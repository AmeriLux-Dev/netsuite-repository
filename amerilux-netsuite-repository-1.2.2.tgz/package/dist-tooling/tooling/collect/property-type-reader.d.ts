import * as ts from 'typescript';
import type { FieldType } from '../../src/types';
/** Identifies a class across the type checker and the evaluator: posix file path plus class name. */
export interface ClassIdentity {
    className: string;
    filePath: string;
}
export declare function classKeyOf(identity: ClassIdentity): string;
/** A property typed as another model class, with the members its declared type keeps. */
export interface DeclaredRelationTarget extends ClassIdentity {
    /** 'all' for the bare class; otherwise the property names of the declared type (Pick, Omit, or an alias of them). */
    projection: string[] | 'all';
}
export interface DeclaredProperty {
    name: string;
    /** Declared with `?`. */
    optional: boolean;
    /** Declared type admits null or undefined; with `optional`, decides whether a relation joins left outer. */
    nullable: boolean;
    isArray: boolean;
    /** Type text as written, used for scalar members of the generated interface. */
    typeText: string;
    /** NetSuite field type inferred from the TypeScript type, when the property is a scalar. */
    scalarType?: FieldType;
    /** Declared on a base class rather than on the class being read. */
    inherited: boolean;
    /** Set when the (element) type resolves to a class; the build step decides whether it is a reference, subrecord, or sublist. */
    target?: DeclaredRelationTarget;
}
export interface DeclaredClass extends ClassIdentity {
    base?: ClassIdentity;
    properties: DeclaredProperty[];
}
export declare const defaultModelCompilerOptions: ts.CompilerOptions;
export declare function createModelTypeProgram(filePaths: string[], compilerOptions?: ts.CompilerOptions): ts.Program;
/** Reads compiler options from a tsconfig file so model files type-check the way the consumer's project does. */
export declare function readCompilerOptionsFromTsconfig(tsconfigPath: string): ts.CompilerOptions;
/** Reads the declared instance properties of an exported class, including inherited ones. Undefined when the class is not found. */
export declare function readDeclaredClass(program: ts.Program, filePath: string, className: string): DeclaredClass | undefined;
