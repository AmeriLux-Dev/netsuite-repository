import type { ConditionNode, QueryDescription } from '../types';
/**
 * Renders a query description as stable, readable text: one clause per line, relation paths as the model names
 * them. It is what tests assert on and what the fake N/query records; it is not SQL and never executes.
 */
export declare function renderQueryDescription(description: QueryDescription, indent?: string): string;
/** Renders a condition tree with SQL precedence made explicit: nested groups are parenthesized, the top level is not. */
export declare function renderConditionNode(node: ConditionNode, topLevel?: boolean): string;
/** A Date in the account's local calendar, with the time only when it is not midnight. */
export declare function renderDate(value: Date): string;
