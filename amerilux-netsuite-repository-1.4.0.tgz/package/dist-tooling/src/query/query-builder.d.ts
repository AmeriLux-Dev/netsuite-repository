import type * as NsQuery from 'N/query';
import type { ConditionValue, FieldReference, FieldReferenceFor, FieldValue, GroupableFieldPath, GroupKeyValues, OperatorFor, ParamFor, RelationName, TextOperator } from '../field-path';
import type { QueryConfigSource } from '../model/resolve';
import type { ConditionParamValue, FieldType, FormulaReturnType, ListPage, ListPageOptions, NQueryOperatorName, QueryDescription, QueryExecution, QueryField, QueryPageOptions, QueryResultValue, SortDirection } from '../types';
import { GroupedQuery } from './grouped-query';
/** The page sizes N/query accepts for runPaged. */
export declare const minimumPageSize = 5;
export declare const maximumPageSize = 1000;
/** Alias of the column a separate query adds to carry the parent key back. */
export declare const parentKeyAlias = "__parentKey";
export interface QueryBuilderOptions<TResult> {
    /** Receives every typed result set (executeTyped, firstTyped) and may substitute instances; used by change tracking. */
    resultObserver?: (results: TResult[]) => TResult[];
    /** How many parent keys one separate-load query asks for at a time. */
    separateLoadBatchSize?: number;
    /**
     * The governance units a read past N/query's 5,000-row answer leaves the script: a list stops with a
     * GovernanceLimitError, and a page stops early, before a read that would dip into them. Defaults to 100.
     */
    governanceReserve?: number;
}
export interface FormulaSelectionOptions {
    /** N/query return type of the formula. */
    type?: FormulaReturnType;
    /** Field type used for read-side coercion and for typing conditions on the alias. */
    fieldType?: FieldType;
    nestPath?: string;
    coerce?: boolean;
    transform?: QueryField['transform'];
}
export declare class QueryBuilder<TResult, TDeclared extends string = never> {
    private readonly config;
    private readonly options;
    private trackingDisabled;
    private selectedKeys;
    private readonly formulaSelections;
    private readonly conditions;
    private readonly sorts;
    private readonly includedRelationships;
    private readonly excludedRelationships;
    private limitValue;
    private offsetValue;
    private coerceEnabled;
    private constructor();
    static from<TResult>(config: QueryConfigSource<TResult>, options?: QueryBuilderOptions<TResult>): QueryBuilder<TResult>;
    /** Loads a reference, subrecord, or sublist that is not selected by default (EF Include). */
    include(...relationships: Array<RelationName<TResult>>): this;
    /** Leaves a reference, subrecord, or sublist and its joins out of this query. */
    exclude(...relationships: Array<RelationName<TResult>>): this;
    /** Results of this query are not registered with the owning context (EF AsNoTracking). */
    asNoTracking(): this;
    select(...keys: Array<FieldReference<TResult, TDeclared>>): this;
    selectAll(): this;
    /**
     * Adds a formula column (N/query `{fieldid}` syntax) mapped onto the result under `alias`, usable in where()
     * and orderBy() by that alias. The only way to read a value the model does not declare.
     */
    selectFormula<TAlias extends string>(formula: string, alias: TAlias, options?: FormulaSelectionOptions): QueryBuilder<TResult, TDeclared | TAlias>;
    /**
     * Adds an AND condition. The operators and the value are typed from the property the field path points at:
     * text takes equality, LIKE, and IN; numbers add order comparisons and BETWEEN; dates take order comparisons
     * and BETWEEN with Date values; a checkbox takes a boolean or 'T'/'F'. Any N/query operator name is accepted
     * too. With `useText` the comparison is made against the display text, so the text operators and string values
     * apply whatever the field. An undefined value skips the condition.
     */
    where<TField extends FieldReference<TResult, TDeclared>, TOperator extends OperatorFor<FieldValue<TResult, TField>>>(field: TField, operator: TOperator, value?: ConditionValue<FieldValue<TResult, TField>, TOperator>, useText?: false): this;
    where<TOperator extends TextOperator>(field: FieldReference<TResult, TDeclared>, operator: TOperator, value: ConditionValue<string, TOperator> | undefined, useText: true): this;
    /** Adds an OR condition; see where() for how the operators and the value are typed. */
    orWhere<TField extends FieldReference<TResult, TDeclared>, TOperator extends OperatorFor<FieldValue<TResult, TField>>>(field: TField, operator: TOperator, value?: ConditionValue<FieldValue<TResult, TField>, TOperator>, useText?: false): this;
    orWhere<TOperator extends TextOperator>(field: FieldReference<TResult, TDeclared>, operator: TOperator, value: ConditionValue<string, TOperator> | undefined, useText: true): this;
    /**
     * Adds an AND condition written as an N/query formula. With no operator the formula is a condition in its own right
     * (`{trandate} + 30 > TRUNC(CURRENT_DATE)`), sent as `CASE WHEN <formula> THEN 1 ELSE 0 END` compared EQUAL 1, the
     * form N/query accepts; with an operator it is a value of the given type compared to `value`. Values written in the
     * formula are part of its text. N/query's formulas have no SYSDATE: write TRUNC(CURRENT_DATE).
     */
    whereFormula(formula: string, type?: FormulaReturnType, operator?: NQueryOperatorName, value?: ConditionParamValue | ConditionParamValue[]): this;
    /** Adds an OR condition written as an N/query formula; see whereFormula(). */
    orWhereFormula(formula: string, type?: FormulaReturnType, operator?: NQueryOperatorName, value?: ConditionParamValue | ConditionParamValue[]): this;
    /** IN over a text or numeric field; skipped when the list is empty or undefined. */
    whereIn<TField extends FieldReferenceFor<TResult, TDeclared, 'IN'>>(field: TField, values: Array<ParamFor<FieldValue<TResult, TField>>> | undefined): this;
    /** NOT IN over a text or numeric field; skipped when the list is empty or undefined. */
    whereNotIn<TField extends FieldReferenceFor<TResult, TDeclared, 'NOT IN'>>(field: TField, values: Array<ParamFor<FieldValue<TResult, TField>>> | undefined): this;
    whereNull(field: FieldReference<TResult, TDeclared>): this;
    whereNotNull(field: FieldReference<TResult, TDeclared>): this;
    /** BETWEEN over a numeric or date field; skipped when either bound is undefined. */
    whereBetween<TField extends FieldReferenceFor<TResult, TDeclared, 'BETWEEN'>>(field: TField, min: ParamFor<FieldValue<TResult, TField>> | undefined, max: ParamFor<FieldValue<TResult, TField>> | undefined): this;
    whereGroup(callback: (builder: QueryBuilder<TResult, TDeclared>) => QueryBuilder<TResult, any>): this;
    orWhereGroup(callback: (builder: QueryBuilder<TResult, TDeclared>) => QueryBuilder<TResult, any>): this;
    orderBy(field: FieldReference<TResult, TDeclared>, direction?: SortDirection): this;
    private describedSortFor;
    /** How a read picks up after a sort on this field: formulas and display text have no comparison a probe checked. */
    private readOnFor;
    /** Whether a component hangs off a reference's select field (joinTo), anywhere between it and the root. */
    private joinsThroughReference;
    orderByAsc(field: FieldReference<TResult, TDeclared>): this;
    orderByDesc(field: FieldReference<TResult, TDeclared>): this;
    limit(count: number): this;
    offset(count: number): this;
    page(pageNumber: number, pageSize: number): this;
    /** Enables or disables read-side coercion of values to their declared field types for this query. */
    coerce(enabled?: boolean): this;
    /**
     * Starts a grouped read (SQL GROUP BY) of this query's conditions: `aggregate()` and `aggregateFormula()` add the
     * aggregate columns, `list()` returns every group. A key is a field path whose declared type holds one value,
     * sublist fields included (each line is a row), or an alias this query declared with selectFormula(). The grouped
     * read works on a copy, so this query is left as it was.
     */
    groupBy<TKey extends GroupableFieldPath<TResult> | TDeclared>(...keys: [TKey, ...TKey[]]): GroupedQuery<TResult, GroupKeyValues<TResult, TKey>, TDeclared, TKey>;
    /** How a grouped query plans and reads through this query; specifications are applied to a copy of it per read. */
    private groupedQueryReader;
    /** An independent copy of this query: its selection, conditions, sorts, relations, page window, and options. */
    private copy;
    /**
     * The plan of a grouped read: the keys as columns marked groupBy, the aggregates, this query's conditions and the
     * model's, and the keys as the query's order: those a sort names first, the rest ascending after them, which is
     * complete since each group has its own keys. N/query sorts on keys only (a sort on an aggregate renders without
     * the aggregate and fails, sandbox 2026-09-28), so a sort that names an aggregate orders the groups in script.
     */
    private planGroupedRead;
    private resolveGroupKey;
    private resolveGroupAggregate;
    /** A field a grouped read can read: one value per row, on a relation its own query joins. */
    private assertReadableInGroupedRead;
    private describeSeparateRelationInGroupedRead;
    /** Each group's row holds its keys at their paths and its aggregates at their aliases: no alias may take another's place. */
    private assertGroupAliasesUnique;
    /** A sort by name: an aggregate's alias, or a key by the name it was grouped by or its field key. */
    private groupSortFor;
    /** Every group of a grouped read: mapped, sorted in script when a sort names an aggregate, and cut to the page window. */
    private readGroups;
    /** What this query asks N/query for, as plain data. */
    describe(): QueryDescription;
    /** The description rendered as stable text, for logs and tests. */
    describeText(): string;
    execute(): QueryExecution<TResult>;
    executeRaw(): Record<string, QueryResultValue>[];
    executeTyped(): TResult[];
    /**
     * One page of the typed results, read across requests: up to `limit` records after the page `after` names, and
     * `next` to name this one. Each page picks up after the last record by its sort values, so a record changed
     * between two pages cannot shift the rest; a page larger than N/query's 5,000-row answer is read on in several.
     * When the script cannot afford another read, the page stops early and `next` says where. Needs every sort to be
     * one a read can compare (the id, numbers, dates, text) and no joined sublist, which answers a row per line.
     */
    executeTypedPage(options: ListPageOptions): ListPage<TResult>;
    /** Rows into typed results: mapped, cut to the page window when rows fanned out, related records loaded, tracked. */
    private buildTypedResults;
    /** Runs the query through N/query's paging and hands the pages back untouched. */
    executePaged(options?: QueryPageOptions): NsQuery.PagedData;
    first(): Record<string, QueryResultValue> | null;
    firstTyped(): TResult | null;
    /** Counts records, not rows: with a joined sublist the primary key is counted distinct. */
    count(): number;
    exists(): boolean;
    /** The SuiteQL NetSuite renders for this query, for debugging. Costs nothing; nothing executes. */
    toSQL(): string;
    private plan;
    /**
     * The query's own sorts, then the internal id: a complete order, so a read past N/query's 5,000-row answer can pick
     * up after the last row, and rows that tie on the sorts never change places between reads. Nothing is added when
     * the id is sorted on already.
     */
    private withPrimaryKeySort;
    /** The sorts a read picks up after, up to the internal id, which completes the order; or why there are none. */
    private planReadOn;
    private planSeparateLoad;
    /** Output paths inside a separately loaded relation are relative to it; a sublist's rows are its items, so nothing groups. */
    private relationMappingOptions;
    private mappingOptions;
    private arrayPathsOf;
    private toColumn;
    private toDescribedComponent;
    /** The components the main query joins: those a selected column, condition, or sort reads, plus their ancestors. */
    private collectComponents;
    /**
     * Parents before children. Depth is the length of the parent chain, which the path need not spell: a reference
     * joined from a field read through a relationship (`subsidiary`) hangs off that relationship's component
     * (`transactionlines`), not off the root.
     */
    private orderComponents;
    private combineWithRootConditions;
    private pageWindow;
    private hasPageWindow;
    private withLimit;
    /** The plan's rows: its page window when it has one, otherwise every row, past N/query's 5,000-row answer. */
    private readRows;
    /**
     * Whether a row window is cut from one run() instead of read through runPaged. When the condition pins the internal
     * id to at most a page's worth of records (find(), getById(), first() on an id), run() answers every row the window
     * can hold for 10 units in one call, where runPaged sizes the result and then fetches it, 20 units in two (probe k1).
     * Only where rows are records: a joined sublist answers a row per line, which the ids do not bound.
     */
    private readsPageWindowInOneRun;
    /**
     * Every row the query matches. One run() answers most queries whole; an answer of 5,000 rows may have stopped
     * short, so the rows after its last one are read the same way until an answer comes back shorter. A query no read
     * can pick up after (a sort no probe compared, a joined sublist's rows, no internal id) is read again through
     * runPaged instead, a thousand rows a fetch.
     */
    private readEveryRow;
    /**
     * Every row of a description: one run() when it answers under 5,000, then read on after `keys`, or through runPaged
     * when there are none or one is text on a record joined through a reference, which a formula may not reach.
     */
    private readEveryRowOf;
    private readOnAfterLastRow;
    /** Every row in the query's own order through runPaged, a thousand a fetch. */
    private readEveryPage;
    private assertAnotherReadAffordable;
    private governanceReserve;
    private executeDescription;
    /** Reads a row window through runPaged: pages are sized to the window, fetched from the first page that overlaps it, and sliced. */
    private runPageWindow;
    private loadSeparateRelations;
    private addWhere;
    /** A condition on the display text of a select field: a formula over the field in DISPLAY context. */
    private createDisplayTextConditionNode;
    /**
     * How a formula names a joined component: the join field ids from the root (`terms`, `transactionlines.item`), not
     * the model's relation names; a formula reaches a joined record through the select field that joins it
     * (sandbox 2026-09-28). Undefined for a component joined from its lines, which no formula names.
     */
    private formulaPathOf;
    private addFormulaCondition;
    private addWhereGroup;
    /** Accepts dotted paths (`customer.companyName`) for the flattened config keys (`customer_companyName`). */
    private normalizeFieldKey;
    private resolveField;
    private assertRelationship;
    /** True when the relationship's fields and components take part in this query. */
    private isRelationshipActive;
    private relationshipOf;
    private loadOf;
    private separateRelationshipOf;
    private activeSeparateRelationships;
    private collectSelectableFields;
    private primaryField;
    private primaryAlias;
}
export declare function query<TResult>(config: QueryConfigSource<TResult>, options?: QueryBuilderOptions<TResult>): QueryBuilder<TResult>;
export declare function runQuery<TResult>(config: QueryConfigSource<TResult>): TResult[];
