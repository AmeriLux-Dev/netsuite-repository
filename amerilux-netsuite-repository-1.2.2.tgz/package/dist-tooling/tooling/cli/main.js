"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EXIT_USAGE = exports.EXIT_PROBLEMS = exports.EXIT_SUCCESS = exports.CLI_USAGE = void 0;
exports.runCli = runCli;
const config_1 = require("../config");
const file_system_1 = require("../file-system");
const generate_1 = require("../generate");
const plugin_1 = require("../plugin");
const watch_1 = require("../watch");
const arguments_1 = require("./arguments");
exports.CLI_USAGE = [
    'Usage: netsuite-repository <command> [options]',
    '',
    'Commands:',
    '  generate        Read the model files and write the config, type, and context files.',
    '  check           Exit non-zero when the generated files are missing or out of date.',
    '  watch           Generate once, then regenerate whenever a model file changes.',
    '  help            Show this message.',
    '',
    'Options:',
    '  --config <path>       Build config file (default: netsuite-repository.config.json).',
    '  --dry-run             With generate: list the files that would be written without writing them.',
].join('\n');
exports.EXIT_SUCCESS = 0;
exports.EXIT_PROBLEMS = 1;
exports.EXIT_USAGE = 2;
const commands = ['generate', 'check', 'watch'];
function formatDiagnostics(plan) {
    return plan.diagnostics.map((diagnostic) => ` - ${diagnostic.filePath}${diagnostic.exportName ? ` (${diagnostic.exportName})` : ''}: ${diagnostic.message}`);
}
/** Runs the CLI and resolves to the process exit code. Never throws for user errors. */
async function runCli(argv, environment) {
    const parsed = (0, arguments_1.parseCommandLineArguments)(argv);
    const fileSystem = environment.fileSystem ?? (0, file_system_1.createNodeFileSystemAdapter)();
    const command = parsed.command ?? 'help';
    if (command === 'help' || (0, arguments_1.readFlagOption)(parsed.options, 'help')) {
        environment.stdout(exports.CLI_USAGE);
        return exports.EXIT_SUCCESS;
    }
    if (!commands.includes(command)) {
        environment.stderr(`Unknown command '${command}'.\n\n${exports.CLI_USAGE}`);
        return exports.EXIT_USAGE;
    }
    let config;
    let options;
    try {
        config = (0, config_1.loadBuildConfig)(fileSystem, environment.cwd, (0, arguments_1.readStringOption)(parsed.options, 'config'));
        options = { config, cwd: config.rootDirectory, fileSystem };
    }
    catch (error) {
        environment.stderr(error instanceof config_1.BuildConfigError ? error.message : `Could not load build config: ${error instanceof Error ? error.message : String(error)}`);
        return exports.EXIT_USAGE;
    }
    if (command === 'generate') {
        if ((0, arguments_1.readFlagOption)(parsed.options, 'dry-run')) {
            const plan = (environment.plan ?? generate_1.planGeneration)(options);
            environment.stdout([`${plan.models.length} model(s); would write:`, ...plan.files.map((file) => ` - ${file.path}`), ...formatDiagnostics(plan)].join('\n'));
            return plan.diagnostics.length > 0 ? exports.EXIT_PROBLEMS : exports.EXIT_SUCCESS;
        }
        const result = (environment.generate ?? generate_1.runGenerate)(options);
        environment.stdout((0, plugin_1.describeGenerateResult)(result));
        return result.diagnostics.length > 0 ? exports.EXIT_PROBLEMS : exports.EXIT_SUCCESS;
    }
    if (command === 'check') {
        const result = (environment.check ?? generate_1.checkGenerated)(options);
        const problems = [
            ...result.missingFiles.map((file) => ` - missing: ${file}`),
            ...result.driftedFiles.map((file) => ` - out of date: ${file}`),
            ...formatDiagnostics(result),
        ];
        if (problems.length > 0) {
            environment.stderr(['Generated files are not up to date. Run `netsuite-repository generate`.', ...problems].join('\n'));
            return exports.EXIT_PROBLEMS;
        }
        environment.stdout(`Generated files are up to date (${result.files.length} file(s)).`);
        return exports.EXIT_SUCCESS;
    }
    const watcher = (0, watch_1.createModelWatcher)({
        ...options,
        generate: environment.generate,
        onGenerated: (result) => environment.stdout((0, plugin_1.describeGenerateResult)(result)),
        onError: (error) => environment.stderr(`netsuite-repository: ${error instanceof Error ? error.message : String(error)}`),
    });
    watcher.start();
    environment.stdout('Watching model files. Press Ctrl+C to stop.');
    environment.onWatcherStarted?.(watcher);
    return exports.EXIT_SUCCESS;
}
