import type { ConditionNode, ConditionParamValue, NQueryOperatorName } from '../types';
import type { TranslatedCondition } from './operator-translation';
/**
 * Builds the condition node for a translated operator: one node, or, when the translation applies its operator per
 * value, one node per value combined the way the translation says.
 */
export declare function conditionNodeForTranslation(translated: TranslatedCondition, makeNode: (operator: NQueryOperatorName, values: ConditionParamValue[] | undefined) => ConditionNode): ConditionNode;
/** A condition and how it links to the one before it. */
export interface LinkedCondition {
    node: ConditionNode;
    link: 'AND' | 'OR';
}
/** Folds a flat list of AND/OR-linked conditions with SQL precedence: AND binds tighter than OR. */
export declare function combineConditions(conditions: LinkedCondition[]): ConditionNode | undefined;
export declare function collectConditionComponents(node: ConditionNode, into: Set<string>): void;
/** Moves a condition tree onto a query rooted at `relationPath`: that component becomes the root, deeper paths keep their names. */
export declare function rerootConditionNode(node: ConditionNode, relationPath: string): ConditionNode;
