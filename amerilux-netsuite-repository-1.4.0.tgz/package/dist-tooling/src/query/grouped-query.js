"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GroupedQuery = exports.numericAggregateNames = void 0;
exports.sortGroups = sortGroups;
const query_description_1 = require("./query-description");
const result_mapper_1 = require("./result-mapper");
exports.numericAggregateNames = ['SUM', 'SUM_DISTINCT', 'AVERAGE', 'AVERAGE_DISTINCT', 'MEDIAN'];
/**
 * A grouped read (SQL `GROUP BY`): the query's conditions, grouped by one or more keys, with aggregate columns under
 * aliases. It selects only its keys and aggregates, loads nothing separately, and tracks nothing. `list()` returns every
 * group, past N/query's 5,000-row answer, sorted by the keys unless a sort says otherwise.
 */
class GroupedQuery {
    constructor(reader, keys) {
        this.reader = reader;
        this.grouping = { keys, aggregates: [], sorts: [] };
    }
    /**
     * Adds an aggregate column over a field path, under `alias`. The aggregate is N/query's own name: COUNT and
     * COUNT_DISTINCT take any field; SUM, AVERAGE, MEDIAN and their DISTINCT forms take numbers (an integer's average
     * comes back whole); MINIMUM, MAXIMUM and their DISTINCT forms take any field and answer its type.
     */
    aggregate(aggregate, field, alias) {
        this.grouping.aggregates.push({ alias, aggregate, field: String(field) });
        return this;
    }
    /**
     * Adds an aggregate column over an N/query formula (`{fieldid}` syntax, `{terms.daysuntilnetdue}` through a select
     * field), under `alias`, typed and coerced as the options say. A formula cannot itself hold an aggregate: to divide
     * one sum by another, aggregate both and divide the results.
     */
    aggregateFormula(aggregate, formula, alias, options = {}) {
        this.grouping.aggregates.push({ alias, aggregate, formula, formulaType: options.type, fieldType: options.fieldType, coerce: options.coerce, transform: options.transform });
        return this;
    }
    /**
     * Sorts by a group key or an aggregate alias. Keys sort in N/query; a sort on an aggregate is applied in script once
     * every group is read, since N/query renders it without the aggregate and fails (sandbox 2026-09-28).
     */
    orderBy(name, direction = 'ASC') {
        this.grouping.sorts.push({ name, ascending: direction === 'ASC' });
        return this;
    }
    orderByAsc(name) {
        return this.orderBy(name, 'ASC');
    }
    orderByDesc(name) {
        return this.orderBy(name, 'DESC');
    }
    /** Every group, past N/query's 5,000-row answer, with the specifications applied the way `RecordSet.list()` applies them. */
    list(...specifications) {
        return this.reader.list(this.grouping, specifications);
    }
    /** What the grouped read asks N/query for, as plain data. */
    describe() {
        return this.reader.describe(this.grouping);
    }
    /** The description rendered as stable text, for logs and tests. */
    describeText() {
        return (0, query_description_1.renderQueryDescription)(this.describe());
    }
    /** The SuiteQL NetSuite renders for the grouped read, for debugging. Nothing executes. */
    toSQL() {
        return this.reader.toSQL(this.grouping);
    }
}
exports.GroupedQuery = GroupedQuery;
function isBlank(value) {
    return value === null || value === undefined || value === '';
}
/**
 * How two groups' values order, the way NetSuite orders them: blanks last ascending and first descending (probe k4),
 * numbers and dates by value, text upper-cased.
 */
function compareGroupValues(left, right, ascending) {
    if (isBlank(left) || isBlank(right)) {
        if (isBlank(left) && isBlank(right)) {
            return 0;
        }
        return isBlank(left) === ascending ? 1 : -1;
    }
    let order;
    if (left instanceof Date && right instanceof Date) {
        order = left.getTime() - right.getTime();
    }
    else if (typeof left === 'number' && typeof right === 'number') {
        order = left - right;
    }
    else {
        const leftText = String(left).toUpperCase();
        const rightText = String(right).toUpperCase();
        order = leftText < rightText ? -1 : leftText > rightText ? 1 : 0;
    }
    return ascending ? order : -order;
}
/** The groups in the script sort's order; groups that tie keep the order N/query read them in. */
function sortGroups(groups, sorts) {
    return groups
        .map((group, index) => ({ group, index }))
        .sort((left, right) => {
        for (const sort of sorts) {
            const order = compareGroupValues((0, result_mapper_1.getValueAtPath)(left.group, sort.path), (0, result_mapper_1.getValueAtPath)(right.group, sort.path), sort.ascending);
            if (order !== 0) {
                return order;
            }
        }
        return left.index - right.index;
    })
        .map((entry) => entry.group);
}
