"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChangeTracker = exports.EntityState = void 0;
const deep_clone_1 = require("./deep-clone");
const diff_1 = require("./diff");
var EntityState;
(function (EntityState) {
    EntityState["Detached"] = "Detached";
    EntityState["Unchanged"] = "Unchanged";
    EntityState["Added"] = "Added";
    EntityState["Modified"] = "Modified";
    EntityState["Deleted"] = "Deleted";
})(EntityState || (exports.EntityState = EntityState = {}));
function keyPropertyOf(config) {
    for (const [key, field] of Object.entries(config.fields)) {
        if (field.isPrimary) {
            return key;
        }
    }
    throw new Error(`No primary field is configured for '${config.recordType}', so its entities cannot be tracked.`);
}
function keyOf(entity, keyProperty) {
    const value = entity[keyProperty];
    return typeof value === 'number' || (typeof value === 'string' && value !== '') ? value : undefined;
}
/**
 * Identity map plus snapshots for entities loaded through a context.
 * Entries are held strongly (ES2019 has no WeakRef and a WeakMap cannot be iterated), so contexts should live for one script execution.
 */
class ChangeTracker {
    constructor(resolveConfig, enabled = true) {
        this.resolveConfig = resolveConfig;
        this.enabled = enabled;
        this.entries = new Map();
        this.identity = new Map();
    }
    /** Registers query results; a result whose key is already tracked is replaced by the tracked instance (identity resolution). */
    trackQueryResults(setName, results) {
        if (!this.enabled) {
            return results;
        }
        const keyProperty = keyPropertyOf(this.resolveConfig(setName));
        return results.map((result) => {
            const key = keyOf(result, keyProperty);
            if (key === undefined) {
                return result;
            }
            const existing = this.findTracked(setName, key);
            if (existing) {
                return existing;
            }
            this.register(setName, result, EntityState.Unchanged, key);
            return result;
        });
    }
    attach(setName, entity) {
        const key = keyOf(entity, keyPropertyOf(this.resolveConfig(setName)));
        if (key === undefined) {
            throw new Error(`Cannot attach an entity to '${setName}' without a key value.`);
        }
        const existing = this.findTracked(setName, key);
        if (existing && existing !== entity) {
            throw new Error(`Another instance with key '${String(key)}' is already tracked in '${setName}'.`);
        }
        this.register(setName, entity, EntityState.Unchanged, key);
        return this.entry(entity);
    }
    add(setName, entity) {
        const key = keyOf(entity, keyPropertyOf(this.resolveConfig(setName)));
        if (key !== undefined && this.findTracked(setName, key) && this.findTracked(setName, key) !== entity) {
            throw new Error(`Another instance with key '${String(key)}' is already tracked in '${setName}'.`);
        }
        this.register(setName, entity, EntityState.Added, key);
        return this.entry(entity);
    }
    /** Marks an entity (or a bare key) for deletion. Removing an Added entity simply detaches it. */
    remove(setName, entityOrKey) {
        const keyProperty = keyPropertyOf(this.resolveConfig(setName));
        const entity = (typeof entityOrKey === 'object' ? entityOrKey : this.findTracked(setName, entityOrKey) ?? { [keyProperty]: entityOrKey });
        const tracked = this.entries.get(entity);
        if (tracked?.state === EntityState.Added) {
            this.detach(entity);
            return this.detachedEntry(setName, entity, keyOf(entity, keyProperty));
        }
        this.register(setName, entity, EntityState.Deleted, keyOf(entity, keyProperty), tracked?.snapshot);
        return this.entry(entity);
    }
    detach(entity) {
        const tracked = this.entries.get(entity);
        if (!tracked) {
            return;
        }
        this.entries.delete(entity);
        const key = keyOf(tracked.entity, keyPropertyOf(this.resolveConfig(tracked.setName)));
        if (key !== undefined) {
            this.identity.get(tracked.setName)?.delete(String(key));
        }
    }
    entry(entity) {
        const tracked = this.entries.get(entity);
        if (!tracked) {
            return undefined;
        }
        const tracker = this;
        return {
            entity,
            setName: tracked.setName,
            get key() {
                return keyOf(tracked.entity, keyPropertyOf(tracker.resolveConfig(tracked.setName)));
            },
            get state() {
                return tracked.state;
            },
            set state(state) {
                tracker.setState(tracked, state);
            },
            get originalValues() {
                return tracked.snapshot;
            },
            reload() {
                tracked.snapshot = (0, deep_clone_1.cloneEntitySnapshot)(tracked.entity);
                tracked.state = EntityState.Unchanged;
                tracked.forceFullWrite = false;
            },
        };
    }
    findTracked(setName, key) {
        return this.identity.get(setName)?.get(String(key));
    }
    trackedEntries() {
        return Array.from(this.entries.keys()).map((entity) => this.entry(entity));
    }
    /** Diffs every tracked entity against its snapshot and updates states to Modified where values changed. */
    detectChanges() {
        const changeSet = [];
        for (const tracked of this.entries.values()) {
            const config = this.resolveConfig(tracked.setName);
            const key = keyOf(tracked.entity, keyPropertyOf(config));
            if (tracked.state === EntityState.Deleted) {
                changeSet.push({ setName: tracked.setName, state: tracked.state, key, entity: tracked.entity, ignoredProperties: [] });
                continue;
            }
            if (tracked.state === EntityState.Added) {
                const diff = (0, diff_1.buildAddedEntityPatch)(config, tracked.entity);
                changeSet.push({ setName: tracked.setName, state: tracked.state, key, entity: tracked.entity, patch: diff.patch ?? {}, ignoredProperties: diff.ignoredProperties });
                continue;
            }
            const diff = tracked.forceFullWrite
                ? (0, diff_1.buildAddedEntityPatch)(config, tracked.entity)
                : (0, diff_1.diffTrackedEntity)(config, tracked.snapshot ?? {}, tracked.entity);
            if (diff.patch) {
                tracked.state = EntityState.Modified;
                changeSet.push({ setName: tracked.setName, state: EntityState.Modified, key, entity: tracked.entity, patch: diff.patch, ignoredProperties: diff.ignoredProperties });
            }
            else {
                tracked.state = EntityState.Unchanged;
            }
        }
        return { entries: changeSet, hasChanges: changeSet.length > 0 };
    }
    /** Re-snapshots saved entities: Added becomes Unchanged with its new key, Modified becomes Unchanged, Deleted is detached. */
    acceptChanges(accepted) {
        for (const change of accepted) {
            const tracked = this.entries.get(change.entity);
            if (!tracked) {
                continue;
            }
            if (tracked.state === EntityState.Deleted) {
                this.detach(change.entity);
                continue;
            }
            const keyProperty = keyPropertyOf(this.resolveConfig(tracked.setName));
            if (change.assignedKey !== undefined) {
                tracked.entity[keyProperty] = change.assignedKey;
            }
            const key = keyOf(tracked.entity, keyProperty);
            if (key !== undefined) {
                this.indexIdentity(tracked.setName, key, change.entity);
            }
            tracked.snapshot = (0, deep_clone_1.cloneEntitySnapshot)(tracked.entity);
            tracked.state = EntityState.Unchanged;
            tracked.forceFullWrite = false;
        }
    }
    clear() {
        this.entries.clear();
        this.identity.clear();
    }
    register(setName, entity, state, key, snapshot) {
        const existing = this.entries.get(entity);
        const tracked = existing ?? { setName, entity, state, forceFullWrite: false };
        tracked.setName = setName;
        tracked.state = state;
        tracked.forceFullWrite = false;
        tracked.snapshot = state === EntityState.Added ? undefined : snapshot ?? (state === EntityState.Unchanged ? (0, deep_clone_1.cloneEntitySnapshot)(entity) : tracked.snapshot);
        this.entries.set(entity, tracked);
        if (key !== undefined) {
            this.indexIdentity(setName, key, entity);
        }
    }
    indexIdentity(setName, key, entity) {
        let bySet = this.identity.get(setName);
        if (!bySet) {
            bySet = new Map();
            this.identity.set(setName, bySet);
        }
        bySet.set(String(key), entity);
    }
    setState(tracked, state) {
        switch (state) {
            case EntityState.Detached:
                this.detach(tracked.entity);
                return;
            case EntityState.Modified:
                tracked.state = EntityState.Modified;
                tracked.forceFullWrite = true;
                return;
            case EntityState.Unchanged:
                tracked.snapshot = (0, deep_clone_1.cloneEntitySnapshot)(tracked.entity);
                tracked.state = EntityState.Unchanged;
                tracked.forceFullWrite = false;
                return;
            default:
                tracked.state = state;
                tracked.forceFullWrite = false;
        }
    }
    detachedEntry(setName, entity, key) {
        return {
            entity,
            setName,
            key,
            state: EntityState.Detached,
            originalValues: undefined,
            reload: () => undefined,
        };
    }
}
exports.ChangeTracker = ChangeTracker;
