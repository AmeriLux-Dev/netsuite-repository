import type { FileSystemAdapter } from './file-system';
export interface BuildConfig {
    /** Globs (relative to the config file's directory) selecting model files. Patterns starting with `!` exclude. */
    models: string[];
    /** Directory (relative to the config file's directory) receiving the generated files. */
    outDir: string;
    context: {
        /** Prefix for the generated context: `AppSchema`, `AppContext`, `createAppContext()`. */
        name: string;
        fileName: string;
    };
    /**
     * The generated types file: the interface of every class and, for record types, the `<Class>Patch` and `<Class>Create`
     * helper types. Type-only, so a browser client can import it without pulling the configs into its bundle.
     */
    types: {
        fileName: string;
        /** Directory (relative to the config file's directory) receiving the types file; defaults to `outDir`. */
        outDir?: string;
    };
    /** Optional tsconfig path (relative to the config file's directory) used to type-check model files; defaults to sensible compiler options. */
    tsconfig?: string;
    /** Module specifier model files import the library from, and generated files import the runtime from. */
    libraryModule: string;
    /**
     * 'classes' also emits a base repository class per record type and lets the context factory accept subclasses.
     * 'none' (default) emits only the configs, types, and context; queries live in modules of functions that take the context.
     */
    repositories: 'classes' | 'none';
}
/** A loaded build config plus the directory its relative paths resolve against. */
export interface ResolvedBuildConfig extends BuildConfig {
    /** The config file's directory, or the working directory when no config file exists and the defaults apply. */
    rootDirectory: string;
}
export declare const DEFAULT_BUILD_CONFIG_FILE_NAME = "netsuite-repository.config.json";
export declare const defaultBuildConfig: BuildConfig;
export declare class BuildConfigError extends Error {
    readonly configPath: string;
    readonly problems: string[];
    constructor(configPath: string, problems: string[]);
}
/**
 * Loads the build config from disk, falling back to defaults when no config file exists.
 * Relative paths inside the config resolve against the config file's directory, so `--config examples/netsuite-repository.config.json` works from anywhere.
 */
export declare function loadBuildConfig(fileSystem: FileSystemAdapter, cwd: string, configPath?: string): ResolvedBuildConfig;
