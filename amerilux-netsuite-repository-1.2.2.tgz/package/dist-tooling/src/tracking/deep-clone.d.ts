/**
 * Copies an entity graph so it can later be diffed against the live object.
 * Dates are copied, arrays and plain objects recurse, functions and prototypes are dropped.
 * structuredClone is unavailable in SuiteScript, so this stays hand-written and small.
 */
export declare function cloneEntitySnapshot<T>(value: T, visited?: WeakSet<object>): T;
