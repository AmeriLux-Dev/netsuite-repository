/** Minimal file system surface used by the build step so tests can run fully in memory. */
export interface FileSystemAdapter {
    readTextFile(filePath: string): string;
    writeTextFile(filePath: string, content: string): void;
    fileExists(filePath: string): boolean;
    ensureDirectory(directoryPath: string): void;
    /** Recursively lists absolute file paths under a directory. Returns [] when it does not exist. */
    listFiles(directoryPath: string): string[];
    /** Watches files or directories; returns a function that stops watching. */
    watch(paths: string[], onChange: (changedPath: string) => void): () => void;
}
export declare function toPosixPath(filePath: string): string;
/** Matches a relative POSIX path against a glob supporting `**`, `*`, and `?`. */
export declare function matchesGlob(pattern: string, relativePath: string): boolean;
/** The folder a glob starts from: its segments up to the first one with a wildcard. */
export declare function globBaseDirectory(pattern: string): string;
/** Resolves glob patterns (relative to cwd) to sorted absolute file paths. Patterns starting with `!` exclude. */
export declare function resolveGlobs(fileSystem: FileSystemAdapter, cwd: string, patterns: string[]): string[];
export declare function createNodeFileSystemAdapter(): FileSystemAdapter;
export interface InMemoryFileSystemAdapter extends FileSystemAdapter {
    readonly files: Map<string, string>;
    /** Simulates a change notification for tests. */
    emitChange(changedPath: string): void;
}
export declare function createInMemoryFileSystemAdapter(initialFiles?: Record<string, string>): InMemoryFileSystemAdapter;
