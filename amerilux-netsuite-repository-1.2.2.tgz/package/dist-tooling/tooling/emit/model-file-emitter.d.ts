import type { QueryConfig } from '../../src/types';
/** A function a config may reference, with the identifier to emit and where to import it from. */
export interface FunctionImport {
    fn: Function;
    identifier: string;
    exportName: string;
    /** Import path (extension-less, relative to the output directory). */
    importPath: string;
}
/** A field path per property, nested by relation: `{ id: 'id', lines: { item: { type: 'lines.item.type' } } }`. */
export interface FieldPathTree {
    [name: string]: string | FieldPathTree;
}
export interface ModelFileEmitOptions {
    className: string;
    libraryModule: string;
    /** Import path (extension-less, relative to the output directory) of the types file holding the class's interface. */
    typesImportPath: string;
    config: QueryConfig<unknown>;
    functionImports: FunctionImport[];
    fields: FieldPathTree;
    /** Also emit `<Model>RepositoryBase`, a RecordSet bound to the config. */
    repository: boolean;
    version?: string;
}
/**
 * Emits `<Class>.gen.ts`, the runtime side of one record type: the `<Class>Config` literal, the `<Class>Fields` paths,
 * and, when asked for, the `<Class>RepositoryBase` class. The interface and helper types live in the types file; this
 * file imports the interface from there and re-exports the three, so a server module can import everything from one place.
 */
export declare function emitModelFile(options: ModelFileEmitOptions): string;
