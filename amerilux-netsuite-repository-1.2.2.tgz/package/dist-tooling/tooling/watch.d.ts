import type { BuildConfig } from './config';
import type { GenerateOptions, GenerateResult } from './generate';
export interface ModelWatcherOptions extends GenerateOptions {
    /** Called after every generation run, including the initial one. */
    onGenerated?: (result: GenerateResult) => void;
    /** Called when a generation run throws. */
    onError?: (error: unknown) => void;
    debounceMilliseconds?: number;
    /** Replaceable for tests; defaults to runGenerate. */
    generate?: (options: GenerateOptions) => GenerateResult;
}
export interface ModelWatcher {
    /** Runs generation once and starts watching. */
    start(): void;
    stop(): void;
    /** Whether the watcher is currently running. */
    readonly running: boolean;
}
/** Directories and files the watcher observes: every model glob base plus the config file. */
export declare function resolveWatchedPaths(config: BuildConfig, cwd: string): string[];
/** Re-runs generation whenever a model file changes, TanStack Router style. */
export declare function createModelWatcher(options: ModelWatcherOptions): ModelWatcher;
