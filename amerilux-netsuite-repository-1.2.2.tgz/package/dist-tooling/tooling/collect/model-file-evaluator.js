"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.evaluateModelFiles = evaluateModelFiles;
const nodePath = __importStar(require("path"));
const vm = __importStar(require("vm"));
const ts = __importStar(require("typescript"));
const file_system_1 = require("../file-system");
const transpileOptions = {
    module: ts.ModuleKind.CommonJS,
    target: ts.ScriptTarget.ES2019,
    experimentalDecorators: true,
    useDefineForClassFields: false,
    esModuleInterop: true,
};
class ModelImportError extends Error {
}
function isClassConstructor(value) {
    return typeof value === 'function' && /^class[\s{]/.test(Function.prototype.toString.call(value));
}
function resolveRelativeModelFile(fileSystem, importingFile, specifier) {
    const base = nodePath.resolve(nodePath.dirname(importingFile), specifier.replace(/\.js$/, ''));
    const candidates = [base, `${base}.ts`, nodePath.join(base, 'index.ts')];
    return candidates.find((candidate) => candidate.endsWith('.ts') && fileSystem.fileExists(candidate));
}
/**
 * Transpiles and runs model files in a sandbox whose `require` only knows the library and relative model files,
 * then collects every exported class with the overrides its decorators registered through the shared runtime instance.
 */
function evaluateModelFiles(options) {
    const { fileSystem, libraryModule, runtimeModule, runtimeApi } = options;
    const moduleCache = new Map();
    const diagnostics = [];
    const classes = [];
    const loadModelModule = (filePath) => {
        const cached = moduleCache.get(filePath);
        if (cached) {
            return cached.exports;
        }
        const moduleRecord = { exports: {} };
        moduleCache.set(filePath, moduleRecord);
        const source = fileSystem.readTextFile(filePath);
        const transpiled = ts.transpileModule(source, { compilerOptions: transpileOptions, fileName: filePath }).outputText;
        const sandboxRequire = (specifier) => {
            if (specifier === libraryModule || specifier.startsWith(`${libraryModule}/`)) {
                return runtimeModule;
            }
            if (specifier.startsWith('.')) {
                const resolved = resolveRelativeModelFile(fileSystem, filePath, specifier);
                if (!resolved) {
                    throw new ModelImportError(`Cannot resolve relative import '${specifier}' from '${filePath}'.`);
                }
                return loadModelModule(resolved);
            }
            throw new ModelImportError(`Model files may only import '${libraryModule}' or relative model files; found '${specifier}'.`);
        };
        const wrapper = vm.runInThisContext(`(function (exports, require, module, __filename, __dirname) {${transpiled}\n})`, { filename: filePath });
        wrapper(moduleRecord.exports, sandboxRequire, moduleRecord, filePath, nodePath.dirname(filePath));
        return moduleRecord.exports;
    };
    const seenClasses = new Set();
    for (const filePath of options.filePaths) {
        let exports;
        try {
            exports = loadModelModule(filePath);
        }
        catch (error) {
            diagnostics.push({ filePath, message: error instanceof Error ? error.message : String(error) });
            continue;
        }
        for (const [exportName, value] of Object.entries(exports)) {
            if (!isClassConstructor(value) || seenClasses.has(value)) {
                continue;
            }
            seenClasses.add(value);
            try {
                classes.push({ filePath: (0, file_system_1.toPosixPath)(filePath), exportName, className: value.name, constructor: value, overrides: runtimeApi.getClassOverrides(value) });
            }
            catch (error) {
                diagnostics.push({ filePath, exportName, message: error instanceof Error ? error.message : String(error) });
            }
        }
    }
    const functionReferences = new Map();
    for (const [modulePath, moduleRecord] of moduleCache) {
        for (const [exportName, value] of Object.entries(moduleRecord.exports)) {
            if (typeof value === 'function' && !isClassConstructor(value) && !functionReferences.has(value)) {
                functionReferences.set(value, { exportName, filePath: modulePath });
            }
        }
    }
    return { classes, diagnostics, functionReferences };
}
