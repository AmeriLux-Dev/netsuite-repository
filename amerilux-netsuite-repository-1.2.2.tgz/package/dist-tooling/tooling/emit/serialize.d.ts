export declare class SerializationError extends Error {
    constructor(message: string);
}
export interface SerializeOptions {
    /** Functions that can be referenced by an imported identifier instead of being inlined. */
    functionReferences?: Map<Function, string>;
    indent?: string;
}
/** Serializes plain data (and referenced functions) to a TypeScript object literal. */
export declare function serializeToTypeScriptLiteral(value: unknown, options?: SerializeOptions): string;
