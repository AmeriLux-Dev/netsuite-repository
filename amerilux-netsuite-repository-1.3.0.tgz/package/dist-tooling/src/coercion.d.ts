import type { CoercedQueryValue, FieldType, QueryResultValue } from './types';
/**
 * The dates one read has parsed, by format type and text: the time N/format answered, or null when it could not parse
 * the text. A read's dates repeat (every line of an order carries its date), so each text goes through N/format once
 * and every other row gets its own Date with the same time.
 */
export type ParsedDateCache = Map<string, number | null>;
/**
 * Coerces a raw SuiteQL value to the JavaScript type implied by the declared field type.
 * Values that cannot be coerced are returned unchanged so a bad row never throws during mapping.
 * `parsedDates` lets the rows of one read share their date parses; without it every date is parsed.
 */
export declare function coerceQueryResultValueByFieldType(value: QueryResultValue, type: FieldType | undefined, parsedDates?: ParsedDateCache): CoercedQueryValue;
