"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.resolveQueryConfig = resolveQueryConfig;
const types_1 = require("../types");
/** Resolves any QueryConfigSource to a normalized QueryConfig. */
function resolveQueryConfig(source) {
    return (0, types_1.normalizeQueryConfig)(source);
}
