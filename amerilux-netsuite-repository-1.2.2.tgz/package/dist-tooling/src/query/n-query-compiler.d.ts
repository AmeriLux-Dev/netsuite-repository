import type * as NsQuery from 'N/query';
import type { QueryDescription } from '../types';
export type NQueryModule = typeof import('N/query');
/** Reads an enum member off the loaded N/query module by name, so the library never carries NetSuite's values itself. */
export declare function resolveNQueryEnumValue(enumObject: object, name: string, enumName: string): string;
/** The hidden column a sort on an unselected field is given; the mapper reads rows by the model's aliases and never sees it. */
export declare function hiddenSortColumnAlias(index: number): string;
/** For each sort, the alias its value comes back under: the selected column it reuses, or its hidden `__sort<n>` column. */
export declare function sortColumnAliases(description: QueryDescription): string[];
/**
 * Builds the N/query Query object a description asks for: the root type, every joined component in parent-first
 * order, the columns with their aliases and contexts, the condition tree (declared component conditions ANDed
 * in front of the query's own), and the sorts. Enum values are read off the module by name.
 */
export declare function compileQueryDescriptionToNQuery(description: QueryDescription, nsQuery: NQueryModule): NsQuery.Query;
