"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.coerceQueryResultValueByFieldType = coerceQueryResultValueByFieldType;
function getNsFormat() {
    return require('N/format');
}
const numericFieldTypes = new Set(['integer', 'float', 'currency', 'key']);
const booleanFieldTypes = new Set(['boolean', 'checkbox']);
const dateFieldTypes = new Set(['date', 'datetime']);
/**
 * Coerces a raw SuiteQL value to the JavaScript type implied by the declared field type.
 * Values that cannot be coerced are returned unchanged so a bad row never throws during mapping.
 * `parsedDates` lets the rows of one read share their date parses; without it every date is parsed.
 */
function coerceQueryResultValueByFieldType(value, type, parsedDates) {
    if (value === null || value === undefined || type === undefined) {
        return value ?? null;
    }
    if (numericFieldTypes.has(type)) {
        return coerceNumericValue(value);
    }
    if (booleanFieldTypes.has(type)) {
        return coerceBooleanValue(value);
    }
    if (dateFieldTypes.has(type)) {
        return coerceDateValue(value, type === 'datetime' ? 'DATETIME' : 'DATE', parsedDates);
    }
    return value;
}
function coerceNumericValue(value) {
    if (typeof value === 'string') {
        const trimmed = value.trim();
        if (trimmed !== '' && !Number.isNaN(Number(trimmed))) {
            return Number(trimmed);
        }
    }
    return value;
}
function coerceBooleanValue(value) {
    if (typeof value === 'string') {
        const normalized = value.trim().toUpperCase();
        if (normalized === 'T' || normalized === 'TRUE') {
            return true;
        }
        if (normalized === 'F' || normalized === 'FALSE') {
            return false;
        }
    }
    return value;
}
function coerceDateValue(value, formatType, parsedDates) {
    if (typeof value !== 'string' || value.trim() === '') {
        return value;
    }
    const cacheKey = `${formatType}:${value}`;
    const cachedTime = parsedDates?.get(cacheKey);
    if (cachedTime !== undefined) {
        return cachedTime === null ? value : new Date(cachedTime);
    }
    const parsed = parseDateWithNsFormat(value, formatType);
    parsedDates?.set(cacheKey, parsed === undefined ? null : parsed.getTime());
    return parsed ?? value;
}
/** The date N/format reads in the text, or undefined when N/format is unavailable, throws, or answers no valid date. */
function parseDateWithNsFormat(value, formatType) {
    try {
        const format = getNsFormat();
        const parsed = format.parse({ value, type: format.Type[formatType] });
        if (parsed instanceof Date && !Number.isNaN(parsed.getTime())) {
            return parsed;
        }
    }
    catch {
        // N/format is unavailable or rejected the value; the caller keeps the raw string.
    }
    return undefined;
}
