export interface ParsedCommandLine {
    command?: string;
    options: Record<string, string | boolean>;
    positional: string[];
}
/** Parses `command --key value --key=value --flag positional` without any dependency. */
export declare function parseCommandLineArguments(argv: string[]): ParsedCommandLine;
export declare function readStringOption(options: Record<string, string | boolean>, name: string): string | undefined;
export declare function readFlagOption(options: Record<string, string | boolean>, name: string): boolean;
