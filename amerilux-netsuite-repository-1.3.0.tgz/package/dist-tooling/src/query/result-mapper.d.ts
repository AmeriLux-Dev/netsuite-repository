import type { ParsedDateCache } from '../coercion';
import type { FieldMap, QueryField, QueryResultValue } from '../types';
export type ResultRow = Record<string, QueryResultValue>;
export interface ResultMappingOptions {
    fieldMap: FieldMap;
    /** Output paths whose fields fan out one row per element (`lines`); rows are grouped by the primary alias into arrays. */
    arrayPaths: string[];
    /** Alias of the primary key column; rows are grouped by it when array paths exist. */
    primaryAlias?: string;
    coerceEnabled: boolean;
}
/** N/query keys mapped results by alias; the mapper compares aliases case-insensitively so casing differences never matter. */
export declare function normalizeMappedResultKey(key: string): string;
/** Builds the alias → output path map for the fields a query selects. Keys are normalized aliases. */
export declare function buildFieldMap(fields: Array<[string, QueryField]>): FieldMap;
/**
 * Maps result rows into typed objects, grouping fanned-out sublist rows under their parent when array paths exist.
 * The rows share `parsedDates`, so each date text is parsed once; pass one cache to several calls over the same read.
 */
export declare function mapRowsToResults<TResult>(rows: ResultRow[], options: ResultMappingOptions, parsedDates?: ParsedDateCache): TResult[];
/** Coerces a raw value to the field's declared type when coercion is on for it, then applies the field's transform. */
export declare function transformResultValue(value: QueryResultValue, row: ResultRow, field: QueryField, coerceEnabled: boolean, parsedDates?: ParsedDateCache): unknown;
/** Writes a value at a dotted path, creating intermediate objects. */
export declare function setValueAtPath(target: Record<string, unknown>, path: string, value: unknown): void;
/** Reads a value at a dotted path; undefined when any segment is missing. */
export declare function getValueAtPath(source: unknown, path: string): unknown;
