"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.defineQueryConfig = defineQueryConfig;
exports.normalizeQueryConfig = normalizeQueryConfig;
exports.normalizeQueryField = normalizeQueryField;
function defineQueryConfig(config) {
    return normalizeQueryConfig(config);
}
/** Flattens sectioned fields and fills the defaults the runtime relies on: the query type and the component map. */
function normalizeQueryConfig(config) {
    const fields = {};
    for (const [key, field] of Object.entries(config.fields)) {
        fields[key] = normalizeQueryField(field);
    }
    return { ...config, queryType: config.queryType ?? config.recordType, components: config.components ?? {}, fields };
}
function normalizeQueryField(field) {
    if (!isQueryFieldSections(field))
        return field;
    return {
        ...field.query,
        ...(field.common || {}),
        ...(field.record || {}),
    };
}
function isQueryFieldSections(field) {
    return Boolean(field && typeof field === 'object' && 'query' in field && field.query && typeof field.query === 'object');
}
