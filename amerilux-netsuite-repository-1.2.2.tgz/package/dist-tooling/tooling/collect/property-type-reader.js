"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.defaultModelCompilerOptions = void 0;
exports.classKeyOf = classKeyOf;
exports.createModelTypeProgram = createModelTypeProgram;
exports.readCompilerOptionsFromTsconfig = readCompilerOptionsFromTsconfig;
exports.readDeclaredClass = readDeclaredClass;
const ts = __importStar(require("typescript"));
const file_system_1 = require("../file-system");
function classKeyOf(identity) {
    return `${identity.filePath}#${identity.className}`;
}
exports.defaultModelCompilerOptions = {
    target: ts.ScriptTarget.ES2019,
    module: ts.ModuleKind.CommonJS,
    moduleResolution: ts.ModuleResolutionKind.Node10,
    experimentalDecorators: true,
    useDefineForClassFields: false,
    strict: true,
    skipLibCheck: true,
    noEmit: true,
};
function createModelTypeProgram(filePaths, compilerOptions = {}) {
    return ts.createProgram({ rootNames: filePaths.map(file_system_1.toPosixPath), options: { ...exports.defaultModelCompilerOptions, ...compilerOptions, noEmit: true } });
}
/** Reads compiler options from a tsconfig file so model files type-check the way the consumer's project does. */
function readCompilerOptionsFromTsconfig(tsconfigPath) {
    const configFile = ts.readConfigFile(tsconfigPath, ts.sys.readFile);
    if (configFile.error) {
        throw new Error(`Could not read tsconfig '${tsconfigPath}': ${ts.flattenDiagnosticMessageText(configFile.error.messageText, '\n')}`);
    }
    const parsed = ts.parseJsonConfigFileContent(configFile.config, ts.sys, (0, file_system_1.toPosixPath)(tsconfigPath).replace(/\/[^/]+$/, ''));
    return parsed.options;
}
function findExportedClass(sourceFile, exportName) {
    for (const statement of sourceFile.statements) {
        if (ts.isClassDeclaration(statement) && statement.name?.text === exportName) {
            return statement;
        }
    }
    return undefined;
}
function classifyScalarFieldType(type) {
    if (type.flags & ts.TypeFlags.BooleanLike)
        return 'boolean';
    if (type.flags & ts.TypeFlags.NumberLike)
        return 'float';
    if (type.flags & ts.TypeFlags.StringLike)
        return 'string';
    if (type.getSymbol()?.name === 'Date')
        return 'date';
    if (type.isUnion()) {
        const memberTypes = type.types.map(classifyScalarFieldType);
        const first = memberTypes[0];
        return first !== undefined && memberTypes.every((member) => member === first) ? first : undefined;
    }
    return undefined;
}
function identityOf(declaration) {
    return declaration.name ? { className: declaration.name.text, filePath: (0, file_system_1.toPosixPath)(declaration.getSourceFile().fileName) } : undefined;
}
function classDeclarationOfType(type) {
    const declaration = type.getSymbol()?.valueDeclaration;
    return declaration && ts.isClassDeclaration(declaration) ? declaration : undefined;
}
/** Follows `Pick<Customer, ...>`, `Omit<...>`, and aliases of them down to the class they project. */
function classDeclarationOfTypeNode(context, node, depth = 0) {
    if (!node || depth > 8) {
        return undefined;
    }
    const direct = classDeclarationOfType(context.checker.getTypeFromTypeNode(node));
    if (direct) {
        return direct;
    }
    if (ts.isTypeReferenceNode(node)) {
        for (const argument of node.typeArguments ?? []) {
            const found = classDeclarationOfTypeNode(context, argument, depth + 1);
            if (found) {
                return found;
            }
        }
        const symbol = context.checker.getSymbolAtLocation(node.typeName);
        const aliasDeclaration = symbol?.declarations?.find(ts.isTypeAliasDeclaration);
        if (aliasDeclaration) {
            return classDeclarationOfTypeNode(context, aliasDeclaration.type, depth + 1);
        }
    }
    return undefined;
}
/** Last resort for projected types: the class that declares the projected members. */
function classDeclarationOfMembers(context, type) {
    for (const property of context.checker.getPropertiesOfType(type)) {
        const declaration = property.declarations?.[0];
        if (declaration && ts.isPropertyDeclaration(declaration) && ts.isClassDeclaration(declaration.parent)) {
            return declaration.parent;
        }
    }
    return undefined;
}
function resolveRelationTarget(context, type, typeNode) {
    const direct = classDeclarationOfType(type);
    if (direct) {
        const identity = identityOf(direct);
        return identity ? { ...identity, projection: 'all' } : undefined;
    }
    const aliasArguments = type.aliasTypeArguments ?? [];
    const fromAlias = aliasArguments.map(classDeclarationOfType).find((declaration) => Boolean(declaration));
    const declaration = fromAlias ?? classDeclarationOfTypeNode(context, typeNode) ?? classDeclarationOfMembers(context, type);
    const identity = declaration ? identityOf(declaration) : undefined;
    if (!identity) {
        return undefined;
    }
    return { ...identity, projection: context.checker.getPropertiesOfType(type).map((property) => property.name) };
}
function elementTypeNodeOf(node) {
    if (!node)
        return undefined;
    if (ts.isArrayTypeNode(node))
        return node.elementType;
    if (ts.isTypeReferenceNode(node) && ts.isIdentifier(node.typeName) && node.typeName.text === 'Array')
        return node.typeArguments?.[0];
    if (ts.isUnionTypeNode(node)) {
        const member = node.types.find((candidate) => !(ts.isLiteralTypeNode(candidate) && candidate.literal.kind === ts.SyntaxKind.NullKeyword) && candidate.kind !== ts.SyntaxKind.UndefinedKeyword);
        return elementTypeNodeOf(member);
    }
    return undefined;
}
function nonNullTypeNodeOf(node) {
    if (node && ts.isUnionTypeNode(node)) {
        return node.types.find((candidate) => !(ts.isLiteralTypeNode(candidate) && candidate.literal.kind === ts.SyntaxKind.NullKeyword) && candidate.kind !== ts.SyntaxKind.UndefinedKeyword);
    }
    return node;
}
function includesNullOrUndefined(type) {
    return type.isUnion() && type.types.some((member) => (member.flags & (ts.TypeFlags.Null | ts.TypeFlags.Undefined)) !== 0);
}
/** Reads the declared instance properties of an exported class, including inherited ones. Undefined when the class is not found. */
function readDeclaredClass(program, filePath, className) {
    const sourceFile = program.getSourceFile((0, file_system_1.toPosixPath)(filePath));
    const declaration = sourceFile ? findExportedClass(sourceFile, className) : undefined;
    if (!sourceFile || !declaration?.name) {
        return undefined;
    }
    const checker = program.getTypeChecker();
    const context = { checker };
    // For a class declaration node the checker answers with the instance type, never undefined.
    const classType = checker.getTypeAtLocation(declaration);
    const extendsExpression = declaration.heritageClauses?.find((clause) => clause.token === ts.SyntaxKind.ExtendsKeyword)?.types[0];
    const baseDeclaration = extendsExpression ? classDeclarationOfType(checker.getTypeAtLocation(extendsExpression.expression)) : undefined;
    const base = baseDeclaration ? identityOf(baseDeclaration) : undefined;
    const properties = [];
    for (const symbol of checker.getPropertiesOfType(classType)) {
        if (symbol.flags & ts.SymbolFlags.Method) {
            continue;
        }
        const propertyDeclaration = symbol.declarations?.find(ts.isPropertyDeclaration);
        if (!propertyDeclaration || propertyDeclaration.modifiers?.some((modifier) => modifier.kind === ts.SyntaxKind.StaticKeyword)) {
            continue;
        }
        const declaredType = checker.getTypeOfSymbolAtLocation(symbol, declaration);
        const nonNullableType = checker.getNonNullableType(declaredType);
        if (nonNullableType.getCallSignatures().length > 0) {
            continue;
        }
        const optional = (symbol.flags & ts.SymbolFlags.Optional) !== 0;
        const printedType = checker.typeToString(declaredType, undefined, ts.TypeFormatFlags.NoTruncation);
        const isArray = checker.isArrayType(nonNullableType);
        const elementType = isArray ? checker.getTypeArguments(nonNullableType)[0] : nonNullableType;
        const scalarFieldType = elementType ? classifyScalarFieldType(elementType) : undefined;
        const property = {
            name: symbol.name,
            optional,
            nullable: includesNullOrUndefined(declaredType),
            isArray,
            typeText: optional ? printedType.replace(/ \| undefined$/, '') : printedType,
            inherited: propertyDeclaration.parent !== declaration,
        };
        if (scalarFieldType !== undefined) {
            property.scalarType = isArray ? (scalarFieldType === 'date' ? undefined : 'multiselect') : scalarFieldType;
        }
        else if (elementType && elementType.flags & ts.TypeFlags.Object) {
            const typeNode = isArray ? elementTypeNodeOf(propertyDeclaration.type) : nonNullTypeNodeOf(propertyDeclaration.type);
            property.target = resolveRelationTarget(context, elementType, typeNode);
        }
        properties.push(property);
    }
    // Base members first, so generated interfaces and configs read top-down like the class hierarchy.
    properties.sort((left, right) => Number(right.inherited) - Number(left.inherited));
    return { className, filePath: (0, file_system_1.toPosixPath)(filePath), base, properties };
}
