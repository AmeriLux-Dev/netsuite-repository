import type { ConditionParamValue, QueryDescription, SeparateLoadDescription } from '../types';
import type { ResultMappingOptions, ResultRow } from './result-mapper';
/** How many parent keys go into one ANY_OF list. */
export declare const defaultSeparateLoadBatchSize = 500;
export interface SeparateLoadRuntime {
    executeDescription(description: QueryDescription): ResultRow[];
    /** The mapping of one relation's rows into its items, with output paths relative to the relation. */
    mappingOptionsFor(load: SeparateLoadDescription): ResultMappingOptions;
    batchSize: number;
    /** The most rows one answer holds; an answer this long may have stopped short. Unset, answers are taken as they come. */
    rowLimit?: number;
}
/** Distinct parent key values in first-seen order; null and undefined are never keys. */
export declare function collectDistinctParentKeys(parents: object[], parentKeyPath: string): ConditionParamValue[];
export declare function batchValues<T>(values: T[], batchSize: number): T[][];
/**
 * Loads every separately loaded relation of the mapped results and stitches the items into their parents: an
 * array for a sublist (empty when the parent has none), an object or null for a subrecord or reference. Parent
 * keys are queried in batches; nested separate relations are loaded from the items the same way.
 */
export declare function loadSeparateRelationsIntoResults(parents: object[], loads: SeparateLoadDescription[], runtime: SeparateLoadRuntime): void;
