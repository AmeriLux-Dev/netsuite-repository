import type * as ts from 'typescript';
import type { ModelFileDiagnostic } from './collect/model-file-evaluator';
import type { BuildConfig } from './config';
import type { FileSystemAdapter } from './file-system';
export interface GenerateOptions {
    config: BuildConfig;
    cwd: string;
    fileSystem: FileSystemAdapter;
    /** Extra compiler options merged over the tsconfig (or defaults); tests use `paths` to resolve the library. */
    compilerOptions?: ts.CompilerOptions;
    version?: string;
}
export interface PlannedFile {
    path: string;
    content: string;
}
export interface GeneratedModelSummary {
    modelName: string;
    setName: string;
    filePath: string;
}
export interface GenerationPlan {
    files: PlannedFile[];
    /** Record types, which own a config, field paths, and a record set. Plain classes only get their interface. */
    models: GeneratedModelSummary[];
    diagnostics: ModelFileDiagnostic[];
}
export interface GenerateResult extends GenerationPlan {
    writtenFiles: string[];
    unchangedFiles: string[];
}
export interface CheckResult extends GenerationPlan {
    driftedFiles: string[];
    missingFiles: string[];
}
export declare function toRecordSetName(modelName: string): string;
/** Where the types file goes: `types.outDir` when set, otherwise next to the other generated files. */
export declare function resolveTypesFilePath(config: BuildConfig, cwd: string): string;
/** Computes every generated file without touching disk. */
export declare function planGeneration(options: GenerateOptions): GenerationPlan;
/** Writes the generated files, skipping any whose content is unchanged. */
export declare function runGenerate(options: GenerateOptions): GenerateResult;
/** Compares the generated files on disk with what generation would produce, without writing. */
export declare function checkGenerated(options: GenerateOptions): CheckResult;
