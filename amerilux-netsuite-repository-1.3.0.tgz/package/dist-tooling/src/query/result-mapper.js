"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.normalizeMappedResultKey = normalizeMappedResultKey;
exports.buildFieldMap = buildFieldMap;
exports.mapRowsToResults = mapRowsToResults;
exports.transformResultValue = transformResultValue;
exports.setValueAtPath = setValueAtPath;
exports.getValueAtPath = getValueAtPath;
const coercion_1 = require("../coercion");
/** N/query keys mapped results by alias; the mapper compares aliases case-insensitively so casing differences never matter. */
function normalizeMappedResultKey(key) {
    return key.toLowerCase();
}
function normalizeRowKeys(row) {
    const normalized = {};
    for (const [key, value] of Object.entries(row)) {
        normalized[normalizeMappedResultKey(key)] = value;
    }
    return normalized;
}
/** Builds the alias → output path map for the fields a query selects. Keys are normalized aliases. */
function buildFieldMap(fields) {
    const map = {};
    for (const [key, field] of fields) {
        map[normalizeMappedResultKey(field.alias ?? key)] = { key, outputPath: field.nestPath ?? key, field };
    }
    return map;
}
function splitPath(path) {
    return path.split('.').filter(Boolean);
}
function isUnderArrayPath(outputPath, arrayPath) {
    return outputPath === arrayPath || outputPath.startsWith(`${arrayPath}.`);
}
function resolveResultMapping(options, parsedDates) {
    const entries = Object.entries(options.fieldMap);
    return {
        recordFields: entries
            .filter(([, mapping]) => !options.arrayPaths.some((arrayPath) => isUnderArrayPath(mapping.outputPath, arrayPath)))
            .map(([alias, mapping]) => ({ alias, pathSegments: splitPath(mapping.outputPath), field: mapping.field })),
        arrayItems: options.arrayPaths.map((arrayPath) => ({
            arrayPath,
            fields: entries
                .filter(([, mapping]) => isUnderArrayPath(mapping.outputPath, arrayPath))
                .map(([alias, mapping]) => ({
                alias,
                pathSegments: splitPath(mapping.outputPath === arrayPath ? mapping.key : mapping.outputPath.slice(arrayPath.length + 1)),
                field: mapping.field,
            })),
        })),
        coerceEnabled: options.coerceEnabled,
        parsedDates,
    };
}
/**
 * Maps result rows into typed objects, grouping fanned-out sublist rows under their parent when array paths exist.
 * The rows share `parsedDates`, so each date text is parsed once; pass one cache to several calls over the same read.
 */
function mapRowsToResults(rows, options, parsedDates = new Map()) {
    if (rows.length === 0) {
        return [];
    }
    const mapping = resolveResultMapping(options, parsedDates);
    const normalizedRows = rows.map(normalizeRowKeys);
    if (options.arrayPaths.length > 0 && options.primaryAlias !== undefined) {
        return mapGroupedRows(normalizedRows, mapping, normalizeMappedResultKey(options.primaryAlias));
    }
    return normalizedRows.map((row) => mapRecordRow(row, mapping));
}
function mapGroupedRows(rows, mapping, primaryAlias) {
    const groups = new Map();
    for (const row of rows) {
        const id = row[primaryAlias];
        if (id === undefined || id === null) {
            continue;
        }
        const group = groups.get(id) ?? [];
        group.push(row);
        groups.set(id, group);
    }
    return Array.from(groups.values()).map((groupRows) => mapRowGroup(groupRows, mapping));
}
function mapRowGroup(rows, mapping) {
    const base = mapRecordRow(rows[0], mapping);
    for (const { arrayPath } of mapping.arrayItems) {
        base[arrayPath] = [];
    }
    const seen = new Set();
    for (const row of rows) {
        for (const { arrayPath, fields } of mapping.arrayItems) {
            const item = buildArrayItem(row, fields, mapping);
            if (!item) {
                continue;
            }
            const key = `${arrayPath}:${JSON.stringify(item)}`;
            if (seen.has(key)) {
                continue;
            }
            seen.add(key);
            base[arrayPath].push(item);
        }
    }
    return base;
}
function mapRecordRow(row, mapping) {
    const output = {};
    for (const { alias, pathSegments, field } of mapping.recordFields) {
        setValueAtPathSegments(output, pathSegments, transformResultValue(row[alias], row, field, mapping.coerceEnabled, mapping.parsedDates));
    }
    return output;
}
function buildArrayItem(row, fields, mapping) {
    const item = {};
    let hasValue = false;
    for (const { alias, pathSegments, field } of fields) {
        const value = transformResultValue(row[alias], row, field, mapping.coerceEnabled, mapping.parsedDates);
        if (value !== null && value !== undefined && value !== '') {
            hasValue = true;
        }
        setValueAtPathSegments(item, pathSegments, value);
    }
    return hasValue ? item : null;
}
/** Coerces a raw value to the field's declared type when coercion is on for it, then applies the field's transform. */
function transformResultValue(value, row, field, coerceEnabled, parsedDates) {
    const shouldCoerce = field.coerce ?? coerceEnabled;
    const coerced = shouldCoerce ? (0, coercion_1.coerceQueryResultValueByFieldType)(value ?? null, field.type, parsedDates) : value ?? null;
    return field.transform ? field.transform(coerced, row) : coerced;
}
/** Writes a value at a dotted path, creating intermediate objects. */
function setValueAtPath(target, path, value) {
    setValueAtPathSegments(target, splitPath(path), value);
}
function setValueAtPathSegments(target, parts, value) {
    let cursor = target;
    for (let index = 0; index < parts.length - 1; index++) {
        const part = parts[index];
        const next = cursor[part];
        if (!next || typeof next !== 'object' || Array.isArray(next)) {
            cursor[part] = {};
        }
        cursor = cursor[part];
    }
    cursor[parts[parts.length - 1]] = value;
}
/** Reads a value at a dotted path; undefined when any segment is missing. */
function getValueAtPath(source, path) {
    let cursor = source;
    for (const part of path.split('.')) {
        if (!cursor || typeof cursor !== 'object') {
            return undefined;
        }
        cursor = cursor[part];
    }
    return cursor;
}
