"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GenerationFailedError = void 0;
exports.netsuiteRepositoryPlugin = netsuiteRepositoryPlugin;
exports.describeGenerateResult = describeGenerateResult;
const config_1 = require("./config");
const file_system_1 = require("./file-system");
const generate_1 = require("./generate");
const watch_1 = require("./watch");
class GenerationFailedError extends Error {
    constructor(result) {
        super(`Model generation reported ${result.diagnostics.length} problem(s):\n${result.diagnostics.map((diagnostic) => ` - ${diagnostic.filePath}${diagnostic.exportName ? ` (${diagnostic.exportName})` : ''}: ${diagnostic.message}`).join('\n')}`);
        this.result = result;
        this.name = 'GenerationFailedError';
    }
}
exports.GenerationFailedError = GenerationFailedError;
function netsuiteRepositoryPlugin(options = {}) {
    const cwd = options.cwd ?? process.cwd();
    const fileSystem = options.fileSystem ?? (0, file_system_1.createNodeFileSystemAdapter)();
    const generate = options.generate ?? generate_1.runGenerate;
    const log = options.log ?? (() => undefined);
    let watcher;
    return {
        name: 'netsuite-repository',
        buildStart() {
            const config = (0, config_1.loadBuildConfig)(fileSystem, cwd, options.configPath);
            const generateOptions = { config, cwd: config.rootDirectory, fileSystem };
            if (options.watch) {
                if (!watcher) {
                    watcher = (0, watch_1.createModelWatcher)({
                        ...generateOptions,
                        generate,
                        onGenerated: (result) => log(describeGenerateResult(result)),
                        onError: (error) => log(`netsuite-repository: ${error instanceof Error ? error.message : String(error)}`),
                    });
                    watcher.start();
                }
                return;
            }
            const result = generate(generateOptions);
            log(describeGenerateResult(result));
            if (result.diagnostics.length > 0) {
                throw new GenerationFailedError(result);
            }
        },
        closeBundle() {
            watcher?.stop();
            watcher = undefined;
        },
    };
}
function describeGenerateResult(result) {
    const lines = [`netsuite-repository: ${result.models.length} model(s), ${result.writtenFiles.length} file(s) written, ${result.unchangedFiles.length} unchanged.`];
    for (const diagnostic of result.diagnostics) {
        lines.push(` - ${diagnostic.filePath}${diagnostic.exportName ? ` (${diagnostic.exportName})` : ''}: ${diagnostic.message}`);
    }
    return lines.join('\n');
}
