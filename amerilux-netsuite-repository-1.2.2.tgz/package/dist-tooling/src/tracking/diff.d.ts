import type { FieldType, QueryConfig, RecordGraphPatch } from '../types';
export interface EntityDiff {
    /** Graph patch for RecordUpdater.patch(); undefined when nothing changed. */
    patch: RecordGraphPatch | undefined;
    /** Field keys that changed but cannot be written (read-only). */
    ignoredProperties: string[];
}
/** Equality that absorbs read-side coercion: '12' equals 12 for numeric fields, 'T' equals true for booleans, dates compare by time. */
export declare function areFieldValuesEqual(left: unknown, right: unknown, fieldType: FieldType | undefined): boolean;
/** Diffs a tracked entity against its snapshot and produces the graph patch describing the changes. */
export declare function diffTrackedEntity(config: QueryConfig<unknown>, snapshot: Record<string, unknown>, current: Record<string, unknown>): EntityDiff;
/** Builds the graph patch for a new entity: every defined writable value plus every collection line as an add. */
export declare function buildAddedEntityPatch(config: QueryConfig<unknown>, current: Record<string, unknown>): EntityDiff;
