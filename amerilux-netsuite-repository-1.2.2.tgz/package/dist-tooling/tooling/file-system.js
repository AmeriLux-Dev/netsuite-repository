"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.toPosixPath = toPosixPath;
exports.matchesGlob = matchesGlob;
exports.globBaseDirectory = globBaseDirectory;
exports.resolveGlobs = resolveGlobs;
exports.createNodeFileSystemAdapter = createNodeFileSystemAdapter;
exports.createInMemoryFileSystemAdapter = createInMemoryFileSystemAdapter;
const nodeFileSystem = __importStar(require("fs"));
const nodePath = __importStar(require("path"));
function toPosixPath(filePath) {
    return filePath.replace(/\\/g, '/');
}
function globToRegularExpression(pattern) {
    let expression = '';
    for (let index = 0; index < pattern.length; index++) {
        const character = pattern[index];
        if (character === '*') {
            if (pattern[index + 1] === '*') {
                const followedBySlash = pattern[index + 2] === '/';
                expression += followedBySlash ? '(?:.*/)?' : '.*';
                index += followedBySlash ? 2 : 1;
            }
            else {
                expression += '[^/]*';
            }
        }
        else if (character === '?') {
            expression += '[^/]';
        }
        else if ('.+^${}()|[]\\'.includes(character)) {
            expression += `\\${character}`;
        }
        else {
            expression += character;
        }
    }
    return new RegExp(`^${expression}$`);
}
/** Matches a relative POSIX path against a glob supporting `**`, `*`, and `?`. */
function matchesGlob(pattern, relativePath) {
    return globToRegularExpression(toPosixPath(pattern)).test(toPosixPath(relativePath));
}
/** The folder a glob starts from: its segments up to the first one with a wildcard. */
function globBaseDirectory(pattern) {
    const segments = toPosixPath(pattern).split('/');
    const baseSegments = [];
    for (const segment of segments) {
        if (/[*?]/.test(segment)) {
            break;
        }
        baseSegments.push(segment);
    }
    return baseSegments.join('/');
}
/** Resolves glob patterns (relative to cwd) to sorted absolute file paths. Patterns starting with `!` exclude. */
function resolveGlobs(fileSystem, cwd, patterns) {
    const includes = patterns.filter((pattern) => !pattern.startsWith('!'));
    const excludes = patterns.filter((pattern) => pattern.startsWith('!')).map((pattern) => pattern.slice(1));
    const matches = new Set();
    for (const pattern of includes) {
        const baseDirectory = nodePath.resolve(cwd, globBaseDirectory(pattern));
        for (const filePath of fileSystem.listFiles(baseDirectory)) {
            const relativePath = toPosixPath(nodePath.relative(cwd, filePath));
            if (matchesGlob(pattern, relativePath) && !excludes.some((exclude) => matchesGlob(exclude, relativePath))) {
                matches.add(filePath);
            }
        }
    }
    return Array.from(matches).sort();
}
function createNodeFileSystemAdapter() {
    const listFiles = (directoryPath) => {
        if (!nodeFileSystem.existsSync(directoryPath)) {
            return [];
        }
        if (!nodeFileSystem.statSync(directoryPath).isDirectory()) {
            return [directoryPath];
        }
        return nodeFileSystem.readdirSync(directoryPath, { withFileTypes: true }).flatMap((entry) => {
            const fullPath = nodePath.join(directoryPath, entry.name);
            return entry.isDirectory() ? listFiles(fullPath) : [fullPath];
        });
    };
    return {
        readTextFile: (filePath) => nodeFileSystem.readFileSync(filePath, 'utf8'),
        writeTextFile: (filePath, content) => nodeFileSystem.writeFileSync(filePath, content, 'utf8'),
        fileExists: (filePath) => nodeFileSystem.existsSync(filePath),
        ensureDirectory: (directoryPath) => nodeFileSystem.mkdirSync(directoryPath, { recursive: true }),
        listFiles,
        watch: (paths, onChange) => {
            const watchers = paths
                .filter((watchedPath) => nodeFileSystem.existsSync(watchedPath))
                .map((watchedPath) => nodeFileSystem.watch(watchedPath, { recursive: true }, (_eventType, fileName) => {
                onChange(fileName ? nodePath.join(watchedPath, String(fileName)) : watchedPath);
            }));
            return () => watchers.forEach((watcher) => watcher.close());
        },
    };
}
function normalizeKey(filePath) {
    return toPosixPath(nodePath.resolve(filePath));
}
function createInMemoryFileSystemAdapter(initialFiles = {}) {
    const files = new Map();
    const directories = new Set();
    const listeners = new Set();
    for (const [filePath, content] of Object.entries(initialFiles)) {
        files.set(normalizeKey(filePath), content);
    }
    return {
        files,
        readTextFile: (filePath) => {
            const content = files.get(normalizeKey(filePath));
            if (content === undefined) {
                throw new Error(`File not found: ${filePath}`);
            }
            return content;
        },
        writeTextFile: (filePath, content) => {
            files.set(normalizeKey(filePath), content);
        },
        fileExists: (filePath) => files.has(normalizeKey(filePath)) || directories.has(normalizeKey(filePath)),
        ensureDirectory: (directoryPath) => {
            directories.add(normalizeKey(directoryPath));
        },
        listFiles: (directoryPath) => {
            const key = normalizeKey(directoryPath);
            if (files.has(key)) {
                return [key];
            }
            const prefix = `${key}/`;
            return Array.from(files.keys()).filter((filePath) => filePath.startsWith(prefix)).sort();
        },
        watch: (_paths, onChange) => {
            listeners.add(onChange);
            return () => listeners.delete(onChange);
        },
        emitChange: (changedPath) => {
            listeners.forEach((listener) => listener(changedPath));
        },
    };
}
