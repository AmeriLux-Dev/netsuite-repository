import type { QueryConfig } from '../types';
import type { EntityModelMetadata } from './metadata';
export declare class ModelValidationError extends Error {
    readonly entityName: string;
    readonly problems: string[];
    constructor(entityName: string, problems: string[]);
}
/**
 * Turns authoring-surface metadata into the QueryConfig the runtime consumes.
 * Both decorators and the fluent API produce EntityModelMetadata, so this is the only place a config is derived.
 */
export declare function compileEntityModel<TResult = unknown>(metadata: EntityModelMetadata): QueryConfig<TResult>;
