export declare const LIBRARY_PACKAGE_NAME = "@amerilux/netsuite-repository";
/** Finds the library's own package.json version by walking up from this file. Falls back to 'unknown'. */
export declare function readGeneratorVersion(startDirectory?: string, readFile?: (filePath: string) => string | undefined): string;
export declare function buildGeneratedFileHeader(description: string, version?: string): string;
