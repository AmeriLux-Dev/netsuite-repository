"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.QueryBuilder = exports.parentKeyAlias = exports.maximumPageSize = exports.minimumPageSize = void 0;
exports.query = query;
exports.runQuery = runQuery;
const resolve_1 = require("../model/resolve");
const condition_nodes_1 = require("./condition-nodes");
const n_query_compiler_1 = require("./n-query-compiler");
const operator_translation_1 = require("./operator-translation");
const query_description_1 = require("./query-description");
const read_on_1 = require("./read-on");
const result_mapper_1 = require("./result-mapper");
const separate_relation_loader_1 = require("./separate-relation-loader");
function getNsQuery() {
    return require('N/query');
}
/** The page sizes N/query accepts for runPaged. */
exports.minimumPageSize = 5;
exports.maximumPageSize = 1000;
/** Alias of the column a separate query adds to carry the parent key back. */
exports.parentKeyAlias = '__parentKey';
/**
 * Runs a step against N/query and, when it fails, rethrows with the rendered query appended: NetSuite's message
 * names the problem ("Operator EQUAL is not valid for given search filter") but never the query.
 */
function withQueryInError(description, step) {
    try {
        return step();
    }
    catch (error) {
        // Not N/query's failure: the guard's, which callers catch by its type.
        if (error instanceof read_on_1.GovernanceLimitError) {
            throw error;
        }
        const failure = error;
        const message = failure && typeof failure.message === 'string' ? failure.message : String(error);
        const named = failure && typeof failure.name === 'string' && failure.name !== 'Error' ? `${failure.name}: ${message}` : message;
        const wrapped = new Error(`${named}\nQuery:\n${(0, query_description_1.renderQueryDescription)(description)}`);
        wrapped.cause = error;
        throw wrapped;
    }
}
function omitUndefined(value) {
    const result = {};
    for (const [key, entry] of Object.entries(value)) {
        if (entry !== undefined) {
            result[key] = entry;
        }
    }
    return result;
}
class QueryBuilder {
    constructor(config, options = {}) {
        this.trackingDisabled = false;
        this.selectedKeys = null;
        this.formulaSelections = new Map();
        this.conditions = [];
        this.sorts = [];
        this.includedRelationships = new Set();
        this.excludedRelationships = new Set();
        this.config = config;
        this.options = options;
        this.coerceEnabled = config.coerce ?? false;
    }
    static from(config, options = {}) {
        return new QueryBuilder((0, resolve_1.resolveQueryConfig)(config), options);
    }
    // ── projection ────────────────────────────────────────────────────────────
    /** Loads a reference, subrecord, or sublist that is not selected by default (EF Include). */
    include(...relationships) {
        for (const name of relationships) {
            this.assertRelationship(name);
            this.includedRelationships.add(name);
            this.excludedRelationships.delete(name);
        }
        return this;
    }
    /** Leaves a reference, subrecord, or sublist and its joins out of this query. */
    exclude(...relationships) {
        for (const name of relationships) {
            this.assertRelationship(name);
            this.excludedRelationships.add(name);
            this.includedRelationships.delete(name);
        }
        return this;
    }
    /** Results of this query are not registered with the owning context (EF AsNoTracking). */
    asNoTracking() {
        this.trackingDisabled = true;
        return this;
    }
    select(...keys) {
        if (!this.selectedKeys) {
            this.selectedKeys = new Set();
        }
        for (const key of keys) {
            this.selectedKeys.add(this.normalizeFieldKey(String(key)));
        }
        return this;
    }
    selectAll() {
        this.selectedKeys = null;
        return this;
    }
    /**
     * Adds a formula column (N/query `{fieldid}` syntax) mapped onto the result under `alias`, usable in where()
     * and orderBy() by that alias. The only way to read a value the model does not declare.
     */
    selectFormula(formula, alias, options = {}) {
        if (this.config.fields[alias] || this.formulaSelections.has(alias)) {
            throw new Error(`Alias '${alias}' is already used by a field in query config for '${this.config.recordType}'.`);
        }
        this.formulaSelections.set(alias, omitUndefined({
            queryFieldId: alias,
            alias,
            formula,
            formulaType: options.type,
            type: options.fieldType,
            nestPath: options.nestPath,
            coerce: options.coerce,
            transform: options.transform,
        }));
        return this;
    }
    where(field, operator, value, useText = false) {
        return this.addWhere('AND', String(field), operator, value, useText);
    }
    orWhere(field, operator, value, useText = false) {
        return this.addWhere('OR', String(field), operator, value, useText);
    }
    /** Adds an AND condition written as an N/query formula (`{trandate} > SYSDATE - 30`). Values are part of the formula text. */
    whereFormula(formula, type = 'BOOLEAN', operator, value) {
        return this.addFormulaCondition('AND', formula, type, operator, value);
    }
    orWhereFormula(formula, type = 'BOOLEAN', operator, value) {
        return this.addFormulaCondition('OR', formula, type, operator, value);
    }
    /** IN over a text or numeric field; skipped when the list is empty or undefined. */
    whereIn(field, values) {
        return values && values.length > 0 ? this.addWhere('AND', String(field), 'IN', values) : this;
    }
    /** NOT IN over a text or numeric field; skipped when the list is empty or undefined. */
    whereNotIn(field, values) {
        return values && values.length > 0 ? this.addWhere('AND', String(field), 'NOT IN', values) : this;
    }
    whereNull(field) {
        return this.addWhere('AND', String(field), 'IS NULL');
    }
    whereNotNull(field) {
        return this.addWhere('AND', String(field), 'IS NOT NULL');
    }
    /** BETWEEN over a numeric or date field; skipped when either bound is undefined. */
    whereBetween(field, min, max) {
        return min === undefined || max === undefined ? this : this.addWhere('AND', String(field), 'BETWEEN', [min, max]);
    }
    whereGroup(callback) {
        return this.addWhereGroup('AND', callback);
    }
    orWhereGroup(callback) {
        return this.addWhereGroup('OR', callback);
    }
    // ── ordering and paging ───────────────────────────────────────────────────
    orderBy(field, direction = 'ASC') {
        const { key, field: resolved } = this.resolveField(String(field));
        const sort = resolved.formula !== undefined
            ? omitUndefined({ formula: resolved.formula, formulaType: resolved.formulaType, ascending: direction === 'ASC' })
            : omitUndefined({ component: resolved.component, fieldId: resolved.queryFieldId, context: resolved.fieldContext, ascending: direction === 'ASC' });
        this.sorts.push(omitUndefined({ sort, relationship: this.separateRelationshipOf(key, resolved), key, readOn: this.readOnFor(resolved) }));
        return this;
    }
    /** How a read picks up after a sort on this field: formulas and display text have no comparison a probe checked. */
    readOnFor(field) {
        if (field.formula !== undefined || field.fieldContext === 'DISPLAY') {
            return undefined;
        }
        const fieldType = field.isPrimary ? 'key' : field.type;
        const comparison = (0, read_on_1.readOnComparisonFor)(fieldType);
        return comparison === undefined || fieldType === undefined ? undefined : { comparison, fieldType, isPrimary: Boolean(field.isPrimary) };
    }
    orderByAsc(field) {
        return this.orderBy(field, 'ASC');
    }
    orderByDesc(field) {
        return this.orderBy(field, 'DESC');
    }
    limit(count) {
        this.limitValue = Math.max(0, Math.floor(count));
        return this;
    }
    offset(count) {
        this.offsetValue = Math.max(0, Math.floor(count));
        return this;
    }
    page(pageNumber, pageSize) {
        const safePage = Math.max(1, Math.floor(pageNumber));
        const safePageSize = Math.max(1, Math.floor(pageSize));
        this.limitValue = safePageSize;
        this.offsetValue = (safePage - 1) * safePageSize;
        return this;
    }
    /** Enables or disables read-side coercion of values to their declared field types for this query. */
    coerce(enabled = true) {
        this.coerceEnabled = enabled;
        return this;
    }
    // ── execution ─────────────────────────────────────────────────────────────
    /** What this query asks N/query for, as plain data. */
    describe() {
        return this.plan(true).description;
    }
    /** The description rendered as stable text, for logs and tests. */
    describeText() {
        return (0, query_description_1.renderQueryDescription)(this.describe());
    }
    execute() {
        const plan = this.plan(true);
        return { data: this.readRows(plan), query: plan.description };
    }
    executeRaw() {
        return this.execute().data;
    }
    executeTyped() {
        const fansOut = this.plan(false).mapping.arrayPaths.length > 0;
        // Joined sublists fan rows out, so a row window would cut records short; those queries page over mapped records instead.
        const plan = this.plan(!fansOut);
        return this.buildTypedResults(this.readRows(plan), plan, fansOut && this.hasPageWindow());
    }
    /**
     * One page of the typed results, read across requests: up to `limit` records after the page `after` names, and
     * `next` to name this one. Each page picks up after the last record by its sort values, so a record changed
     * between two pages cannot shift the rest; a page larger than N/query's 5,000-row answer is read on in several.
     * When the script cannot afford another read, the page stops early and `next` says where. Needs every sort to be
     * one a read can compare (the id, numbers, dates, text) and no joined sublist, which answers a row per line.
     */
    executeTypedPage(options) {
        const { limit } = options;
        if (!Number.isInteger(limit) || limit < 1) {
            throw new Error(`A page needs a limit of at least one record; it was given ${limit}.`);
        }
        const plan = this.plan(false);
        if (plan.mapping.arrayPaths.length > 0) {
            throw new Error(`A page picks up after its last record, and ${plan.mapping.arrayPaths.join(', ')} of '${this.config.recordType}' is a joined sublist that answers a row per line: load it separately (load: 'separate') to page these records.`);
        }
        const keys = plan.readOnKeys;
        if (!keys) {
            throw new Error(`A page picks up after its last record by its sort values, and ${plan.readOnObstacle}: sort by the id, a number, a date or text to page these records.`);
        }
        const governance = new read_on_1.ReadGovernance(this.governanceReserve());
        let afterValues = options.after === undefined || options.after === null ? undefined : (0, read_on_1.decodeReadOnMarker)(options.after, keys);
        const rows = [];
        let hasMore;
        for (;;) {
            const description = afterValues === undefined ? plan.description : (0, read_on_1.withAddedCondition)(plan.description, (0, read_on_1.buildAfterRowCondition)(keys, afterValues));
            const answer = governance.measure(() => this.executeDescription(description));
            const wanted = limit - rows.length;
            rows.push(...answer.slice(0, wanted));
            if (answer.length > wanted) {
                hasMore = true;
                break;
            }
            if (answer.length < read_on_1.runRowLimit) {
                hasMore = false;
                break;
            }
            if (rows.length === limit || governance.shortfall()) {
                hasMore = true;
                break;
            }
            afterValues = (0, read_on_1.readKeyValues)(keys, answer[answer.length - 1]);
        }
        return {
            items: this.buildTypedResults(rows, plan, false),
            next: hasMore && rows.length > 0 ? (0, read_on_1.encodeReadOnMarker)((0, read_on_1.readKeyValues)(keys, rows[rows.length - 1])) : null,
        };
    }
    /** Rows into typed results: mapped, cut to the page window when rows fanned out, related records loaded, tracked. */
    buildTypedResults(rows, plan, sliceWindow) {
        let results = (0, result_mapper_1.mapRowsToResults)(rows, plan.mapping);
        if (sliceWindow) {
            const offset = this.offsetValue ?? 0;
            results = results.slice(offset, this.limitValue === undefined ? undefined : offset + this.limitValue);
        }
        this.loadSeparateRelations(results, plan);
        const { postProcess } = this.config;
        const finalResults = postProcess ? results.map((row) => postProcess(row) ?? row) : results;
        return this.trackingDisabled || !this.options.resultObserver ? finalResults : this.options.resultObserver(finalResults);
    }
    /** Runs the query through N/query's paging and hands the pages back untouched. */
    executePaged(options = {}) {
        const query = (0, n_query_compiler_1.compileQueryDescriptionToNQuery)(this.plan(false).description, getNsQuery());
        return query.runPaged({ pageSize: Math.min(exports.maximumPageSize, Math.max(exports.minimumPageSize, options.pageSize ?? exports.maximumPageSize)) });
    }
    first() {
        return this.withLimit(1, () => this.executeRaw()[0] ?? null);
    }
    firstTyped() {
        return this.withLimit(1, () => this.executeTyped()[0] ?? null);
    }
    /** Counts records, not rows: with a joined sublist the primary key is counted distinct. */
    count() {
        const plan = this.plan(false);
        const primary = this.primaryField();
        if (!primary) {
            throw new Error(`A primary key field is required to count '${this.config.recordType}'.`);
        }
        const description = {
            ...plan.description,
            columns: [{ alias: 'count', fieldId: primary.field.queryFieldId, aggregate: plan.description.components.length > 0 ? 'COUNT_DISTINCT' : 'COUNT' }],
            sort: [],
            separateLoads: [],
        };
        const rows = this.executeDescription(description);
        return Number(rows[0]?.count ?? 0);
    }
    exists() {
        return this.withLimit(1, () => this.executeRaw().length > 0);
    }
    /** The SuiteQL NetSuite renders for this query, for debugging. Costs nothing; nothing executes. */
    toSQL() {
        const description = this.plan(true).description;
        return withQueryInError(description, () => (0, n_query_compiler_1.compileQueryDescriptionToNQuery)(description, getNsQuery()).toSuiteQL().query);
    }
    // ── planning ──────────────────────────────────────────────────────────────
    plan(includePage) {
        const activeFields = this.collectSelectableFields();
        const separateRelationships = this.activeSeparateRelationships();
        const mainFields = activeFields.filter(([key, field]) => !separateRelationships.has(this.relationshipOf(key, field) ?? ''));
        const mainConditions = this.conditions.filter((condition) => condition.relationship === undefined);
        const mainSorts = this.withPrimaryKeySort(this.sorts.filter((sort) => sort.relationship === undefined));
        const components = this.collectComponents(mainFields, mainConditions.map((condition) => condition.node), mainSorts.map((sort) => sort.sort));
        const columns = mainFields.map(([key, field]) => this.toColumn(key, field));
        if (columns.length === 0) {
            throw new Error('At least one selectable field is required.');
        }
        const separateMappings = new Map();
        const separateLoads = [];
        for (const relationship of separateRelationships) {
            const relationFields = activeFields.filter(([key, field]) => this.relationshipOf(key, field) === relationship);
            if (relationFields.length === 0) {
                continue;
            }
            const { load, mapping } = this.planSeparateLoad(relationship, relationFields);
            separateLoads.push(load);
            separateMappings.set(relationship, mapping);
        }
        const description = omitUndefined({
            queryType: this.config.queryType ?? this.config.recordType,
            components,
            columns,
            condition: this.combineWithRootConditions((0, condition_nodes_1.combineConditions)(mainConditions)),
            sort: mainSorts.map((sort) => sort.sort),
            page: includePage ? this.pageWindow() : undefined,
            separateLoads,
        });
        return {
            description,
            mapping: this.mappingOptions(mainFields, this.primaryAlias()),
            separateMappings,
            ...this.planReadOn(mainSorts, description),
        };
    }
    /**
     * The query's own sorts, then the internal id: a complete order, so a read past N/query's 5,000-row answer can pick
     * up after the last row, and rows that tie on the sorts never change places between reads. Nothing is added when
     * the id is sorted on already.
     */
    withPrimaryKeySort(sorts) {
        const primary = this.primaryField();
        if (!primary || sorts.some((sort) => sort.readOn?.isPrimary)) {
            return sorts;
        }
        const sort = omitUndefined({ component: primary.field.component, fieldId: primary.field.queryFieldId, ascending: true });
        return [...sorts, { sort, key: primary.key, readOn: { comparison: 'ordered', fieldType: 'key', isPrimary: true } }];
    }
    /** The sorts a read picks up after, up to the internal id, which completes the order; or why there are none. */
    planReadOn(sorts, description) {
        const primaryIndex = sorts.findIndex((sort) => sort.readOn?.isPrimary);
        if (primaryIndex === -1) {
            return { readOnObstacle: `'${this.config.recordType}' declares no internal id to read on by` };
        }
        const keySorts = sorts.slice(0, primaryIndex + 1);
        const uncomparable = keySorts.filter((sort) => sort.readOn === undefined).map((sort) => sort.key);
        if (uncomparable.length > 0) {
            return { readOnObstacle: `'${this.config.recordType}' is sorted by ${uncomparable.join(', ')}, which no read can compare (select fields, checkboxes, datetimes, display text and formulas)` };
        }
        const aliases = (0, n_query_compiler_1.sortColumnAliases)(description);
        return { readOnKeys: keySorts.map((sort, index) => ({ sort: sort.sort, alias: aliases[index], ...sort.readOn })) };
    }
    planSeparateLoad(relationship, relationFields) {
        const component = this.config.components?.[relationship];
        const kind = this.config.relationships?.[relationship]?.kind;
        if (!component) {
            throw new Error(`Relationship '${relationship}' has no component in query config for '${this.config.recordType}'.`);
        }
        const conditions = this.conditions.filter((condition) => condition.relationship === relationship);
        const sorts = this.sorts.filter((sort) => sort.relationship === relationship).map((sort) => sort.sort);
        const relationComponents = Object.values(this.config.components ?? {}).filter((candidate) => candidate.path === relationship || candidate.path.startsWith(`${relationship}.`));
        if (kind === 'reference') {
            const separate = component.separate;
            if (!separate) {
                throw new Error(`Reference '${relationship}' is loaded separately but declares no separate load in query config for '${this.config.recordType}'.`);
            }
            const parentKeyField = this.config.fields[separate.parentKeyField];
            const reroot = (path) => (path === relationship ? undefined : path);
            const nested = relationComponents.filter((candidate) => candidate.path !== relationship);
            const columns = [
                ...relationFields.map(([key, field]) => omitUndefined({ ...this.toColumn(key, field), component: reroot(field.component) })),
                { alias: exports.parentKeyAlias, fieldId: separate.targetKeyFieldId },
            ];
            const description = omitUndefined({
                queryType: separate.queryType,
                components: this.orderComponents(nested).map((candidate) => omitUndefined({ ...this.toDescribedComponent(candidate), parent: reroot(candidate.parent) })),
                columns,
                condition: (0, condition_nodes_1.combineConditions)(conditions.map((condition) => ({ ...condition, node: (0, condition_nodes_1.rerootConditionNode)(condition.node, relationship) }))),
                sort: sorts.map((sort) => omitUndefined({ ...sort, component: reroot(sort.component) })),
            });
            return {
                load: { relationship, kind, description, parentKeyPath: parentKeyField.nestPath ?? separate.parentKeyField, batchFieldId: separate.targetKeyFieldId, batchFieldType: separate.targetKeyFieldType ?? 'key', parentKeyAlias: exports.parentKeyAlias },
                mapping: this.relationMappingOptions(relationship, relationFields, kind),
            };
        }
        const primary = this.primaryField();
        if (!primary) {
            throw new Error(`A primary key field is required to load '${relationship}' separately on '${this.config.recordType}'.`);
        }
        // A has-many joined `from` a field on the child (its @ParentId() field) runs on the child's own type when loaded
        // separately: the rows are the items, so the relation's fields, conditions, sorts, and nested components are
        // rerooted at the child, the sublist filter becomes a root condition, and each batch matches the child's parent
        // field against the owners' keys.
        if (component.separate && component.join.kind === 'from') {
            const separate = component.separate;
            const parentKeyField = this.config.fields[separate.parentKeyField] ?? primary.field;
            const reroot = (path) => (path === relationship ? undefined : path);
            const nested = relationComponents.filter((candidate) => candidate.path !== relationship);
            const columns = [
                ...relationFields.map(([key, field]) => omitUndefined({ ...this.toColumn(key, field), component: reroot(field.component) })),
                { alias: exports.parentKeyAlias, fieldId: separate.targetKeyFieldId },
            ];
            const filterNodes = (component.conditions ?? []).map((condition) => omitUndefined({ kind: 'field', fieldId: condition.fieldId, operator: condition.operator, values: condition.values }));
            const userCondition = (0, condition_nodes_1.combineConditions)(conditions.map((condition) => ({ ...condition, node: (0, condition_nodes_1.rerootConditionNode)(condition.node, relationship) })));
            const conditionNodes = [...filterNodes, ...(userCondition ? [userCondition] : [])];
            const defaultSort = component.lineOrderFieldId ? [{ fieldId: component.lineOrderFieldId, ascending: true }] : [];
            const description = omitUndefined({
                queryType: separate.queryType,
                components: this.orderComponents(nested).map((candidate) => omitUndefined({ ...this.toDescribedComponent(candidate), parent: reroot(candidate.parent) })),
                columns,
                condition: conditionNodes.length === 0 ? undefined : conditionNodes.length === 1 ? conditionNodes[0] : { kind: 'and', nodes: conditionNodes },
                sort: (sorts.length > 0 ? sorts : defaultSort).map((sort) => omitUndefined({ ...sort, component: reroot(sort.component) })),
            });
            return {
                load: { relationship, kind, description, parentKeyPath: parentKeyField.nestPath ?? separate.parentKeyField, batchFieldId: separate.targetKeyFieldId, batchFieldType: separate.targetKeyFieldType ?? 'select', parentKeyAlias: exports.parentKeyAlias },
                mapping: this.relationMappingOptions(relationship, relationFields, kind),
            };
        }
        // A sublist may run its own query on another root (a sales order's lines hang off `transaction`); it then matches
        // the owner by internal id and the owner's root conditions do not apply.
        const ownRoot = component.separate;
        const batchFieldId = ownRoot?.targetKeyFieldId ?? primary.field.queryFieldId;
        const columns = [...relationFields.map(([key, field]) => this.toColumn(key, field)), { alias: exports.parentKeyAlias, fieldId: batchFieldId }];
        const defaultSort = component.lineOrderFieldId ? [{ component: relationship, fieldId: component.lineOrderFieldId, ascending: true }] : [];
        const description = omitUndefined({
            queryType: ownRoot?.queryType ?? this.config.queryType ?? this.config.recordType,
            components: this.orderComponents(relationComponents).map((candidate) => this.toDescribedComponent(candidate)),
            columns,
            condition: ownRoot ? (0, condition_nodes_1.combineConditions)(conditions) : this.combineWithRootConditions((0, condition_nodes_1.combineConditions)(conditions)),
            sort: sorts.length > 0 ? sorts : defaultSort,
        });
        return {
            load: { relationship, kind, description, parentKeyPath: primary.field.nestPath ?? primary.key, batchFieldId, batchFieldType: ownRoot?.targetKeyFieldType ?? 'key', parentKeyAlias: exports.parentKeyAlias },
            mapping: this.relationMappingOptions(relationship, relationFields, kind),
        };
    }
    /** Output paths inside a separately loaded relation are relative to it; a sublist's rows are its items, so nothing groups. */
    relationMappingOptions(relationship, relationFields, kind) {
        const prefix = `${relationship}.`;
        const relativeFields = relationFields.map(([key, field]) => [key, { ...field, nestPath: (field.nestPath ?? key).slice(prefix.length) }]);
        const arrayPaths = kind === 'sublist' ? [] : this.arrayPathsOf(relativeFields);
        return { fieldMap: (0, result_mapper_1.buildFieldMap)(relativeFields), arrayPaths, primaryAlias: arrayPaths.length > 0 ? exports.parentKeyAlias : undefined, coerceEnabled: this.coerceEnabled };
    }
    mappingOptions(fields, primaryAlias) {
        return { fieldMap: (0, result_mapper_1.buildFieldMap)(fields), arrayPaths: this.arrayPathsOf(fields), primaryAlias, coerceEnabled: this.coerceEnabled };
    }
    arrayPathsOf(fields) {
        const paths = new Set();
        for (const [key, field] of fields) {
            if (field.cardinality === 'many') {
                paths.add((field.nestPath ?? key).split('.')[0]);
            }
        }
        return Array.from(paths);
    }
    toColumn(key, field) {
        if (field.formula !== undefined) {
            return omitUndefined({ alias: field.alias ?? key, formula: field.formula, formulaType: field.formulaType });
        }
        return omitUndefined({ alias: field.alias ?? key, component: field.component, fieldId: field.queryFieldId, context: field.fieldContext });
    }
    toDescribedComponent(component) {
        return omitUndefined({ path: component.path, parent: component.parent, join: component.join, conditions: component.conditions ?? [] });
    }
    /** The components the main query joins: those a selected column, condition, or sort reads, plus their ancestors. */
    collectComponents(fields, conditions, sorts) {
        const wanted = new Set();
        for (const [, field] of fields) {
            if (field.component !== undefined)
                wanted.add(field.component);
        }
        conditions.forEach((node) => (0, condition_nodes_1.collectConditionComponents)(node, wanted));
        for (const sort of sorts) {
            if (sort.component !== undefined)
                wanted.add(sort.component);
        }
        const withAncestors = new Set();
        for (const path of wanted) {
            let current = path;
            while (current !== undefined) {
                withAncestors.add(current);
                const component = this.config.components?.[current];
                if (!component) {
                    throw new Error(`Component '${current}' is not defined in query config for '${this.config.recordType}'.`);
                }
                current = component.parent;
            }
        }
        return this.orderComponents(Array.from(withAncestors).map((path) => this.config.components?.[path])).map((component) => this.toDescribedComponent(component));
    }
    /**
     * Parents before children. Depth is the length of the parent chain, which the path need not spell: a reference
     * joined from a field read through a relationship (`subsidiary`) hangs off that relationship's component
     * (`transactionlines`), not off the root.
     */
    orderComponents(components) {
        const depthOf = (component) => {
            let depth = 0;
            for (let parent = component.parent; parent !== undefined; parent = this.config.components?.[parent]?.parent) {
                depth += 1;
            }
            return depth;
        };
        return [...components].sort((left, right) => depthOf(left) - depthOf(right) || left.path.localeCompare(right.path));
    }
    combineWithRootConditions(userCondition) {
        const rootNodes = (this.config.rootConditions ?? []).map((condition) => omitUndefined({ kind: 'field', fieldId: condition.fieldId, operator: condition.operator, values: condition.values }));
        const nodes = userCondition ? [...rootNodes, userCondition] : rootNodes;
        return nodes.length === 0 ? undefined : nodes.length === 1 ? nodes[0] : { kind: 'and', nodes };
    }
    pageWindow() {
        return this.hasPageWindow() ? omitUndefined({ offset: this.offsetValue ?? 0, limit: this.limitValue }) : undefined;
    }
    hasPageWindow() {
        return this.limitValue !== undefined || Boolean(this.offsetValue);
    }
    withLimit(limit, run) {
        const originalLimit = this.limitValue;
        this.limitValue = limit;
        try {
            return run();
        }
        finally {
            this.limitValue = originalLimit;
        }
    }
    // ── running ───────────────────────────────────────────────────────────────
    /** The plan's rows: its page window when it has one, otherwise every row, past N/query's 5,000-row answer. */
    readRows(plan) {
        return plan.description.page ? this.executeDescription(plan.description) : this.readEveryRow(plan);
    }
    /**
     * Every row the query matches. One run() answers most queries whole; an answer of 5,000 rows may have stopped
     * short, so the rows after its last one are read the same way until an answer comes back shorter. A query no read
     * can pick up after (a sort no probe compared, a joined sublist's rows, no internal id) is read again through
     * runPaged instead, a thousand rows a fetch.
     */
    readEveryRow(plan) {
        const governance = new read_on_1.ReadGovernance(this.governanceReserve());
        const firstAnswer = governance.measure(() => this.executeDescription(plan.description));
        if (firstAnswer.length < read_on_1.runRowLimit) {
            return firstAnswer;
        }
        const keys = plan.mapping.arrayPaths.length > 0 ? undefined : plan.readOnKeys;
        return keys ? this.readOnAfterLastRow(plan.description, keys, firstAnswer, governance) : this.readEveryPage(plan.description, governance);
    }
    readOnAfterLastRow(description, keys, firstAnswer, governance) {
        const rows = [...firstAnswer];
        let answer = firstAnswer;
        while (answer.length >= read_on_1.runRowLimit) {
            this.assertAnotherReadAffordable(governance, rows.length);
            const after = (0, read_on_1.buildAfterRowCondition)(keys, (0, read_on_1.readKeyValues)(keys, answer[answer.length - 1]));
            answer = governance.measure(() => this.executeDescription((0, read_on_1.withAddedCondition)(description, after)));
            rows.push(...answer);
        }
        return rows;
    }
    /** Every row in the query's own order through runPaged, a thousand a fetch. */
    readEveryPage(description, governance) {
        return withQueryInError(description, () => {
            const query = (0, n_query_compiler_1.compileQueryDescriptionToNQuery)(description, getNsQuery());
            const paged = governance.measure(() => query.runPaged({ pageSize: exports.maximumPageSize }));
            const rows = [];
            for (const range of paged.pageRanges) {
                this.assertAnotherReadAffordable(governance, rows.length);
                rows.push(...governance.measure(() => paged.fetch({ index: range.index }).data.asMappedResults()));
            }
            return rows;
        });
    }
    assertAnotherReadAffordable(governance, rowsRead) {
        const shortfall = governance.shortfall();
        if (shortfall) {
            throw new read_on_1.GovernanceLimitError(`Reading '${this.config.recordType}' stopped after ${rowsRead} rows: another read costs about ${shortfall.readCost} units, and ${shortfall.remainingUsage} are left with ${governance.reserve} held back for the script. Narrow the query, or read it a page at a time with listPage().`, rowsRead, shortfall.remainingUsage, shortfall.readCost, governance.reserve);
        }
    }
    governanceReserve() {
        return this.options.governanceReserve ?? read_on_1.defaultGovernanceReserve;
    }
    executeDescription(description) {
        return withQueryInError(description, () => {
            const query = (0, n_query_compiler_1.compileQueryDescriptionToNQuery)(description, getNsQuery());
            if (!description.page) {
                return query.run().asMappedResults();
            }
            return this.runPageWindow(query, description.page);
        });
    }
    /** Reads a row window through runPaged: pages are sized to the window, fetched from the first page that overlaps it, and sliced. */
    runPageWindow(query, page) {
        const pageSize = Math.min(exports.maximumPageSize, Math.max(exports.minimumPageSize, page.limit ?? exports.maximumPageSize));
        const firstPageIndex = Math.floor(page.offset / pageSize);
        const skip = page.offset - firstPageIndex * pageSize;
        const paged = query.runPaged({ pageSize });
        const rows = [];
        for (let index = firstPageIndex; index < paged.pageRanges.length; index += 1) {
            const fetched = paged.fetch({ index });
            rows.push(...fetched.data.asMappedResults());
            if ((page.limit !== undefined && rows.length >= skip + page.limit) || fetched.isLast) {
                break;
            }
        }
        return rows.slice(skip, page.limit === undefined ? undefined : skip + page.limit);
    }
    loadSeparateRelations(results, plan) {
        const loads = plan.description.separateLoads ?? [];
        if (loads.length === 0 || results.length === 0) {
            return;
        }
        (0, separate_relation_loader_1.loadSeparateRelationsIntoResults)(results, loads, {
            executeDescription: (description) => this.executeDescription(description),
            mappingOptionsFor: (load) => plan.separateMappings.get(load.relationship),
            batchSize: this.options.separateLoadBatchSize ?? separate_relation_loader_1.defaultSeparateLoadBatchSize,
            rowLimit: read_on_1.runRowLimit,
        });
    }
    // ── condition helpers ─────────────────────────────────────────────────────
    addWhere(link, rawField, operator, value, useText = false) {
        if (value === undefined && operator !== 'IS NULL' && operator !== 'IS NOT NULL' && operator !== 'EMPTY' && operator !== 'EMPTY_NOT') {
            return this;
        }
        const { key, field } = this.resolveField(rawField);
        // The internal id is a key whatever the model types it as; display text compares as a string.
        const fieldType = useText || field.fieldContext === 'DISPLAY' ? 'string' : field.isPrimary ? 'key' : field.type;
        const translated = (0, operator_translation_1.translateConditionOperator)(operator, fieldType, value);
        const node = (0, condition_nodes_1.conditionNodeForTranslation)(translated, (translatedOperator, values) => (field.formula !== undefined
            ? omitUndefined({ kind: 'formula', formula: field.formula, type: field.formulaType, operator: translatedOperator, values })
            : useText || field.fieldContext === 'DISPLAY'
                ? this.createDisplayTextConditionNode(field, translatedOperator, values)
                : omitUndefined({ kind: 'field', component: field.component, fieldId: field.queryFieldId, operator: translatedOperator, values })));
        this.conditions.push(omitUndefined({ node, link, relationship: this.separateRelationshipOf(key, field) }));
        return this;
    }
    /** A condition on the display text of a select field: a formula over the field in DISPLAY context. */
    createDisplayTextConditionNode(field, operator, values) {
        const reference = `{${field.component ? `${field.component}.` : ''}${field.queryFieldId}#DISPLAY}`;
        return omitUndefined({ kind: 'formula', formula: reference, type: 'STRING', operator, values });
    }
    addFormulaCondition(link, formula, type, operator, value) {
        const values = value === undefined ? undefined : Array.isArray(value) ? value : [value];
        this.conditions.push({ node: omitUndefined({ kind: 'formula', formula, type, operator, values }), link });
        return this;
    }
    addWhereGroup(link, callback) {
        const child = new QueryBuilder(this.config);
        this.formulaSelections.forEach((field, alias) => child.formulaSelections.set(alias, field));
        callback(child);
        if (child.conditions.length === 0) {
            return this;
        }
        const relationships = new Set(child.conditions.map((condition) => condition.relationship));
        const relationship = relationships.size === 1 ? child.conditions[0].relationship : undefined;
        this.conditions.push(omitUndefined({ node: (0, condition_nodes_1.combineConditions)(child.conditions), link, relationship }));
        return this;
    }
    // ── field resolution ──────────────────────────────────────────────────────
    /** Accepts dotted paths (`customer.companyName`) for the flattened config keys (`customer_companyName`). */
    normalizeFieldKey(fieldKey) {
        if (this.config.fields[fieldKey] || !fieldKey.includes('.')) {
            return fieldKey;
        }
        const flattened = fieldKey.replace(/\./g, '_');
        return this.config.fields[flattened] ? flattened : fieldKey;
    }
    resolveField(rawFieldKey) {
        const key = this.normalizeFieldKey(rawFieldKey);
        const field = this.config.fields[key] ?? this.formulaSelections.get(key);
        if (!field) {
            throw new Error(`Field '${key}' is not defined in query config for '${this.config.recordType}'.`);
        }
        return { key, field };
    }
    assertRelationship(name) {
        if (!this.config.relationships?.[name]) {
            throw new Error(`Relationship '${name}' is not defined in query config for '${this.config.recordType}'.`);
        }
    }
    /** True when the relationship's fields and components take part in this query. */
    isRelationshipActive(name) {
        if (this.excludedRelationships.has(name)) {
            return false;
        }
        return this.includedRelationships.has(name) || this.config.relationships?.[name]?.selectByDefault !== false;
    }
    relationshipOf(key, field) {
        const root = (field.nestPath ?? key).split('.')[0];
        return this.config.relationships?.[root] ? root : undefined;
    }
    loadOf(relationship) {
        return this.config.relationships?.[relationship]?.load ?? this.config.components?.[relationship]?.load ?? 'join';
    }
    separateRelationshipOf(key, field) {
        const relationship = this.relationshipOf(key, field);
        return relationship !== undefined && this.loadOf(relationship) === 'separate' ? relationship : undefined;
    }
    activeSeparateRelationships() {
        const names = new Set();
        for (const name of Object.keys(this.config.relationships ?? {})) {
            if (this.isRelationshipActive(name) && this.loadOf(name) === 'separate') {
                names.add(name);
            }
        }
        return names;
    }
    collectSelectableFields() {
        const configuredFields = Object.entries(this.config.fields).filter(([key, field]) => {
            if (field.isPrimary) {
                return true;
            }
            const relationship = this.relationshipOf(key, field);
            if (relationship !== undefined && !this.isRelationshipActive(relationship)) {
                return false;
            }
            if (this.selectedKeys) {
                return this.selectedKeys.has(key);
            }
            if (field.select === false) {
                return relationship !== undefined && this.includedRelationships.has(relationship);
            }
            return true;
        });
        return [...configuredFields, ...Array.from(this.formulaSelections.entries())];
    }
    primaryField() {
        for (const [key, field] of Object.entries(this.config.fields)) {
            if (field.isPrimary) {
                return { key, field };
            }
        }
        return undefined;
    }
    primaryAlias() {
        const primary = this.primaryField();
        return primary ? primary.field.alias ?? primary.key : undefined;
    }
}
exports.QueryBuilder = QueryBuilder;
function query(config, options) {
    return QueryBuilder.from(config, options);
}
function runQuery(config) {
    return query(config).executeTyped();
}
