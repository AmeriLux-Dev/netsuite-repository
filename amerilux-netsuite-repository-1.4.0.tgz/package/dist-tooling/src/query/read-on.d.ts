import type { ConditionNode, DescribedSort, FieldType, QueryDescription, QueryResultValue } from '../types';
import type { ResultRow } from './result-mapper';
/**
 * Reading a query past N/query's 5,000-row answer. Every query is sorted by its own sorts and then by the internal id,
 * so its order is complete; when an answer comes back full, the next read asks for the rows after its last one, by
 * the values of those sorts. What each comparison may be is what probes k1 to k6 found in a sandbox account on
 * 2026-09-24, reading 17,369 invoices of one customer.
 */
/** The most rows N/query's run() answers; it says nothing when it stops there (probe k2). */
export declare const runRowLimit = 5000;
/** The governance units a run of reads leaves the script by default, for the caller to act on what it read. */
export declare const defaultGovernanceReserve = 100;
/**
 * How a read compares a sort's value to pick up after it. `ordered` uses the field's own operators (GREATER, AFTER,
 * EQUAL, ON), which N/query accepts on keys, numbers and dates (probes k2, k5). `text` compares upper-cased in a
 * formula: N/query rejects GREATER on text, NetSuite orders text as UPPER(field), and the formula picks up exactly
 * where that order left off (probe k3).
 */
export type ReadOnComparison = 'ordered' | 'text';
/** A sort a read can pick up after: the sort, the alias its value comes back under, and how it compares. */
export interface ReadOnKey {
    sort: DescribedSort;
    alias: string;
    comparison: ReadOnComparison;
    fieldType: FieldType;
    /** The internal id: never blank. */
    isPrimary: boolean;
    /**
     * A text key on a joined record: how its formula names that record, by the join field ids from the root
     * (`terms`, `transactionlines`). A formula reaches a joined record through its select field, not the model's name.
     */
    formulaPath?: string;
    /**
     * A text key on a record joined through a reference's select field, which a formula may not reach at all (a select
     * field that points at several record types has no formula path: `{entity.companyname}` is "not found", sandbox
     * 2026-09-28). A whole read goes through runPaged rather than read on after it.
     */
    throughReference?: boolean;
}
/**
 * How a sort on a field of this type is compared to read on after it, or undefined when no probe checked a comparison
 * for the type (select, multiselect, checkbox, datetime): those queries are read through runPaged instead.
 */
export declare function readOnComparisonFor(fieldType: FieldType | undefined): ReadOnComparison | undefined;
/** Where blanks go: NetSuite puts them last ascending and first descending unless the sort says (probe k4). */
export declare function sortsBlanksLast(sort: DescribedSort): boolean;
/**
 * The rows after the one whose key values these are, in the order the keys give: for each key, the rows that share
 * every earlier key's value and come later on this one. The last key is the internal id, so no row is read twice or
 * skipped.
 */
export declare function buildAfterRowCondition(keys: ReadOnKey[], values: QueryResultValue[]): ConditionNode;
/** The description with one more condition ANDed onto its own. */
export declare function withAddedCondition(description: QueryDescription, condition: ConditionNode): QueryDescription;
/** A row's value for each key, read by the alias its column came back under; a missing value is blank. */
export declare function readKeyValues(keys: ReadOnKey[], row: ResultRow): QueryResultValue[];
/** The marker a page answers for the page after it: its last row's key values. */
export declare function encodeReadOnMarker(values: QueryResultValue[]): string;
/** The key values a marker carries, checked against the query it is handed back to. */
export declare function decodeReadOnMarker(marker: string, keys: ReadOnKey[]): QueryResultValue[];
/** Thrown before a read the script cannot afford, instead of NetSuite ending the script halfway through it. */
export declare class GovernanceLimitError extends Error {
    readonly rowsRead: number;
    readonly remainingUsage: number;
    readonly readCost: number;
    readonly reserve: number;
    constructor(message: string, rowsRead: number, remainingUsage: number, readCost: number, reserve: number);
}
/**
 * The governance a run of reads spends: what the last read cost, and whether another like it would leave the script
 * less than `reserve`. getRemainingUsage costs nothing (probe k6). Where N/runtime answers no usage, as outside
 * SuiteScript, every read is affordable.
 */
export declare class ReadGovernance {
    readonly reserve: number;
    private lastReadCost;
    constructor(reserve: number);
    measure<T>(read: () => T): T;
    /** What is left and what a read costs, when another read would dip into the reserve; undefined while it would not. */
    shortfall(): {
        remainingUsage: number;
        readCost: number;
    } | undefined;
}
