"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.normalizeMappedResultKey = normalizeMappedResultKey;
exports.buildFieldMap = buildFieldMap;
exports.mapRowsToResults = mapRowsToResults;
exports.transformResultValue = transformResultValue;
exports.setValueAtPath = setValueAtPath;
exports.getValueAtPath = getValueAtPath;
const coercion_1 = require("../coercion");
/** N/query keys mapped results by alias; the mapper compares aliases case-insensitively so casing differences never matter. */
function normalizeMappedResultKey(key) {
    return key.toLowerCase();
}
function normalizeRowKeys(row) {
    const normalized = {};
    for (const [key, value] of Object.entries(row)) {
        normalized[normalizeMappedResultKey(key)] = value;
    }
    return normalized;
}
/** Builds the alias → output path map for the fields a query selects. Keys are normalized aliases. */
function buildFieldMap(fields) {
    const map = {};
    for (const [key, field] of fields) {
        map[normalizeMappedResultKey(field.alias ?? key)] = { key, outputPath: field.nestPath ?? key, field };
    }
    return map;
}
/** Maps result rows into typed objects, grouping fanned-out sublist rows under their parent when array paths exist. */
function mapRowsToResults(rows, options) {
    if (rows.length === 0) {
        return [];
    }
    const normalizedRows = rows.map(normalizeRowKeys);
    if (options.arrayPaths.length > 0 && options.primaryAlias !== undefined) {
        return mapGroupedRows(normalizedRows, options, normalizeMappedResultKey(options.primaryAlias));
    }
    return normalizedRows.map((row) => mapSingleRow(row, options));
}
function mapGroupedRows(rows, options, primaryAlias) {
    const groups = new Map();
    for (const row of rows) {
        const id = row[primaryAlias];
        if (id === undefined || id === null) {
            continue;
        }
        const group = groups.get(id) ?? [];
        group.push(row);
        groups.set(id, group);
    }
    return Array.from(groups.values()).map((groupRows) => mapRowGroup(groupRows, options));
}
function mapRowGroup(rows, options) {
    const base = mapSingleRow(rows[0], options);
    for (const arrayPath of options.arrayPaths) {
        base[arrayPath] = [];
    }
    const seen = new Set();
    for (const row of rows) {
        for (const arrayPath of options.arrayPaths) {
            const item = buildArrayItem(row, options, arrayPath);
            if (!item) {
                continue;
            }
            const key = `${arrayPath}:${JSON.stringify(item)}`;
            if (seen.has(key)) {
                continue;
            }
            seen.add(key);
            base[arrayPath].push(item);
        }
    }
    return base;
}
function mapSingleRow(row, options) {
    const output = {};
    for (const [alias, mapping] of Object.entries(options.fieldMap)) {
        const path = mapping.outputPath;
        if (options.arrayPaths.some((arrayPath) => path === arrayPath || path.startsWith(`${arrayPath}.`))) {
            continue;
        }
        setValueAtPath(output, path, transformResultValue(row[alias], row, mapping.field, options.coerceEnabled));
    }
    return output;
}
function buildArrayItem(row, options, arrayPath) {
    const item = {};
    let hasValue = false;
    for (const [alias, mapping] of Object.entries(options.fieldMap)) {
        const path = mapping.outputPath;
        if (path !== arrayPath && !path.startsWith(`${arrayPath}.`)) {
            continue;
        }
        const itemPath = path === arrayPath ? mapping.key : path.slice(arrayPath.length + 1);
        const value = transformResultValue(row[alias], row, mapping.field, options.coerceEnabled);
        if (value !== null && value !== undefined && value !== '') {
            hasValue = true;
        }
        setValueAtPath(item, itemPath, value);
    }
    return hasValue ? item : null;
}
/** Coerces a raw value to the field's declared type when coercion is on for it, then applies the field's transform. */
function transformResultValue(value, row, field, coerceEnabled) {
    const shouldCoerce = field.coerce ?? coerceEnabled;
    const coerced = shouldCoerce ? (0, coercion_1.coerceQueryResultValueByFieldType)(value ?? null, field.type) : value ?? null;
    return field.transform ? field.transform(coerced, row) : coerced;
}
/** Writes a value at a dotted path, creating intermediate objects. */
function setValueAtPath(target, path, value) {
    const parts = path.split('.').filter(Boolean);
    let cursor = target;
    for (let index = 0; index < parts.length - 1; index++) {
        const part = parts[index];
        const next = cursor[part];
        if (!next || typeof next !== 'object' || Array.isArray(next)) {
            cursor[part] = {};
        }
        cursor = cursor[part];
    }
    cursor[parts[parts.length - 1]] = value;
}
/** Reads a value at a dotted path; undefined when any segment is missing. */
function getValueAtPath(source, path) {
    let cursor = source;
    for (const part of path.split('.')) {
        if (!cursor || typeof cursor !== 'object') {
            return undefined;
        }
        cursor = cursor[part];
    }
    return cursor;
}
