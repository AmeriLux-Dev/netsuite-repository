import type { DeleteResult, EntityCreate, EntityPatch, ListPage, ListPageOptions, QueryConfig, RecordGraphPatch, RecordId, RecordUpdaterOptions, UpdatePlan, UpdateResult } from './types';
import { QueryBuilder } from './query';
import type { GroupedQuery } from './query';
import type { ConditionValue, FieldPath, FieldValue, GroupableFieldPath, GroupKeyValues, OperatorFor } from './field-path';
import { RecordUpdater } from './record-updater';
import type { QueryConfigSource, QueryConfigSourceResult } from './model/resolve';
import { ChangeTracker, EntityState } from './tracking/change-tracker';
import type { ChangeSetEntry, EntityEntry } from './tracking/change-tracker';
export interface NetSuiteContextOptions {
    /** When false, queries never register entities and saveChanges() has nothing to save. Defaults to true. */
    tracking?: boolean;
}
/** A schema maps record set names to anything a model can be resolved from: raw configs or generated configs. */
export type ContextSchema = Record<string, QueryConfigSource<any, any>>;
export interface RecordSetOptions {
    /** Name used by the change tracker; defaults to the record type. */
    name?: string;
    changeTracker?: ChangeTracker;
}
/**
 * A reusable, composable query predicate (the EF specification pattern): a function that narrows a query.
 * Repositories accept any number of them, so `db.salesOrders.list(forCustomer(12), open())` reads as a sentence.
 */
export type Specification<TResult> = (query: QueryBuilder<TResult>) => QueryBuilder<TResult>;
export declare function applySpecifications<TResult>(builder: QueryBuilder<TResult>, specifications: Specification<TResult>[]): QueryBuilder<TResult>;
export interface PlannedChange extends ChangeSetEntry {
    /** RecordUpdater plan for Added and Modified entries; computed without NetSuite calls. */
    plan?: UpdatePlan;
}
/** What saveChanges() would do: one entry per entity that has changes, in save order. */
export interface ChangePlan {
    entries: PlannedChange[];
    hasChanges: boolean;
}
export interface PlanChangesOptions {
    /** Plan only these tracked entities; every other pending change is left alone. */
    entities?: object[];
    /** Record updater options for every plan built, layered over the model's defaults. */
    updaterOptions?: RecordUpdaterOptions;
}
export interface SaveChangesOptions extends PlanChangesOptions {
    /** Skip the remaining entities after the first failure. Defaults to true. */
    stopOnFirstFailure?: boolean;
    /** Re-snapshot entities that saved successfully. Defaults to true. */
    acceptChangesOnSuccess?: boolean;
}
export interface EntitySaveResult {
    setName: string;
    state: EntityState;
    key?: RecordId;
    entity: object;
    result: UpdateResult;
}
export interface SaveChangesResult {
    success: boolean;
    savedCount: number;
    failedCount: number;
    skippedCount: number;
    results: EntitySaveResult[];
}
/** Options of the record set's one-call writes: `create()`, `update()`, and `delete()`. */
export interface WriteOptions {
    /** Sees the plan before anything is written. Throw to abort with nothing saved; the entity keeps its pending changes. */
    beforeSave?: (plan: ChangePlan) => void;
    /** Record updater options for this write (requireFastPath, maxRecordCalls, ...), layered over the model's defaults. */
    updater?: RecordUpdaterOptions;
}
/** Thrown by `getById()` and `update()` when no record has the id. */
export declare class RecordNotFoundError extends Error {
    readonly recordType: string;
    readonly id: RecordId;
    constructor(recordType: string, id: RecordId);
}
/** Thrown by the record set's one-call writes when NetSuite rejects the save; `result` carries every entity's outcome. */
export declare class SaveChangesError extends Error {
    readonly result: SaveChangesResult;
    constructor(result: SaveChangesResult);
}
/**
 * The record set of one record type on a context: the repository (EF DbSet). Reads go through `list`, `first`,
 * `getById`, and `query()`. Writes come in three layers: the one-call `create`, `update`, and `delete`, which go
 * through change tracking and throw on failure; change tracking itself (`add`, `remove`, mutate, then
 * `context.saveChanges()`); and the record updater underneath (`updater`, `submitPatch`, `createRecord`, `deleteRecord`),
 * which returns results instead of throwing. Generated `<Model>RepositoryBase` classes extend it.
 */
export declare class RecordSet<TResult, TUpdate extends Record<string, unknown> = Partial<TResult> & Record<string, unknown>> {
    private readonly config;
    readonly name: string;
    readonly changeTracker: ChangeTracker;
    constructor(source: QueryConfigSource<TResult>, options?: RecordSetOptions);
    get recordType(): string;
    get metadata(): QueryConfig<TResult>;
    /** A tracked query: typed results are registered with the change tracker. */
    query(): QueryBuilder<TResult>;
    /** A query whose results are never tracked (EF AsNoTracking). Prefer it for reporting reads. */
    asNoTracking(): QueryBuilder<TResult>;
    /**
     * Every record matching the specifications, past N/query's 5,000-row answer; every record of the set when there are
     * none. See QueryBuilder.executeTyped().
     */
    list(...specifications: Specification<TResult>[]): TResult[];
    all(): TResult[];
    /**
     * One page of the records matching the specifications, for a list read across requests: pass the page's `next` as
     * `after` to read the page that follows. See QueryBuilder.executeTypedPage().
     */
    listPage(options: ListPageOptions, ...specifications: Specification<TResult>[]): ListPage<TResult>;
    /** The first record matching the specifications. */
    first(...specifications: Specification<TResult>[]): TResult | null;
    count(...specifications: Specification<TResult>[]): number;
    exists(...specifications: Specification<TResult>[]): boolean;
    /**
     * Starts a grouped read of the set, never tracked: add aggregates, then `list(...specifications)` returns every group.
     * See QueryBuilder.groupBy().
     */
    groupBy<TKey extends GroupableFieldPath<TResult>>(...keys: [TKey, ...TKey[]]): GroupedQuery<TResult, GroupKeyValues<TResult, TKey>, never, TKey>;
    /** Starts a query with one condition; the operators and the value are typed from the field, as on the query builder. */
    where<TField extends FieldPath<TResult>, TOperator extends OperatorFor<FieldValue<TResult, TField>>>(field: TField, operator: TOperator, value?: ConditionValue<FieldValue<TResult, TField>, TOperator>): QueryBuilder<TResult>;
    /** Returns the tracked instance when the key is already loaded, otherwise queries NetSuite (EF Find). Null when there is none. */
    find(id: RecordId): TResult | null;
    /** The record with the id; throws RecordNotFoundError when there is none. */
    getById(id: RecordId): TResult;
    /** The builder with the model's field typing set aside, for conditions the set states on the model's behalf. */
    private untypedQuery;
    /**
     * Creates a record from its values in one call and returns the same object with its new id written back.
     * The object is tracked afterwards; read it back with `getById()` when NetSuite sources values on save.
     */
    create(values: EntityCreate<TResult>, options?: WriteOptions): TResult;
    /**
     * Loads the record, applies the patch to the tracked entity, plans, calls `beforeSave`, and saves only that entity.
     * Scalars replace, subrecords merge, sublists take { update, add, remove } by line identity. Returns the entity.
     */
    update(id: RecordId, patch: EntityPatch<TResult>, options?: WriteOptions): TResult;
    /** Deletes the record in one call; an entity that was only added and never saved is simply forgotten. */
    delete(id: RecordId, options?: WriteOptions): void;
    private saveEntity;
    /** Starts tracking an existing entity as Unchanged. */
    attach(entity: TResult & object): EntityEntry<TResult & object>;
    /** Tracks a new entity; saveChanges() creates it. */
    add(entity: TResult & object): EntityEntry<TResult & object>;
    /** Marks an entity or key for deletion; saveChanges() deletes it. */
    remove(entityOrId: (TResult & object) | RecordId): EntityEntry<TResult & object>;
    entry(entity: TResult & object): EntityEntry<TResult & object> | undefined;
    /** An updater for the record, to stage values on before `submit()`. */
    updater(id: RecordId): RecordUpdater<TResult, TUpdate>;
    submit(id: RecordId, values: Partial<TUpdate> | Record<string, unknown>): UpdateResult;
    /** Writes a graph patch straight through the updater, without change tracking. */
    submitPatch(id: RecordId, patch: RecordGraphPatch<TUpdate>, options?: RecordUpdaterOptions): UpdateResult;
    /** Creates a record from a graph patch straight through the updater, without change tracking. */
    createRecord(patch: RecordGraphPatch<TUpdate>, options?: RecordUpdaterOptions): UpdateResult;
    /** Deletes a record and returns the result instead of throwing. */
    deleteRecord(id: RecordId): DeleteResult;
    private getPrimaryFieldKey;
}
/** A record set class the context can construct in place of the plain RecordSet: a generated base or a subclass of one. */
export type RecordSetConstructor<TResult> = new (source: QueryConfigSource<TResult>, options?: RecordSetOptions) => RecordSet<TResult, any>;
/** Repository classes per set name; any set left out is a plain RecordSet. */
export type RepositoryMap<TSchema extends ContextSchema> = {
    readonly [K in keyof TSchema]?: RecordSetConstructor<QueryConfigSourceResult<TSchema[K]>>;
};
/** Overrides layered over generated defaults: a registered subclass wins, every other set keeps its generated base. */
export type MergeRepositories<TDefaults, TOverrides> = Omit<TDefaults, keyof TOverrides> & TOverrides;
type ResolvedRecordSet<TSchema extends ContextSchema, TRepositories, K extends keyof TSchema> = K extends keyof TRepositories ? NonNullable<TRepositories[K]> extends new (...args: any[]) => infer TInstance ? TInstance : RecordSet<QueryConfigSourceResult<TSchema[K]>> : RecordSet<QueryConfigSourceResult<TSchema[K]>>;
export type RecordSets<TSchema extends ContextSchema, TRepositories extends RepositoryMap<TSchema> = {}> = {
    readonly [K in keyof TSchema]: ResolvedRecordSet<TSchema, TRepositories, K>;
};
export interface ContextFactoryOptions<TRepositories> extends NetSuiteContextOptions {
    /** Repository classes to construct for the named sets, typed so the context exposes the subclass. */
    repositories?: TRepositories;
}
/** The unit of work (EF DbContext): one record set per schema entry, one change tracker, saveChanges(). */
export declare class NetSuiteContext<TSchema extends ContextSchema, TRepositories extends RepositoryMap<TSchema> = {}> {
    private readonly schema;
    readonly entities: RecordSets<TSchema, TRepositories>;
    readonly options: NetSuiteContextOptions;
    readonly changeTracker: ChangeTracker;
    constructor(schema: TSchema, options?: ContextFactoryOptions<TRepositories>);
    set<K extends keyof TSchema & string>(name: K): RecordSets<TSchema, TRepositories>[K];
    has(name: string): boolean;
    /** Returns the schema entry as registered: a raw config or a generated config. */
    getConfig<K extends keyof TSchema & string>(name: K): TSchema[K];
    attach<K extends keyof TSchema & string>(setName: K, entity: QueryConfigSourceResult<TSchema[K]> & object): EntityEntry<QueryConfigSourceResult<TSchema[K]> & object>;
    entry<T extends object>(entity: T): EntityEntry<T> | undefined;
    detach(entity: object): void;
    /** Diffs every tracked entity (or only `options.entities`) and returns what saveChanges() would do, with updater plans and no NetSuite calls. */
    planChanges(options?: PlanChangesOptions): ChangePlan;
    /** Saves Added, then Modified, then Deleted entities through the record updater. Never throws for NetSuite failures. */
    saveChanges(options?: SaveChangesOptions): SaveChangesResult;
    /** The set by name, untyped, for the tracker and the save loop. */
    private recordSet;
    private createRecordSets;
}
export type NetSuiteContextInstance<TSchema extends ContextSchema, TRepositories extends RepositoryMap<TSchema> = {}> = NetSuiteContext<TSchema, TRepositories> & RecordSets<TSchema, TRepositories>;
/** Builds a context whose record sets are also properties (`db.salesOrders`); `repositories` swaps in subclasses per set. */
export declare function createNetSuiteContext<TSchema extends ContextSchema, TRepositories extends RepositoryMap<TSchema> = {}>(schema: TSchema, options?: ContextFactoryOptions<TRepositories>): NetSuiteContextInstance<TSchema, TRepositories>;
export {};
