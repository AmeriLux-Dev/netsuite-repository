import type { ClassOverrides } from '../../src/model';
import type { FileSystemAdapter } from '../file-system';
export interface ModelFileDiagnostic {
    filePath: string;
    message: string;
    exportName?: string;
}
/** An exported class from a model file together with the overrides its decorators registered. */
export interface CollectedClass {
    /** Posix path, matching the type checker's source file names. */
    filePath: string;
    exportName: string;
    className: string;
    constructor: Function;
    /** Overrides merged along the prototype chain, base first. */
    overrides: ClassOverrides;
}
/** Where an exported function lives, so transforms can be emitted as imports by name. */
export interface FunctionReference {
    exportName: string;
    filePath: string;
}
/** The subset of the runtime the evaluator relies on. Passed in so the sandbox shares the caller's module instance. */
export interface RuntimeModelApi {
    getClassOverrides(modelClass: Function): ClassOverrides;
}
export interface EvaluateModelFilesOptions {
    filePaths: string[];
    fileSystem: FileSystemAdapter;
    /** Module specifier that resolves to the runtime inside model files, e.g. '@amerilux/netsuite-repository'. */
    libraryModule: string;
    /** The loaded runtime module object handed to model files when they import the library. */
    runtimeModule: object;
    runtimeApi: RuntimeModelApi;
}
export interface EvaluateModelFilesResult {
    classes: CollectedClass[];
    diagnostics: ModelFileDiagnostic[];
    /** Every non-class function exported by any evaluated module (model files and their relative imports). */
    functionReferences: Map<Function, FunctionReference>;
}
/**
 * Transpiles and runs model files in a sandbox whose `require` only knows the library and relative model files,
 * then collects every exported class with the overrides its decorators registered through the shared runtime instance.
 */
export declare function evaluateModelFiles(options: EvaluateModelFilesOptions): EvaluateModelFilesResult;
