export interface TypesFileMember {
    name: string;
    optional: boolean;
    typeText: string;
}
/** One class of the types file: its interface, and for a record type the `<Class>Patch` and `<Class>Create` helpers. */
export interface TypesFileClass {
    className: string;
    /** Generated interface this one extends, when the model class has a collected base class. */
    baseClassName?: string;
    /** Own members only; inherited ones come from the base interface. */
    members: TypesFileMember[];
    /** Whether to emit `<Class>Patch` and `<Class>Create`: a record type whose config serialized. */
    helperTypes: boolean;
}
export interface TypesFileEmitOptions {
    classes: TypesFileClass[];
    libraryModule: string;
    version?: string;
}
/**
 * Emits the types file: the interface of every class, extending its base and referring to the other interfaces by
 * name (they all live in this one file), and for record types `<Class>Patch` and `<Class>Create`. Everything in it is
 * a type, so a bundler erases any import of it and a browser client can share it without the configs.
 */
export declare function emitTypesFile(options: TypesFileEmitOptions): string;
