"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.toRecordSetName = toRecordSetName;
exports.resolveTypesFilePath = resolveTypesFilePath;
exports.planGeneration = planGeneration;
exports.runGenerate = runGenerate;
exports.checkGenerated = checkGenerated;
const nodePath = __importStar(require("path"));
const runtime = __importStar(require("../src"));
const model_file_evaluator_1 = require("./collect/model-file-evaluator");
const model_resolver_1 = require("./collect/model-resolver");
const property_type_reader_1 = require("./collect/property-type-reader");
const compile_model_1 = require("./compile/compile-model");
const context_file_emitter_1 = require("./emit/context-file-emitter");
const model_file_emitter_1 = require("./emit/model-file-emitter");
const types_file_emitter_1 = require("./emit/types-file-emitter");
const file_system_1 = require("./file-system");
function toRecordSetName(modelName) {
    const camel = modelName.charAt(0).toLowerCase() + modelName.slice(1);
    if (/[^aeiou]y$/i.test(camel))
        return `${camel.slice(0, -1)}ies`;
    if (/(s|x|z|ch|sh)$/i.test(camel))
        return `${camel}es`;
    return `${camel}s`;
}
function toImportPath(fromDirectory, toFile) {
    const relative = (0, file_system_1.toPosixPath)(nodePath.relative(fromDirectory, toFile)).replace(/\.ts$/, '');
    return relative.startsWith('.') ? relative : `./${relative}`;
}
/** Where the types file goes: `types.outDir` when set, otherwise next to the other generated files. */
function resolveTypesFilePath(config, cwd) {
    return nodePath.resolve(cwd, config.types.outDir ?? config.outDir, config.types.fileName);
}
/** Gives every exported function a unique identifier for generated imports; same-named exports from different files are aliased. */
function buildFunctionImports(functionReferences, outDir) {
    const usedIdentifiers = new Set();
    const imports = [];
    for (const [fn, reference] of functionReferences) {
        let identifier = reference.exportName;
        let suffix = 2;
        while (usedIdentifiers.has(identifier)) {
            identifier = `${reference.exportName}_${suffix++}`;
        }
        usedIdentifiers.add(identifier);
        imports.push({ fn, identifier, exportName: reference.exportName, importPath: toImportPath(outDir, reference.filePath) });
    }
    return imports;
}
function resolveCompilerOptions(options) {
    const fromTsconfig = options.config.tsconfig ? (0, property_type_reader_1.readCompilerOptionsFromTsconfig)(nodePath.resolve(options.cwd, options.config.tsconfig)) : {};
    return { ...fromTsconfig, ...(options.compilerOptions ?? {}) };
}
/** The TypeScript text of a reference, subrecord, or sublist member: the target interface, projected with Pick when the declaration projected it. */
function relationTypeText(relation, target) {
    const mappedNames = target ? [...target.fields.map((field) => field.name), ...target.relations.map((nested) => nested.name)] : [];
    const projected = relation.projection === 'all' ? undefined : relation.projection.filter((name) => mappedNames.includes(name));
    const base = projected && projected.length > 0 && projected.length < mappedNames.length
        ? `Pick<${relation.targetClassName}, ${projected.map((name) => `'${name}'`).join(' | ')}>`
        : relation.targetClassName;
    return relation.kind === 'sublist' ? `${base}[]` : base;
}
/** The field paths of a record type, nested by relation, for the generated fields constant. */
function buildFieldPathTree(fields, relations, prefix = '') {
    const tree = {};
    for (const field of fields) {
        tree[field.name] = `${prefix}${field.name}`;
    }
    for (const relation of relations) {
        tree[relation.name] = buildFieldPathTree(relation.fields, relation.relations, `${prefix}${relation.name}.`);
    }
    return tree;
}
/** The own members of a class as the types file declares them; inherited ones come from the base interface it extends. */
function buildTypeFileMembers(model, classesByName) {
    const members = [];
    const ownFields = model.fields.filter((field) => !field.inherited || !model.base);
    const ownRelations = model.relations.filter((relation) => !relation.inherited || !model.base);
    for (const field of ownFields) {
        members.push({ name: field.name, optional: field.optional, typeText: field.typeText });
    }
    for (const property of model.unmapped.filter((candidate) => !candidate.inherited || !model.base)) {
        members.push({ name: property.name, optional: property.optional, typeText: property.typeText });
    }
    for (const relation of ownRelations) {
        members.push({ name: relation.name, optional: relation.optional, typeText: relationTypeText(relation, classesByName.get(relation.targetClassName)) });
    }
    return members;
}
/** Computes every generated file without touching disk. */
function planGeneration(options) {
    const { config, cwd, fileSystem } = options;
    const outDir = nodePath.resolve(cwd, config.outDir);
    const modelFiles = (0, file_system_1.resolveGlobs)(fileSystem, cwd, config.models);
    const evaluation = (0, model_file_evaluator_1.evaluateModelFiles)({
        filePaths: modelFiles,
        fileSystem,
        libraryModule: config.libraryModule,
        runtimeModule: runtime,
        runtimeApi: runtime,
    });
    const diagnostics = [...evaluation.diagnostics];
    // A models folder that exists and holds no model yet is a project that has just started: nothing to generate.
    // A folder that does not exist is a 'models' glob pointing at the wrong place.
    const missingModelFolder = config.models
        .filter((pattern) => !pattern.startsWith('!'))
        .some((pattern) => !fileSystem.fileExists(nodePath.resolve(cwd, (0, file_system_1.globBaseDirectory)(pattern))));
    if (modelFiles.length === 0 && missingModelFolder) {
        diagnostics.push({ filePath: cwd, message: `No model files matched the 'models' globs (${config.models.join(', ')}) under '${cwd}'. Check 'models' in the build config.` });
    }
    const functionImports = buildFunctionImports(evaluation.functionReferences, outDir);
    const files = [];
    const models = [];
    const program = evaluation.classes.length > 0 ? (0, property_type_reader_1.createModelTypeProgram)(modelFiles, resolveCompilerOptions(options)) : undefined;
    const declared = new Map();
    for (const collected of evaluation.classes) {
        const shape = program ? (0, property_type_reader_1.readDeclaredClass)(program, collected.filePath, collected.className) : undefined;
        if (!shape) {
            diagnostics.push({ filePath: collected.filePath, exportName: collected.exportName, message: `Could not read the TypeScript declaration of '${collected.exportName}'.` });
            continue;
        }
        declared.set((0, property_type_reader_1.classKeyOf)(collected), shape);
    }
    const resolution = (0, model_resolver_1.resolveModels)({ classes: evaluation.classes, declared });
    diagnostics.push(...resolution.diagnostics);
    const classesWithProblems = new Set(resolution.diagnostics.map((diagnostic) => `${diagnostic.filePath}#${diagnostic.exportName}`));
    const classesByName = new Map();
    for (const model of resolution.classes) {
        const previous = classesByName.get(model.className);
        if (previous) {
            diagnostics.push({ filePath: model.filePath, exportName: model.exportName, message: `Model name '${model.className}' is already used in '${previous.filePath}'.` });
            continue;
        }
        classesByName.set(model.className, model);
    }
    // The types file may live outside outDir (a workspace shared with a client); every model file imports its interface from there.
    const typesFilePath = resolveTypesFilePath(config, cwd);
    const typesImportPath = toImportPath(outDir, typesFilePath);
    const typesFileClasses = [];
    for (const model of classesByName.values()) {
        const members = buildTypeFileMembers(model, classesByName);
        let helperTypes = false;
        // One file per record type: its config, field paths, and optional base repository. A plain class has only its interface, in the types file.
        if (model.recordType !== undefined && !classesWithProblems.has(`${model.filePath}#${model.exportName}`)) {
            try {
                const content = (0, model_file_emitter_1.emitModelFile)({
                    className: model.className,
                    libraryModule: config.libraryModule,
                    typesImportPath,
                    config: (0, compile_model_1.compileModel)(model),
                    functionImports,
                    fields: buildFieldPathTree(model.fields, model.relations),
                    repository: config.repositories === 'classes',
                    version: options.version,
                });
                files.push({ path: nodePath.join(outDir, `${model.className}.gen.ts`), content });
                models.push({ modelName: model.className, setName: model.setName ?? toRecordSetName(model.className), filePath: model.filePath });
                helperTypes = true;
            }
            catch (error) {
                // The config could not be compiled or serialized (an unexported transform, say): report it and still emit the type.
                diagnostics.push({ filePath: model.filePath, exportName: model.exportName, message: error instanceof Error ? error.message : String(error) });
            }
        }
        typesFileClasses.push({ className: model.className, baseClassName: model.base?.className, members, helperTypes });
    }
    // Every interface in one type-only file, so consumers that must not touch the configs (a browser client's DTOs) import from it.
    if (typesFileClasses.length > 0) {
        files.push({
            path: typesFilePath,
            content: (0, types_file_emitter_1.emitTypesFile)({ classes: typesFileClasses, libraryModule: config.libraryModule, version: options.version }),
        });
    }
    if (models.length > 0) {
        files.push({
            path: nodePath.join(outDir, config.context.fileName),
            content: (0, context_file_emitter_1.emitContextFile)({
                contextName: config.context.name,
                libraryModule: config.libraryModule,
                repositories: config.repositories === 'classes',
                version: options.version,
                models: models.map((model) => ({ modelName: model.modelName, setName: model.setName, importPath: `./${model.modelName}.gen` })),
            }),
        });
    }
    return { files, models, diagnostics };
}
/** Writes the generated files, skipping any whose content is unchanged. */
function runGenerate(options) {
    const plan = planGeneration(options);
    const writtenFiles = [];
    const unchangedFiles = [];
    for (const file of plan.files) {
        const existing = options.fileSystem.fileExists(file.path) ? options.fileSystem.readTextFile(file.path) : undefined;
        if (existing === file.content) {
            unchangedFiles.push(file.path);
            continue;
        }
        options.fileSystem.ensureDirectory(nodePath.dirname(file.path));
        options.fileSystem.writeTextFile(file.path, file.content);
        writtenFiles.push(file.path);
    }
    return { ...plan, writtenFiles, unchangedFiles };
}
/** Compares the generated files on disk with what generation would produce, without writing. */
function checkGenerated(options) {
    const plan = planGeneration(options);
    const driftedFiles = [];
    const missingFiles = [];
    for (const file of plan.files) {
        if (!options.fileSystem.fileExists(file.path)) {
            missingFiles.push(file.path);
        }
        else if (options.fileSystem.readTextFile(file.path) !== file.content) {
            driftedFiles.push(file.path);
        }
    }
    return { ...plan, driftedFiles, missingFiles };
}
