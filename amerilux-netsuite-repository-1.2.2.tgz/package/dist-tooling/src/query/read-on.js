"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ReadGovernance = exports.GovernanceLimitError = exports.defaultGovernanceReserve = exports.runRowLimit = void 0;
exports.readOnComparisonFor = readOnComparisonFor;
exports.sortsBlanksLast = sortsBlanksLast;
exports.buildAfterRowCondition = buildAfterRowCondition;
exports.withAddedCondition = withAddedCondition;
exports.readKeyValues = readKeyValues;
exports.encodeReadOnMarker = encodeReadOnMarker;
exports.decodeReadOnMarker = decodeReadOnMarker;
const condition_nodes_1 = require("./condition-nodes");
const operator_translation_1 = require("./operator-translation");
const result_mapper_1 = require("./result-mapper");
/**
 * Reading a query past N/query's 5,000-row answer. Every query is sorted by its own sorts and then by the internal id,
 * so its order is complete; when an answer comes back full, the next read asks for the rows after its last one, by
 * the values of those sorts. What each comparison may be is what probes k1 to k6 found in a sandbox account on
 * 2026-09-24, reading 17,369 invoices of one customer.
 */
/** The most rows N/query's run() answers; it says nothing when it stops there (probe k2). */
exports.runRowLimit = 5000;
/** The governance units a run of reads leaves the script by default, for the caller to act on what it read. */
exports.defaultGovernanceReserve = 100;
/**
 * How a sort on a field of this type is compared to read on after it, or undefined when no probe checked a comparison
 * for the type (select, multiselect, checkbox, datetime): those queries are read through runPaged instead.
 */
function readOnComparisonFor(fieldType) {
    switch (fieldType) {
        case 'key':
        case 'integer':
        case 'float':
        case 'currency':
        case 'date':
            return 'ordered';
        case 'string':
            return 'text';
        default:
            return undefined;
    }
}
/** Where blanks go: NetSuite puts them last ascending and first descending unless the sort says (probe k4). */
function sortsBlanksLast(sort) {
    return sort.nullsLast ?? sort.ascending;
}
function isBlank(value) {
    return value === null || value === undefined || value === '';
}
function anyOf(nodes) {
    const flattened = nodes.flatMap((node) => (node.kind === 'or' ? node.nodes : [node]));
    return flattened.length === 1 ? flattened[0] : { kind: 'or', nodes: flattened };
}
function allOf(nodes) {
    const flattened = nodes.flatMap((node) => (node.kind === 'and' ? node.nodes : [node]));
    return flattened.length === 1 ? flattened[0] : { kind: 'and', nodes: flattened };
}
function fieldNode(sort, operator) {
    const node = { kind: 'field', fieldId: sort.fieldId, operator };
    return sort.component === undefined ? node : { ...node, component: sort.component };
}
/** `a > b` on text, the way NetSuite orders it: both sides upper-cased, inside a formula N/query accepts. */
function buildTextComparisonNode(sort, operator, value) {
    const reference = `{${sort.component === undefined ? '' : `${sort.component}.`}${sort.fieldId}}`;
    const literal = `'${String(value).replace(/'/g, "''")}'`;
    return { kind: 'formula', formula: `CASE WHEN UPPER(${reference}) ${operator} UPPER(${literal}) THEN 1 ELSE 0 END`, type: 'INTEGER', operator: 'EQUAL', values: [1] };
}
function buildOrderedComparisonNode(key, operator, value) {
    return (0, condition_nodes_1.conditionNodeForTranslation)((0, operator_translation_1.translateConditionOperator)(operator, key.fieldType, value), (translatedOperator, values) => {
        const node = { kind: 'field', fieldId: key.sort.fieldId, operator: translatedOperator, values };
        return key.sort.component === undefined ? node : { ...node, component: key.sort.component };
    });
}
function buildComparisonNode(key, operator, value) {
    return key.comparison === 'text' ? buildTextComparisonNode(key.sort, operator, value) : buildOrderedComparisonNode(key, operator, value);
}
/** The rows that share this value for the key: the same value, or a blank for a blank. */
function buildSameValueNode(key, value) {
    return isBlank(value) ? fieldNode(key.sort, 'EMPTY') : buildComparisonNode(key, '=', value);
}
/** The rows whose value for the key comes after this one in the sort, blanks where NetSuite puts them; undefined when none can. */
function buildLaterValueNode(key, value) {
    const blanksLast = !key.isPrimary && sortsBlanksLast(key.sort);
    if (isBlank(value)) {
        return blanksLast || key.isPrimary ? undefined : fieldNode(key.sort, 'EMPTY_NOT');
    }
    const later = buildComparisonNode(key, key.sort.ascending ? '>' : '<', value);
    return blanksLast ? anyOf([later, fieldNode(key.sort, 'EMPTY')]) : later;
}
/**
 * The rows after the one whose key values these are, in the order the keys give: for each key, the rows that share
 * every earlier key's value and come later on this one. The last key is the internal id, so no row is read twice or
 * skipped.
 */
function buildAfterRowCondition(keys, values) {
    const terms = [];
    keys.forEach((key, index) => {
        const later = buildLaterValueNode(key, values[index]);
        if (later !== undefined) {
            terms.push(allOf([...keys.slice(0, index).map((earlier, earlierIndex) => buildSameValueNode(earlier, values[earlierIndex])), later]));
        }
    });
    return anyOf(terms);
}
/** The description with one more condition ANDed onto its own. */
function withAddedCondition(description, condition) {
    return { ...description, condition: description.condition === undefined ? condition : { kind: 'and', nodes: [description.condition, condition] } };
}
/** A row's value for each key, read by the alias its column came back under; a missing value is blank. */
function readKeyValues(keys, row) {
    const valuesByKey = new Map(Object.entries(row).map(([alias, value]) => [(0, result_mapper_1.normalizeMappedResultKey)(alias), value]));
    return keys.map((key) => valuesByKey.get((0, result_mapper_1.normalizeMappedResultKey)(key.alias)) ?? null);
}
/** The marker a page answers for the page after it: its last row's key values. */
function encodeReadOnMarker(values) {
    return JSON.stringify(values);
}
/** The key values a marker carries, checked against the query it is handed back to. */
function decodeReadOnMarker(marker, keys) {
    let values;
    try {
        values = JSON.parse(marker);
    }
    catch {
        values = undefined;
    }
    if (!Array.isArray(values) || values.length !== keys.length) {
        throw new Error(`The page marker '${marker}' does not belong to this query: a marker for it carries ${keys.length} value(s), one per sort (${keys.map((key) => key.alias).join(', ')}).`);
    }
    return values;
}
/** Thrown before a read the script cannot afford, instead of NetSuite ending the script halfway through it. */
class GovernanceLimitError extends Error {
    constructor(message, rowsRead, remainingUsage, readCost, reserve) {
        super(message);
        this.rowsRead = rowsRead;
        this.remainingUsage = remainingUsage;
        this.readCost = readCost;
        this.reserve = reserve;
        this.name = 'GovernanceLimitError';
    }
}
exports.GovernanceLimitError = GovernanceLimitError;
function readRemainingUsage() {
    try {
        const usage = require('N/runtime').getCurrentScript().getRemainingUsage();
        return typeof usage === 'number' ? usage : undefined;
    }
    catch {
        return undefined;
    }
}
/**
 * The governance a run of reads spends: what the last read cost, and whether another like it would leave the script
 * less than `reserve`. getRemainingUsage costs nothing (probe k6). Where N/runtime answers no usage, as outside
 * SuiteScript, every read is affordable.
 */
class ReadGovernance {
    constructor(reserve) {
        this.reserve = reserve;
        this.lastReadCost = 0;
    }
    measure(read) {
        const before = readRemainingUsage();
        const result = read();
        const after = readRemainingUsage();
        if (before !== undefined && after !== undefined) {
            this.lastReadCost = Math.max(0, before - after);
        }
        return result;
    }
    /** What is left and what a read costs, when another read would dip into the reserve; undefined while it would not. */
    shortfall() {
        const remainingUsage = readRemainingUsage();
        if (remainingUsage === undefined || remainingUsage - this.lastReadCost >= this.reserve) {
            return undefined;
        }
        return { remainingUsage, readCost: this.lastReadCost };
    }
}
exports.ReadGovernance = ReadGovernance;
