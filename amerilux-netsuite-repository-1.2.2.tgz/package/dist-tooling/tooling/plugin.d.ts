import type { FileSystemAdapter } from './file-system';
import type { GenerateOptions, GenerateResult } from './generate';
export interface NetSuiteRepositoryPluginOptions {
    cwd?: string;
    configPath?: string;
    /** Regenerate on model changes for as long as the bundler stays open. */
    watch?: boolean;
    fileSystem?: FileSystemAdapter;
    /** Replaceable for tests; defaults to runGenerate. */
    generate?: (options: GenerateOptions) => GenerateResult;
    log?: (message: string) => void;
}
/** The object shape Vite and Rollup accept directly; webpack and esbuild users can call the same hooks from a tiny wrapper. */
export interface NetSuiteRepositoryPlugin {
    name: string;
    buildStart(): void;
    closeBundle(): void;
}
export declare class GenerationFailedError extends Error {
    readonly result: GenerateResult;
    constructor(result: GenerateResult);
}
export declare function netsuiteRepositoryPlugin(options?: NetSuiteRepositoryPluginOptions): NetSuiteRepositoryPlugin;
export declare function describeGenerateResult(result: GenerateResult): string;
