"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.defaultSeparateLoadBatchSize = void 0;
exports.collectDistinctParentKeys = collectDistinctParentKeys;
exports.batchValues = batchValues;
exports.loadSeparateRelationsIntoResults = loadSeparateRelationsIntoResults;
const condition_nodes_1 = require("./condition-nodes");
const operator_translation_1 = require("./operator-translation");
const result_mapper_1 = require("./result-mapper");
/** How many parent keys go into one ANY_OF list. */
exports.defaultSeparateLoadBatchSize = 500;
/** Distinct parent key values in first-seen order; null and undefined are never keys. */
function collectDistinctParentKeys(parents, parentKeyPath) {
    const seen = new Set();
    const keys = [];
    for (const parent of parents) {
        const value = (0, result_mapper_1.getValueAtPath)(parent, parentKeyPath);
        if (value === null || value === undefined) {
            continue;
        }
        const key = String(value);
        if (!seen.has(key)) {
            seen.add(key);
            keys.push(value);
        }
    }
    return keys;
}
function batchValues(values, batchSize) {
    const batches = [];
    for (let index = 0; index < values.length; index += batchSize) {
        batches.push(values.slice(index, index + batchSize));
    }
    return batches;
}
function withBatchCondition(load, batch) {
    const translated = (0, operator_translation_1.translateConditionOperator)('IN', load.batchFieldType ?? 'key', batch);
    const batchNode = (0, condition_nodes_1.conditionNodeForTranslation)(translated, (operator, values) => ({ kind: 'field', fieldId: load.batchFieldId, operator, values }));
    const condition = load.description.condition ? { kind: 'and', nodes: [batchNode, load.description.condition] } : batchNode;
    return { ...load.description, condition };
}
/**
 * One batch's related rows. An answer as long as the row limit may have stopped short, so the batch is split in two
 * and each half read again; a single parent whose answer is still that long cannot be split, and fails rather than
 * hand back part of what it holds.
 */
function readBatchRows(load, batch, runtime) {
    const rows = runtime.executeDescription(withBatchCondition(load, batch));
    if (runtime.rowLimit === undefined || rows.length < runtime.rowLimit) {
        return rows;
    }
    if (batch.length === 1) {
        throw new Error(`'${load.relationship}' of the record whose ${load.parentKeyPath} is ${String(batch[0])} came back ${runtime.rowLimit} rows long, as many as N/query answers at once, so some may be missing; narrow the relation's conditions or read it on its own.`);
    }
    const middle = Math.ceil(batch.length / 2);
    return [...readBatchRows(load, batch.slice(0, middle), runtime), ...readBatchRows(load, batch.slice(middle), runtime)];
}
function readRowValue(row, alias) {
    const wanted = (0, result_mapper_1.normalizeMappedResultKey)(alias);
    for (const [key, value] of Object.entries(row)) {
        if ((0, result_mapper_1.normalizeMappedResultKey)(key) === wanted) {
            return value;
        }
    }
    return undefined;
}
function groupRowsByParentKey(rows, parentKeyAlias) {
    const groups = new Map();
    for (const row of rows) {
        const key = readRowValue(row, parentKeyAlias);
        if (key === null || key === undefined) {
            continue;
        }
        const group = groups.get(String(key)) ?? [];
        group.push(row);
        groups.set(String(key), group);
    }
    return groups;
}
/**
 * Loads every separately loaded relation of the mapped results and stitches the items into their parents: an
 * array for a sublist (empty when the parent has none), an object or null for a subrecord or reference. Parent
 * keys are queried in batches; nested separate relations are loaded from the items the same way.
 */
function loadSeparateRelationsIntoResults(parents, loads, runtime) {
    for (const load of loads) {
        const itemsByParentKey = new Map();
        const mapping = runtime.mappingOptionsFor(load);
        for (const batch of batchValues(collectDistinctParentKeys(parents, load.parentKeyPath), runtime.batchSize)) {
            const rows = readBatchRows(load, batch, runtime);
            for (const [parentKey, group] of groupRowsByParentKey(rows, load.parentKeyAlias)) {
                const items = load.kind === 'sublist'
                    ? group.flatMap((row) => (0, result_mapper_1.mapRowsToResults)([row], mapping))
                    : (0, result_mapper_1.mapRowsToResults)(group, mapping);
                itemsByParentKey.set(parentKey, [...(itemsByParentKey.get(parentKey) ?? []), ...items]);
            }
        }
        const loadedItems = [];
        for (const parent of parents) {
            const key = (0, result_mapper_1.getValueAtPath)(parent, load.parentKeyPath);
            const items = key === null || key === undefined ? [] : itemsByParentKey.get(String(key)) ?? [];
            parent[load.relationship] = load.kind === 'sublist' ? items : items[0] ?? null;
            loadedItems.push(...items);
        }
        if (load.description.separateLoads && load.description.separateLoads.length > 0 && loadedItems.length > 0) {
            loadSeparateRelationsIntoResults(loadedItems, load.description.separateLoads, runtime);
        }
    }
}
