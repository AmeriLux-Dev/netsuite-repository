import type { ComponentCondition, FieldType, QueryField, RecordUpdaterOptions, RelationshipLoad } from '../types';
import type { ClassOverrides, ReferenceJoinKind, RelationHop } from './metadata';
export type ModelClass<T = unknown> = new (...args: never[]) => T;
export interface RecordTypeOptions {
    /** N/query root type when it is not the record type. */
    queryType?: string;
    /** Conditions applied to every query on this record type. */
    filter?: ComponentCondition[];
    /** Record set name on the context; derived from the class name when absent. */
    setName?: string;
    coerce?: boolean;
    /** Default record updater options for every write on this record type. */
    updater?: RecordUpdaterOptions;
}
export interface FieldOptions {
    /** N/query field id when it differs from the record field id. */
    queryFieldId?: string;
    /**
     * Overrides the type inferred from the property. Declare `select` on a list/record field with no reference: N/query
     * compares select and key fields through ANY_OF and rejects EQUAL on them.
     */
    type?: FieldType;
    /** Read the display text of a select field. Text fields are read-only; declare a second property to write the select field itself. */
    text?: boolean;
    coerce?: boolean;
    /**
     * Relationship field the value is read through (autoJoin), when N/query does not expose the field on the root but a
     * joined component carries it: a transaction's `subsidiary` is NOT_EXPOSED on `transaction` inside SuiteScript, and
     * its main line has it. The field still writes through the record's own field id; the query alone reads it there.
     */
    relationship?: string;
    /** Conditions on the joined component that pick the one row the value is read from (`mainline IS true`). */
    filter?: ComponentCondition[];
    /** Excludes the property from writes. */
    readOnly?: boolean;
    /** Writes the field before the others (a subrecord's `state` before its `zip`, so address validation accepts it). */
    setFirst?: boolean;
    /** `false` leaves the property out of the default select; include() brings it back per query. */
    selectByDefault?: boolean;
    /** Maps the value read. Must be an exported function so the build step can import it by name. */
    transform?: NonNullable<QueryField['transform']>;
}
export interface RelationOptions {
    /** `join` (default) reads the relation in the parent's query; `separate` runs a second query keyed by the parent ids. */
    load?: RelationshipLoad;
    /** `false` leaves the whole relation out of the default select; include() brings it back per query. */
    selectByDefault?: boolean;
}
export interface ReferenceOptions extends RelationOptions {
    /**
     * Property on the referenced class to match when it is not its internal id. Such a reference always loads separately.
     * Without it, `load: 'separate'` matches the target's internal id by a second query, for references N/query has no join for.
     */
    targetKey?: string;
    /** How the reference is joined: `auto` (autoJoin on the select field) or `to` (joinTo with the target's query type). */
    join?: ReferenceJoinKind;
}
export interface SubrecordOptions extends RelationOptions {
    /** List field cleared before the subrecord can be edited (for example 'shipaddresslist'). */
    clearListField?: string;
}
export interface SublistOptions extends RelationOptions {
    /** Conditions on the line component that pick this sublist's rows out of the line type. */
    filter?: ComponentCondition[];
    /** Relationship field for autoJoin, instead of joinFrom through the line class's @ParentId() field. */
    relationship?: string;
    /**
     * Root type of the separate line query when the lines are reached from another record than the owner's query
     * type: a sales order's lines hang off `transaction`, not `salesorder`. The lines are matched to the owner by
     * internal id, so the sublist loads separately; `load` need not be given.
     */
    queryType?: string;
    /**
     * The joins after `relationship` that lead to the items when they sit more than one join away: a string is a
     * relationship field (autoJoin), an object a select field with the query type it points at (joinTo) and its own
     * filter. The items' fields are read on the last hop, and nothing on the way needs a class. A transaction's
     * related transactions: `{ relationship: 'nexttransactionlink', through: [{ fieldId: 'nextdoc', target: 'transaction' }] }`.
     * The items are other records, not lines of the owner, so they are read-only.
     */
    through?: Array<string | RelationHop>;
}
type ClassDecoratorFunction = (target: Function) => void;
type PropertyDecoratorFunction = (target: object, propertyKey: string | symbol) => void;
/** A queryable record type. The class becomes a record set on the context, queried through N/query as the same type. */
export declare function RecordType(recordType: string, options?: RecordTypeOptions): ClassDecoratorFunction;
/** Marks the internal id when it is not the property named `id`. */
export declare function InternalId(): PropertyDecoratorFunction;
/** On a line class: marks the property holding the parent record's internal id. Its field is what the sublist join goes through. */
export declare function ParentId(): PropertyDecoratorFunction;
/**
 * Renames the field, overrides the inferred type, or flags how it is read and written. Never required: by convention
 * the field id is the lowercased property name.
 */
export declare function Field(fieldId?: string, options?: FieldOptions): PropertyDecoratorFunction;
export declare function Field(options: FieldOptions): PropertyDecoratorFunction;
/** @deprecated Use `@Field({ readOnly: true })`. */
export declare function ReadOnly(): PropertyDecoratorFunction;
/** A reference to another record: names the property holding the referenced internal id when it is not `<reference>Id`. */
export declare function Reference(selectFieldProperty?: string, options?: ReferenceOptions): PropertyDecoratorFunction;
export declare function Reference(options: ReferenceOptions): PropertyDecoratorFunction;
/** A subrecord: the field id when it is not the lowercased property name. N/query resolves the join from the field. */
export declare function Subrecord(fieldId?: string, options?: SubrecordOptions): PropertyDecoratorFunction;
export declare function Subrecord(options: SubrecordOptions): PropertyDecoratorFunction;
/** A sublist: the sublist id when it is not the lowercased property name, and the conditions that pick its lines. */
export declare function Sublist(sublistId?: string, options?: SublistOptions): PropertyDecoratorFunction;
export declare function Sublist(options: SublistOptions): PropertyDecoratorFunction;
/** @deprecated Use `@Field({ setFirst: true })`. */
export declare function SetFirst(): PropertyDecoratorFunction;
/** @deprecated Use `@Field({ selectByDefault: false })`, or `{ selectByDefault: false }` on `@Reference`, `@Subrecord`, or `@Sublist`. */
export declare function ExcludeFromDefaultSelect(): PropertyDecoratorFunction;
/** @deprecated Use `@Field({ transform })`. */
export declare function Transform(transform: NonNullable<QueryField['transform']>): PropertyDecoratorFunction;
/** Excludes a property from the model entirely. */
export declare function NotMapped(): PropertyDecoratorFunction;
/** The overrides registered on exactly this class, ignoring base classes. */
export declare function getOwnClassOverrides(modelClass: Function): ClassOverrides | undefined;
/** The overrides of a class merged over those of its base classes, base first. */
export declare function getClassOverrides(modelClass: Function): ClassOverrides;
/** True when the class or one of its bases carries a model decorator. */
export declare function isModelClass(value: unknown): value is ModelClass;
/** True only for classes carrying @RecordType somewhere in their prototype chain. */
export declare function isRecordTypeClass(value: unknown): value is ModelClass;
export {};
