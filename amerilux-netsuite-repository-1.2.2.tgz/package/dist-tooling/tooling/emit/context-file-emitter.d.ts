export interface ContextModelReference {
    modelName: string;
    setName: string;
    /** Import path (extension-less, relative) of the model's generated file. */
    importPath: string;
}
export interface ContextFileEmitOptions {
    contextName: string;
    models: ContextModelReference[];
    libraryModule: string;
    /** Wire the generated base repositories and accept subclasses through the factory's `repositories` option. */
    repositories: boolean;
    version?: string;
}
/** Emits `context.gen.ts`: the schema, the context type, a factory, and `dbContext`; with repositories, also the generated bases and the option to swap in subclasses. */
export declare function emitContextFile(options: ContextFileEmitOptions): string;
