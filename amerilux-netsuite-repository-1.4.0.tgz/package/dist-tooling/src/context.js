"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NetSuiteContext = exports.RecordSet = exports.SaveChangesError = exports.RecordNotFoundError = void 0;
exports.applySpecifications = applySpecifications;
exports.createNetSuiteContext = createNetSuiteContext;
const query_1 = require("./query");
const record_updater_1 = require("./record-updater");
const resolve_1 = require("./model/resolve");
const change_tracker_1 = require("./tracking/change-tracker");
const apply_patch_1 = require("./tracking/apply-patch");
function applySpecifications(builder, specifications) {
    return specifications.reduce((current, specification) => specification(current), builder);
}
/** Thrown by `getById()` and `update()` when no record has the id. */
class RecordNotFoundError extends Error {
    constructor(recordType, id) {
        super(`No '${recordType}' record has id ${String(id)}.`);
        this.recordType = recordType;
        this.id = id;
        this.name = 'RecordNotFoundError';
    }
}
exports.RecordNotFoundError = RecordNotFoundError;
/** Thrown by the record set's one-call writes when NetSuite rejects the save; `result` carries every entity's outcome. */
class SaveChangesError extends Error {
    constructor(result) {
        super(describeSaveFailures(result));
        this.result = result;
        this.name = 'SaveChangesError';
    }
}
exports.SaveChangesError = SaveChangesError;
const skippedAfterFailureMessage = 'Skipped because an earlier entity failed to save.';
function describeSaveFailures(result) {
    const failures = result.results
        .filter((saved) => !saved.result.success && saved.result.error !== skippedAfterFailureMessage)
        .map((saved) => `${saved.setName}${saved.key !== undefined ? ` ${String(saved.key)}` : ''}: ${saved.result.error ?? 'failed'}`);
    return failures.length > 0 ? failures.join('; ') : 'saveChanges() failed.';
}
// ── the save loop ────────────────────────────────────────────────────────────
// Shared by the context (every tracked entity) and the record set's one-call writes (one entity).
const saveOrder = [change_tracker_1.EntityState.Added, change_tracker_1.EntityState.Modified, change_tracker_1.EntityState.Deleted];
function orderedChanges(changeTracker, entities) {
    const changeSet = changeTracker.detectChanges();
    const scoped = entities ? changeSet.entries.filter((entry) => entities.includes(entry.entity)) : changeSet.entries;
    const entries = saveOrder.flatMap((state) => scoped.filter((entry) => entry.state === state));
    return { entries, hasChanges: entries.length > 0 };
}
function buildUpdater(changeTracker, entry, updaterOptions) {
    const config = changeTracker.resolveConfig(entry.setName);
    let updater;
    if (entry.state === change_tracker_1.EntityState.Added) {
        updater = (0, record_updater_1.createRecord)(config);
    }
    else if (entry.state === change_tracker_1.EntityState.Modified) {
        updater = (0, record_updater_1.updateRecord)(config).id(entry.key);
    }
    if (!updater) {
        return undefined;
    }
    if (updaterOptions) {
        updater.withOptions(updaterOptions);
    }
    return updater.patch(entry.patch ?? {});
}
function saveEntry(changeTracker, entry, updaterOptions) {
    if (entry.state === change_tracker_1.EntityState.Deleted) {
        if (entry.key === undefined) {
            return { success: false, error: 'Cannot delete an entity without a key value.' };
        }
        const deleted = (0, record_updater_1.deleteRecord)(changeTracker.resolveConfig(entry.setName), entry.key);
        return { success: deleted.success, id: deleted.id, error: deleted.error };
    }
    if (entry.state === change_tracker_1.EntityState.Modified && entry.key === undefined) {
        return { success: false, error: 'Cannot update an entity without a key value.' };
    }
    return buildUpdater(changeTracker, entry, updaterOptions).submit();
}
function planTrackedChanges(changeTracker, options) {
    const changeSet = orderedChanges(changeTracker, options.entities);
    return {
        hasChanges: changeSet.hasChanges,
        entries: changeSet.entries.map((entry) => ({ ...entry, plan: buildUpdater(changeTracker, entry, options.updaterOptions)?.plan() })),
    };
}
function saveTrackedChanges(changeTracker, options) {
    const { stopOnFirstFailure = true, acceptChangesOnSuccess = true } = options;
    const changeSet = orderedChanges(changeTracker, options.entities);
    const results = [];
    let failed = false;
    for (const entry of changeSet.entries) {
        if (failed && stopOnFirstFailure) {
            results.push({ setName: entry.setName, state: entry.state, key: entry.key, entity: entry.entity, result: { success: false, error: skippedAfterFailureMessage } });
            continue;
        }
        const result = saveEntry(changeTracker, entry, options.updaterOptions);
        results.push({ setName: entry.setName, state: entry.state, key: entry.key, entity: entry.entity, result });
        if (!result.success) {
            failed = true;
        }
    }
    if (acceptChangesOnSuccess) {
        changeTracker.acceptChanges(results.filter((saved) => saved.result.success).map((saved) => ({ entity: saved.entity, assignedKey: saved.state === change_tracker_1.EntityState.Added ? saved.result.id : undefined })));
    }
    const savedCount = results.filter((saved) => saved.result.success).length;
    const skippedCount = results.filter((saved) => saved.result.error === skippedAfterFailureMessage).length;
    return { success: !failed, savedCount, failedCount: results.length - savedCount - skippedCount, skippedCount, results };
}
// ── the record set ───────────────────────────────────────────────────────────
/**
 * The record set of one record type on a context: the repository (EF DbSet). Reads go through `list`, `first`,
 * `getById`, and `query()`. Writes come in three layers: the one-call `create`, `update`, and `delete`, which go
 * through change tracking and throw on failure; change tracking itself (`add`, `remove`, mutate, then
 * `context.saveChanges()`); and the record updater underneath (`updater`, `submitPatch`, `createRecord`, `deleteRecord`),
 * which returns results instead of throwing. Generated `<Model>RepositoryBase` classes extend it.
 */
class RecordSet {
    constructor(source, options = {}) {
        this.config = (0, resolve_1.resolveQueryConfig)(source);
        this.name = options.name ?? this.config.recordType;
        this.changeTracker = options.changeTracker ?? new change_tracker_1.ChangeTracker(() => this.config);
    }
    get recordType() {
        return this.config.recordType;
    }
    get metadata() {
        return this.config;
    }
    // ── reads ──
    /** A tracked query: typed results are registered with the change tracker. */
    query() {
        return (0, query_1.query)(this.config, { resultObserver: (results) => this.changeTracker.trackQueryResults(this.name, results) });
    }
    /** A query whose results are never tracked (EF AsNoTracking). Prefer it for reporting reads. */
    asNoTracking() {
        return this.query().asNoTracking();
    }
    /**
     * Every record matching the specifications, past N/query's 5,000-row answer; every record of the set when there are
     * none. See QueryBuilder.executeTyped().
     */
    list(...specifications) {
        return applySpecifications(this.query(), specifications).executeTyped();
    }
    all() {
        return this.list();
    }
    /**
     * One page of the records matching the specifications, for a list read across requests: pass the page's `next` as
     * `after` to read the page that follows. See QueryBuilder.executeTypedPage().
     */
    listPage(options, ...specifications) {
        return applySpecifications(this.query(), specifications).executeTypedPage(options);
    }
    /** The first record matching the specifications. */
    first(...specifications) {
        return applySpecifications(this.query(), specifications).firstTyped();
    }
    count(...specifications) {
        return applySpecifications(this.query(), specifications).count();
    }
    exists(...specifications) {
        return applySpecifications(this.query(), specifications).exists();
    }
    /**
     * Starts a grouped read of the set, never tracked: add aggregates, then `list(...specifications)` returns every group.
     * See QueryBuilder.groupBy().
     */
    groupBy(...keys) {
        return this.asNoTracking().groupBy(...keys);
    }
    /** Starts a query with one condition; the operators and the value are typed from the field, as on the query builder. */
    where(field, operator, value) {
        return this.untypedQuery().where(field, operator, value);
    }
    /** Returns the tracked instance when the key is already loaded, otherwise queries NetSuite (EF Find). Null when there is none. */
    find(id) {
        const tracked = this.changeTracker.findTracked(this.name, id);
        if (tracked) {
            return tracked;
        }
        return this.untypedQuery().where(this.getPrimaryFieldKey(), '=', id).firstTyped();
    }
    /** The record with the id; throws RecordNotFoundError when there is none. */
    getById(id) {
        const entity = this.find(id);
        if (entity === null || entity === undefined) {
            throw new RecordNotFoundError(this.config.recordType, id);
        }
        return entity;
    }
    /** The builder with the model's field typing set aside, for conditions the set states on the model's behalf. */
    untypedQuery() {
        return this.query();
    }
    // ── one-call writes: change tracking, one entity, throw on failure ──
    /**
     * Creates a record from its values in one call and returns the same object with its new id written back.
     * The object is tracked afterwards; read it back with `getById()` when NetSuite sources values on save.
     */
    create(values, options = {}) {
        const entity = values;
        this.add(entity);
        this.saveEntity(entity, options);
        return entity;
    }
    /**
     * Loads the record, applies the patch to the tracked entity, plans, calls `beforeSave`, and saves only that entity.
     * Scalars replace, subrecords merge, sublists take { update, add, remove } by line identity. Returns the entity.
     */
    update(id, patch, options = {}) {
        const entity = this.getById(id);
        if (!this.changeTracker.entry(entity)) {
            this.attach(entity);
        }
        (0, apply_patch_1.applyEntityPatch)(this.config, entity, patch);
        this.saveEntity(entity, options);
        return entity;
    }
    /** Deletes the record in one call; an entity that was only added and never saved is simply forgotten. */
    delete(id, options = {}) {
        const entry = this.remove(id);
        this.saveEntity(entry.entity, options);
    }
    saveEntity(entity, options) {
        const scope = { entities: [entity], updaterOptions: options.updater };
        if (options.beforeSave) {
            options.beforeSave(planTrackedChanges(this.changeTracker, scope));
        }
        const result = saveTrackedChanges(this.changeTracker, scope);
        if (!result.success) {
            throw new SaveChangesError(result);
        }
    }
    // ── change tracking ──
    /** Starts tracking an existing entity as Unchanged. */
    attach(entity) {
        return this.changeTracker.attach(this.name, entity);
    }
    /** Tracks a new entity; saveChanges() creates it. */
    add(entity) {
        return this.changeTracker.add(this.name, entity);
    }
    /** Marks an entity or key for deletion; saveChanges() deletes it. */
    remove(entityOrId) {
        return this.changeTracker.remove(this.name, entityOrId);
    }
    entry(entity) {
        return this.changeTracker.entry(entity);
    }
    // ── the record updater: results, never throws ──
    /** An updater for the record, to stage values on before `submit()`. */
    updater(id) {
        return (0, record_updater_1.updateRecord)(this.config).id(id);
    }
    submit(id, values) {
        return this.submitPatch(id, values);
    }
    /** Writes a graph patch straight through the updater, without change tracking. */
    submitPatch(id, patch, options) {
        const updater = this.updater(id);
        if (options) {
            updater.withOptions(options);
        }
        return updater.patch(patch).submit();
    }
    /** Creates a record from a graph patch straight through the updater, without change tracking. */
    createRecord(patch, options) {
        const updater = (0, record_updater_1.createRecord)(this.config);
        if (options) {
            updater.withOptions(options);
        }
        return updater.patch(patch).submit();
    }
    /** Deletes a record and returns the result instead of throwing. */
    deleteRecord(id) {
        return (0, record_updater_1.deleteRecord)(this.config, id);
    }
    getPrimaryFieldKey() {
        for (const [key, field] of Object.entries(this.config.fields)) {
            if (field.isPrimary) {
                return key;
            }
        }
        throw new Error(`No primary field is configured for '${this.config.recordType}'.`);
    }
}
exports.RecordSet = RecordSet;
// ── the context ──────────────────────────────────────────────────────────────
/** The unit of work (EF DbContext): one record set per schema entry, one change tracker, saveChanges(). */
class NetSuiteContext {
    constructor(schema, options = {}) {
        this.schema = schema;
        const { repositories, ...contextOptions } = options;
        this.options = { tracking: true, ...contextOptions };
        this.changeTracker = new change_tracker_1.ChangeTracker((setName) => this.recordSet(setName).metadata, this.options.tracking !== false);
        this.entities = this.createRecordSets(schema, repositories);
    }
    set(name) {
        return this.recordSet(name);
    }
    has(name) {
        return Object.prototype.hasOwnProperty.call(this.schema, name);
    }
    /** Returns the schema entry as registered: a raw config or a generated config. */
    getConfig(name) {
        const config = this.schema[name];
        if (!config) {
            throw new Error(`Entity '${name}' is not registered in this NetSuiteContext.`);
        }
        return config;
    }
    attach(setName, entity) {
        return this.recordSet(setName).attach(entity);
    }
    entry(entity) {
        return this.changeTracker.entry(entity);
    }
    detach(entity) {
        this.changeTracker.detach(entity);
    }
    /** Diffs every tracked entity (or only `options.entities`) and returns what saveChanges() would do, with updater plans and no NetSuite calls. */
    planChanges(options = {}) {
        return planTrackedChanges(this.changeTracker, options);
    }
    /** Saves Added, then Modified, then Deleted entities through the record updater. Never throws for NetSuite failures. */
    saveChanges(options = {}) {
        return saveTrackedChanges(this.changeTracker, options);
    }
    /** The set by name, untyped, for the tracker and the save loop. */
    recordSet(name) {
        const recordSet = this.entities[name];
        if (!recordSet) {
            throw new Error(`Entity '${name}' is not registered in this NetSuiteContext.`);
        }
        return recordSet;
    }
    createRecordSets(schema, repositories) {
        const sets = {};
        const constructors = (repositories ?? {});
        for (const [name, source] of Object.entries(schema)) {
            const Repository = constructors[name] ?? RecordSet;
            sets[name] = new Repository(source, { name, changeTracker: this.changeTracker });
        }
        return sets;
    }
}
exports.NetSuiteContext = NetSuiteContext;
/** Builds a context whose record sets are also properties (`db.salesOrders`); `repositories` swaps in subclasses per set. */
function createNetSuiteContext(schema, options) {
    const context = new NetSuiteContext(schema, options);
    for (const [name, recordSet] of Object.entries(context.entities)) {
        Object.defineProperty(context, name, {
            value: recordSet,
            enumerable: true,
            configurable: false,
            writable: false,
        });
    }
    return context;
}
