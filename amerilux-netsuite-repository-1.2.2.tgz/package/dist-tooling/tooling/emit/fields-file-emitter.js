"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.emitFieldsFile = emitFieldsFile;
const header_1 = require("./header");
function isIdentifier(name) {
    return /^[A-Za-z_$][A-Za-z0-9_$]*$/.test(name);
}
function renderTree(tree, indent) {
    const lines = [];
    for (const [name, entry] of Object.entries(tree)) {
        const key = isIdentifier(name) ? name : `'${name}'`;
        if (typeof entry === 'string') {
            lines.push(`${indent}${key}: '${entry}',`);
        }
        else {
            lines.push(`${indent}${key}: {`, ...renderTree(entry, `${indent}    `), `${indent}},`);
        }
    }
    return lines;
}
/**
 * Emits `<Model>.fields.gen.ts`: a constant whose properties mirror the model and hold its field paths, so a
 * specification can say `where(SalesOrderFields.lines.item.type, 'IN', ...)` instead of spelling the path.
 */
function emitFieldsFile(options) {
    const { modelName } = options;
    return [
        (0, header_1.buildGeneratedFileHeader)(`Field paths of the ${modelName} model, for where(), orderBy(), and select().`, options.version),
        `export const ${modelName}Fields = {`,
        ...renderTree(options.tree, '    '),
        '} as const;',
        '',
    ].join('\n');
}
