export interface TypeFileMember {
    name: string;
    optional: boolean;
    typeText: string;
}
export interface TypeFileEmitOptions {
    className: string;
    /** Generated interface this one extends, when the model class has a collected base class. */
    baseClassName?: string;
    /** Own members only; inherited ones come from the base interface. */
    members: TypeFileMember[];
    /** Other generated classes referenced by the members or the base, imported from their own type files. */
    imports: string[];
    /** Record types also get the patch and create helper types. */
    isRecordType: boolean;
    libraryModule: string;
    version?: string;
}
/** Emits `<Class>.types.gen.ts`: one plain interface per model class plus, for record types, the patch and create helper types. */
export declare function emitTypeFile(options: TypeFileEmitOptions): string;
