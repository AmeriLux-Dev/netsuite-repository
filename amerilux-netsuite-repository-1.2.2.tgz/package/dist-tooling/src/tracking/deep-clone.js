"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.cloneEntitySnapshot = cloneEntitySnapshot;
/**
 * Copies an entity graph so it can later be diffed against the live object.
 * Dates are copied, arrays and plain objects recurse, functions and prototypes are dropped.
 * structuredClone is unavailable in SuiteScript, so this stays hand-written and small.
 */
function cloneEntitySnapshot(value, visited = new WeakSet()) {
    if (value === null || typeof value !== 'object') {
        return value;
    }
    if (value instanceof Date) {
        return new Date(value.getTime());
    }
    if (visited.has(value)) {
        throw new Error('Cannot snapshot an entity with circular references.');
    }
    visited.add(value);
    if (Array.isArray(value)) {
        const copy = value.map((item) => cloneEntitySnapshot(item, visited));
        visited.delete(value);
        return copy;
    }
    const copy = {};
    for (const [key, entry] of Object.entries(value)) {
        if (typeof entry !== 'function') {
            copy[key] = cloneEntitySnapshot(entry, visited);
        }
    }
    visited.delete(value);
    return copy;
}
