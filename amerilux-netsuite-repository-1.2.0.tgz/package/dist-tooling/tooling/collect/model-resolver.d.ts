import type { ComponentCondition, ComponentJoin, FieldType, QueryField, RecordUpdaterOptions, RelationshipLoad, SeparateLoad } from '../../src/types';
import type { RelationKind } from '../../src/model';
import type { CollectedClass, ModelFileDiagnostic } from './model-file-evaluator';
import type { ClassIdentity, DeclaredClass } from './property-type-reader';
export type { RelationKind };
/** A field N/query reads off a joined component instead of the root: the relationship field and the row it picks. */
export interface ResolvedFieldRelationship {
    fieldId: string;
    filter?: ComponentCondition[];
}
export interface ResolvedField {
    name: string;
    /** N/query field id. */
    queryFieldId: string;
    /** Set when the value is read through a relationship because the root does not expose it. */
    relationship?: ResolvedFieldRelationship;
    /** N/record field id the property writes through; `readOnly` says whether it ever does. */
    recordFieldId: string;
    readOnly: boolean;
    type: FieldType;
    text?: boolean;
    coerce?: boolean;
    setFirst?: boolean;
    selectByDefault?: boolean;
    transform?: QueryField['transform'];
    typeText: string;
    optional: boolean;
    inherited: boolean;
}
/** A property the class declares but the model does not map (@NotMapped); it stays on the generated type. */
export interface ResolvedUnmappedProperty {
    name: string;
    typeText: string;
    optional: boolean;
    inherited: boolean;
}
export interface ResolvedRelation {
    name: string;
    kind: RelationKind;
    optional: boolean;
    inherited: boolean;
    load: RelationshipLoad;
    selectByDefault?: boolean;
    targetClassName: string;
    projection: string[] | 'all';
    fields: ResolvedField[];
    relations: ResolvedRelation[];
    /** How N/query joins the relation to its parent component. */
    join: ComponentJoin;
    /** Reference matched on a field other than the target's internal id: loaded by its own query. */
    separate?: SeparateLoad;
    /** Reference: the owner's property holding the select field; a select field read through a relationship joins from there. */
    selectFieldProperty?: string;
    /** Subrecord: field id on the owner and the list field cleared before edits. */
    subrecordFieldId?: string;
    clearListField?: string;
    /** Sublist: id on the owner, the conditions that pick its lines, and the line class's key property. */
    sublistId?: string;
    filter?: ComponentCondition[];
    lineKeyProperty?: string;
    lineOrderFieldId?: string;
}
export interface ResolvedClass extends ClassIdentity {
    exportName: string;
    /** Base class when it is one of the collected classes. */
    base?: ClassIdentity;
    /** Set for @RecordType classes; plain classes (subrecord shapes, mapping bases) have none. */
    recordType?: string;
    /** N/query root type; the record type unless overridden. */
    queryType?: string;
    rootFilter?: ComponentCondition[];
    setName?: string;
    keyProperty: string;
    parentKeyProperty?: string;
    coerce?: boolean;
    updaterOptions?: RecordUpdaterOptions;
    fields: ResolvedField[];
    relations: ResolvedRelation[];
    unmapped: ResolvedUnmappedProperty[];
}
export interface ResolveModelsOptions {
    classes: CollectedClass[];
    declared: Map<string, DeclaredClass>;
}
export interface ResolveModelsResult {
    classes: ResolvedClass[];
    diagnostics: ModelFileDiagnostic[];
}
/**
 * Turns collected classes plus their declared shapes into resolved models. Every fact comes from the model itself:
 * property names and types, the decorators, and the classes properties point at. Nothing is looked up in a table of
 * NetSuite knowledge; what the model does not say, N/query resolves at run time.
 */
export declare function resolveModels(options: ResolveModelsOptions): ResolveModelsResult;
