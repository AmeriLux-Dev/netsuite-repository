"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EntityTypeBuilder = exports.RelatedNavigationBuilder = exports.CollectionNavigationBuilder = exports.OwnedNavigationBuilder = exports.NavigationBuilder = exports.PropertyBuilder = void 0;
exports.defineModel = defineModel;
exports.modelFromEntity = modelFromEntity;
exports.extendModel = extendModel;
exports.isEntityModelDefinition = isEntityModelDefinition;
const compile_1 = require("./compile");
const decorators_1 = require("./decorators");
const metadata_1 = require("./metadata");
/** Configures one scalar property. `end()` returns to the owning builder; `property()` jumps to a sibling. */
class PropertyBuilder {
    constructor(propertyMetadata, parent) {
        this.propertyMetadata = propertyMetadata;
        this.parent = parent;
    }
    hasColumn(column, tableAlias) {
        this.propertyMetadata.column = column;
        if (tableAlias !== undefined) {
            this.propertyMetadata.tableAlias = tableAlias;
        }
        return this;
    }
    fromAlias(tableAlias) {
        this.propertyMetadata.tableAlias = tableAlias;
        return this;
    }
    hasAlias(resultAlias) {
        this.propertyMetadata.alias = resultAlias;
        return this;
    }
    hasType(type) {
        this.propertyMetadata.type = type;
        return this;
    }
    /** Opts the property into writes. Without an argument the record field id equals the column. */
    hasRecordField(fieldId) {
        if (fieldId === undefined) {
            this.propertyMetadata.recordFieldFollowsColumn = true;
        }
        else {
            this.propertyMetadata.recordFieldId = fieldId;
        }
        return this;
    }
    isReadOnly() {
        this.propertyMetadata.readOnly = true;
        return this;
    }
    setFirst() {
        this.propertyMetadata.setFirst = true;
        return this;
    }
    useText() {
        this.propertyMetadata.useText = true;
        return this;
    }
    excludeFromDefaultSelect() {
        this.propertyMetadata.selectByDefault = false;
        return this;
    }
    coerce(enabled) {
        this.propertyMetadata.coerce = enabled;
        return this;
    }
    transform(transform) {
        this.propertyMetadata.transform = transform;
        return this;
    }
    hasUpdateMapping(mapping) {
        this.propertyMetadata.updateMapping = mapping;
        return this;
    }
    property(name) {
        return this.parent.property(name);
    }
    end() {
        return this.parent;
    }
}
exports.PropertyBuilder = PropertyBuilder;
/** Shared surface for owned, collection, and related navigations. */
class NavigationBuilder {
    constructor(navigation) {
        this.navigation = navigation;
    }
    viaJoin(alias, spec) {
        this.navigation.join = { alias, table: spec.table, on: spec.on, type: spec.type, from: spec.from, params: spec.params };
        return this;
    }
    /** Nested columns live on an existing alias instead of their own join. */
    fromAlias(alias) {
        this.navigation.sourceAlias = alias;
        return this;
    }
    withRelationshipFields(fields) {
        this.navigation.additionalRelationshipFields = { ...(this.navigation.additionalRelationshipFields ?? {}), ...fields };
        return this;
    }
    property(name) {
        return new PropertyBuilder((0, metadata_1.getOrCreatePropertyMetadata)(this.navigation.properties, name), this);
    }
}
exports.NavigationBuilder = NavigationBuilder;
class OwnedNavigationBuilder extends NavigationBuilder {
    /** NetSuite subrecord field id, never inferred. */
    toSubrecord(subrecordFieldId) {
        this.navigation.subrecordFieldId = subrecordFieldId;
        return this;
    }
    clearListField(listFieldId) {
        this.navigation.clearListFieldId = listFieldId;
        return this;
    }
}
exports.OwnedNavigationBuilder = OwnedNavigationBuilder;
class CollectionNavigationBuilder extends NavigationBuilder {
    /** NetSuite sublist id, never inferred. */
    toSublist(sublistId) {
        this.navigation.sublistId = sublistId;
        return this;
    }
    matchBy(property) {
        this.navigation.matchByProperty = property;
        return this;
    }
    lineNumberProperty(property) {
        this.navigation.lineNumberProperty = property;
        return this;
    }
}
exports.CollectionNavigationBuilder = CollectionNavigationBuilder;
class RelatedNavigationBuilder extends NavigationBuilder {
}
exports.RelatedNavigationBuilder = RelatedNavigationBuilder;
/** Fluent configuration for one entity. Writes the same metadata the decorators produce. */
class EntityTypeBuilder {
    constructor(metadata) {
        this.metadata = metadata;
    }
    toRecord(recordType) {
        this.metadata.recordType = recordType;
        return this;
    }
    toTable(name, alias = name) {
        this.metadata.table = { name, alias };
        return this;
    }
    hasSetName(setName) {
        this.metadata.setName = setName;
        return this;
    }
    hasKey(property) {
        this.metadata.keyProperty = property;
        (0, metadata_1.getOrCreatePropertyMetadata)(this.metadata.properties, property);
        return this;
    }
    property(name) {
        return new PropertyBuilder((0, metadata_1.getOrCreatePropertyMetadata)(this.metadata.properties, name), this);
    }
    ignore(name) {
        this.metadata.ignoredProperties.add(name);
        return this;
    }
    hasJoin(alias, spec) {
        const existingIndex = this.metadata.joins.findIndex((join) => join.alias === alias);
        const join = { alias, table: spec.table, on: spec.on, type: spec.type, from: spec.from, params: spec.params };
        if (existingIndex >= 0) {
            this.metadata.joins[existingIndex] = join;
        }
        else {
            this.metadata.joins.push(join);
        }
        return this;
    }
    ownsOne(name, configure) {
        configure(new OwnedNavigationBuilder((0, metadata_1.getOrCreateNavigationMetadata)(this.metadata, name, 'owned')));
        return this;
    }
    ownsMany(name, configure) {
        configure(new CollectionNavigationBuilder((0, metadata_1.getOrCreateNavigationMetadata)(this.metadata, name, 'collection')));
        return this;
    }
    hasRelated(name, configure) {
        configure(new RelatedNavigationBuilder((0, metadata_1.getOrCreateNavigationMetadata)(this.metadata, name, 'related')));
        return this;
    }
    updaterOptions(options) {
        this.metadata.updaterOptions = { ...(this.metadata.updaterOptions ?? {}), ...options };
        return this;
    }
    coerce(enabled) {
        this.metadata.coerce = enabled;
        return this;
    }
    hasRestMetadata(metadata) {
        this.metadata.restRecordMetadata = metadata;
        return this;
    }
    hasComposite(mapping) {
        this.metadata.composite = mapping;
        return this;
    }
    postProcess(callback) {
        this.metadata.postProcess = callback;
        return this;
    }
}
exports.EntityTypeBuilder = EntityTypeBuilder;
function createDefinition(seed, steps) {
    let compiled;
    const definition = {
        kind: 'entityModel',
        buildMetadata() {
            const metadata = seed();
            const builder = new EntityTypeBuilder(metadata);
            for (const step of steps) {
                step(builder);
            }
            return metadata;
        },
        compile() {
            if (!compiled) {
                compiled = (0, compile_1.compileEntityModel)(definition.buildMetadata());
            }
            return compiled;
        },
    };
    return definition;
}
const definitionSteps = new WeakMap();
function registerDefinition(seed, steps) {
    const definition = createDefinition(seed, steps);
    definitionSteps.set(definition, { seed, steps });
    return definition;
}
/** Describes a model with the fluent API against a hand-written interface. */
function defineModel(configure) {
    return registerDefinition(() => (0, metadata_1.createEntityModelMetadata)(), [configure]);
}
/** Layers additional fluent configuration over a decorated class. Fluent calls override the decorators. */
function modelFromEntity(entityClass, configure) {
    return registerDefinition(() => (0, metadata_1.cloneEntityModelMetadata)((0, decorators_1.resolveDecoratedEntityMetadata)(entityClass)), configure ? [configure] : []);
}
/** Creates a new definition that replays the base steps and then the override. The base is untouched. */
function extendModel(base, configure) {
    const registration = definitionSteps.get(base);
    if (!registration) {
        throw new Error('extendModel() requires a definition created by defineModel(), modelFromEntity(), or extendModel().');
    }
    return registerDefinition(registration.seed, [...registration.steps, configure]);
}
function isEntityModelDefinition(value) {
    return Boolean(value) && typeof value === 'object' && value.kind === 'entityModel' && typeof value.compile === 'function';
}
