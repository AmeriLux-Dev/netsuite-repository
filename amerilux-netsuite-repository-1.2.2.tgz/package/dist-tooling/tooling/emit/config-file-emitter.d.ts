import type { QueryConfig } from '../../src/types';
export interface ConfigFileEmitOptions {
    modelName: string;
    config: QueryConfig<unknown>;
    libraryModule: string;
    /** Import path (extension-less, relative) of the generated type file. */
    typesImportPath: string;
    /** Functions the config may reference, each with the identifier to emit and where to import it from. */
    functionImports: FunctionImport[];
    version?: string;
}
export interface FunctionImport {
    fn: Function;
    identifier: string;
    exportName: string;
    /** Import path (extension-less, relative to the output directory). */
    importPath: string;
}
/** Emits `<Model>.config.gen.ts`: the plain QueryConfig literal the runtime imports. */
export declare function emitConfigFile(options: ConfigFileEmitOptions): string;
