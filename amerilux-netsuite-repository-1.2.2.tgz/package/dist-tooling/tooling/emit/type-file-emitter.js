"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.emitTypeFile = emitTypeFile;
const header_1 = require("./header");
/** Emits `<Class>.types.gen.ts`: one plain interface per model class plus, for record types, the patch and create helper types. */
function emitTypeFile(options) {
    const imports = Array.from(new Set(options.imports)).filter((name) => name !== options.className).sort();
    const lines = [(0, header_1.buildGeneratedFileHeader)(`Plain type for the ${options.className} model.`, options.version)];
    if (options.isRecordType) {
        lines.push(`import type { RecordGraphPatch } from '${options.libraryModule}';`);
    }
    for (const name of imports) {
        lines.push(`import type { ${name} } from './${name}.types.gen';`);
    }
    if (options.isRecordType || imports.length > 0) {
        lines.push('');
    }
    const extendsClause = options.baseClassName ? ` extends ${options.baseClassName}` : '';
    lines.push(`export interface ${options.className}${extendsClause} {`);
    for (const member of options.members) {
        lines.push(`    ${member.name}${member.optional ? '?' : ''}: ${member.typeText};`);
    }
    lines.push('}');
    if (options.isRecordType) {
        lines.push('', `export type ${options.className}Patch = RecordGraphPatch<${options.className}>;`, `export type ${options.className}Create = Partial<${options.className}>;`);
    }
    lines.push('');
    return lines.join('\n');
}
