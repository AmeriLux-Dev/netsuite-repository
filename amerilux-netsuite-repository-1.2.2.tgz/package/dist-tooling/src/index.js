"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createContext = void 0;
exports.repository = repository;
__exportStar(require("./types"), exports);
__exportStar(require("./query"), exports);
__exportStar(require("./field-path"), exports);
__exportStar(require("./record-updater"), exports);
__exportStar(require("./context"), exports);
__exportStar(require("./model"), exports);
__exportStar(require("./coercion"), exports);
__exportStar(require("./tracking"), exports);
const context_1 = require("./context");
const query_1 = require("./query");
const record_updater_1 = require("./record-updater");
/** Repository-style access to one model without a context, from its generated config. */
function repository(source) {
    function update(id, patch, options) {
        const updater = (0, record_updater_1.updateRecord)(source).id(id);
        if (options)
            updater.withOptions(options);
        return patch === undefined ? updater : updater.patch(patch).submit();
    }
    function create(patch, options) {
        const updater = (0, record_updater_1.createRecord)(source);
        if (options)
            updater.withOptions(options);
        return patch === undefined ? updater : updater.patch(patch).submit();
    }
    return {
        query: () => (0, query_1.query)(source),
        update,
        create,
        delete: (id) => (0, record_updater_1.deleteRecord)(source, id),
    };
}
exports.createContext = context_1.createNetSuiteContext;
