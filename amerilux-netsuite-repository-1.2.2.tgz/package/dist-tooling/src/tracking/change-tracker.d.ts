import type { QueryConfig, RecordGraphPatch, RecordId } from '../types';
export declare enum EntityState {
    Detached = "Detached",
    Unchanged = "Unchanged",
    Added = "Added",
    Modified = "Modified",
    Deleted = "Deleted"
}
/** EF-style view of one tracked entity. Setting `state` to Modified forces every writable value to be written. */
export interface EntityEntry<T extends object = object> {
    readonly entity: T;
    readonly setName: string;
    readonly key: RecordId | undefined;
    state: EntityState;
    readonly originalValues: T | undefined;
    /** Re-snapshots the entity from its current values so it counts as unchanged. */
    reload(): void;
}
export interface ChangeSetEntry {
    setName: string;
    state: EntityState;
    key?: RecordId;
    entity: object;
    /** Graph patch for Added and Modified entries. */
    patch?: RecordGraphPatch;
    /** Changed properties that cannot be written. */
    ignoredProperties: string[];
}
export interface ChangeSet {
    entries: ChangeSetEntry[];
    hasChanges: boolean;
}
export interface AcceptedChange {
    entity: object;
    /** Id assigned by NetSuite for an Added entity. */
    assignedKey?: RecordId;
}
/**
 * Identity map plus snapshots for entities loaded through a context.
 * Entries are held strongly (ES2019 has no WeakRef and a WeakMap cannot be iterated), so contexts should live for one script execution.
 */
export declare class ChangeTracker {
    readonly resolveConfig: (setName: string) => QueryConfig<unknown>;
    readonly enabled: boolean;
    private readonly entries;
    private readonly identity;
    constructor(resolveConfig: (setName: string) => QueryConfig<unknown>, enabled?: boolean);
    /** Registers query results; a result whose key is already tracked is replaced by the tracked instance (identity resolution). */
    trackQueryResults<T extends object>(setName: string, results: T[]): T[];
    attach<T extends object>(setName: string, entity: T): EntityEntry<T>;
    add<T extends object>(setName: string, entity: T): EntityEntry<T>;
    /** Marks an entity (or a bare key) for deletion. Removing an Added entity simply detaches it. */
    remove<T extends object>(setName: string, entityOrKey: T | RecordId): EntityEntry<T>;
    detach(entity: object): void;
    entry<T extends object>(entity: T): EntityEntry<T> | undefined;
    findTracked<T extends object>(setName: string, key: RecordId): T | undefined;
    trackedEntries(): EntityEntry[];
    /** Diffs every tracked entity against its snapshot and updates states to Modified where values changed. */
    detectChanges(): ChangeSet;
    /** Re-snapshots saved entities: Added becomes Unchanged with its new key, Modified becomes Unchanged, Deleted is detached. */
    acceptChanges(accepted: AcceptedChange[]): void;
    clear(): void;
    private register;
    private indexIdentity;
    private setState;
    private detachedEntry;
}
