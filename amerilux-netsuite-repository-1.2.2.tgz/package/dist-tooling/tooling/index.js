"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
__exportStar(require("./config"), exports);
__exportStar(require("./file-system"), exports);
__exportStar(require("./collect/model-file-evaluator"), exports);
__exportStar(require("./collect/property-type-reader"), exports);
__exportStar(require("./collect/model-resolver"), exports);
__exportStar(require("./compile/compile-model"), exports);
__exportStar(require("./emit/serialize"), exports);
__exportStar(require("./emit/header"), exports);
__exportStar(require("./emit/model-file-emitter"), exports);
__exportStar(require("./emit/context-file-emitter"), exports);
__exportStar(require("./emit/types-file-emitter"), exports);
__exportStar(require("./generate"), exports);
__exportStar(require("./watch"), exports);
__exportStar(require("./plugin"), exports);
__exportStar(require("./cli/arguments"), exports);
__exportStar(require("./cli/main"), exports);
