import type { QueryConfig } from '../types';
/**
 * Applies an EntityPatch to a tracked entity in place, so the change tracker can diff it: scalars replace, subrecords
 * merge, sublist lines are updated, added, and removed by identity, and undefined values are skipped. A property the
 * model does not declare, or a reference, is an error rather than a silent no-op.
 */
export declare function applyEntityPatch(config: QueryConfig<unknown>, entity: Record<string, unknown>, patch: Record<string, unknown>): void;
