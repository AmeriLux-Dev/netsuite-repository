export interface RepositoryFileEmitOptions {
    modelName: string;
    libraryModule: string;
    /** Import paths (extension-less, relative) of the generated config and type files. */
    configImportPath: string;
    typesImportPath: string;
    version?: string;
}
/**
 * Emits `<Model>.repository.gen.ts`: the base repository of one record type, a RecordSet bound to the generated
 * config. Consumers extend it with domain queries and register the subclass with the context factory.
 */
export declare function emitRepositoryFile(options: RepositoryFileEmitOptions): string;
