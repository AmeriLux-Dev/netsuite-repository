"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.emitConfigFile = emitConfigFile;
const header_1 = require("./header");
const serialize_1 = require("./serialize");
function isIdentifierReferenced(literal, identifier) {
    return new RegExp(`(^|[^A-Za-z0-9_$])${identifier}([^A-Za-z0-9_$]|$)`).test(literal);
}
/** Emits `<Model>.config.gen.ts`: the plain QueryConfig literal the runtime imports. */
function emitConfigFile(options) {
    const identifierByFunction = new Map(options.functionImports.map((entry) => [entry.fn, entry.identifier]));
    const literal = (0, serialize_1.serializeToTypeScriptLiteral)(options.config, { functionReferences: identifierByFunction });
    const importsByPath = new Map();
    for (const entry of options.functionImports) {
        if (isIdentifierReferenced(literal, entry.identifier)) {
            const specifier = entry.identifier === entry.exportName ? entry.identifier : `${entry.exportName} as ${entry.identifier}`;
            importsByPath.set(entry.importPath, [...(importsByPath.get(entry.importPath) ?? []), specifier]);
        }
    }
    const lines = [
        (0, header_1.buildGeneratedFileHeader)(`Query and record configuration for the ${options.modelName} model.`, options.version),
        `import type { QueryConfig } from '${options.libraryModule}';`,
        `import type { ${options.modelName} } from '${options.typesImportPath}';`,
    ];
    for (const [importPath, specifiers] of Array.from(importsByPath.entries()).sort(([left], [right]) => left.localeCompare(right))) {
        lines.push(`import { ${specifiers.sort().join(', ')} } from '${importPath}';`);
    }
    lines.push('', `export const ${options.modelName}Config: QueryConfig<${options.modelName}> = ${literal};`, '');
    return lines.join('\n');
}
