"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.resolveWatchedPaths = resolveWatchedPaths;
exports.createModelWatcher = createModelWatcher;
const nodePath = __importStar(require("path"));
const config_1 = require("./config");
const generate_1 = require("./generate");
function globBaseDirectory(pattern) {
    const segments = pattern.replace(/\\/g, '/').split('/');
    const base = [];
    for (const segment of segments) {
        if (/[*?]/.test(segment)) {
            break;
        }
        base.push(segment);
    }
    return base.join('/');
}
/** Directories and files the watcher observes: every model glob base plus the config file. */
function resolveWatchedPaths(config, cwd) {
    const bases = config.models
        .filter((pattern) => !pattern.startsWith('!'))
        .map((pattern) => nodePath.resolve(cwd, globBaseDirectory(pattern)));
    return Array.from(new Set([...bases, nodePath.resolve(cwd, config_1.DEFAULT_BUILD_CONFIG_FILE_NAME)]));
}
/** Re-runs generation whenever a model file changes, TanStack Router style. */
function createModelWatcher(options) {
    const generate = options.generate ?? generate_1.runGenerate;
    const debounceMilliseconds = options.debounceMilliseconds ?? 200;
    const outDir = nodePath.resolve(options.cwd, options.config.outDir);
    const typesFilePath = (0, generate_1.resolveTypesFilePath)(options.config, options.cwd);
    let stopWatching;
    let pendingTimer;
    let running = false;
    const runOnce = () => {
        try {
            const result = generate(options);
            options.onGenerated?.(result);
        }
        catch (error) {
            options.onError?.(error);
        }
    };
    const scheduleRun = (changedPath) => {
        if (isInsideDirectory(changedPath, outDir) || nodePath.resolve(changedPath) === typesFilePath) {
            return;
        }
        if (pendingTimer !== undefined) {
            clearTimeout(pendingTimer);
        }
        pendingTimer = setTimeout(() => {
            pendingTimer = undefined;
            runOnce();
        }, debounceMilliseconds);
    };
    return {
        get running() {
            return running;
        },
        start() {
            if (running) {
                return;
            }
            running = true;
            runOnce();
            stopWatching = options.fileSystem.watch(resolveWatchedPaths(options.config, options.cwd), scheduleRun);
        },
        stop() {
            if (pendingTimer !== undefined) {
                clearTimeout(pendingTimer);
                pendingTimer = undefined;
            }
            stopWatching?.();
            stopWatching = undefined;
            running = false;
        },
    };
}
function isInsideDirectory(filePath, directory) {
    const relative = nodePath.relative(directory, filePath);
    return relative !== '' && !relative.startsWith('..') && !nodePath.isAbsolute(relative);
}
