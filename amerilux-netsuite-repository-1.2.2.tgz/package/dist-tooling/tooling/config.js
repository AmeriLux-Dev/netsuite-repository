"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.BuildConfigError = exports.defaultBuildConfig = exports.DEFAULT_BUILD_CONFIG_FILE_NAME = void 0;
exports.loadBuildConfig = loadBuildConfig;
const nodePath = __importStar(require("path"));
exports.DEFAULT_BUILD_CONFIG_FILE_NAME = 'netsuite-repository.config.json';
exports.defaultBuildConfig = {
    models: ['src/models/**/*.ts'],
    outDir: 'src/repositories/generated',
    context: { name: 'App', fileName: 'context.gen.ts' },
    types: { fileName: 'types.gen.ts' },
    libraryModule: '@amerilux/netsuite-repository',
    repositories: 'none',
};
class BuildConfigError extends Error {
    constructor(configPath, problems) {
        super(`Build config '${configPath}' is invalid:\n - ${problems.join('\n - ')}`);
        this.configPath = configPath;
        this.problems = problems;
        this.name = 'BuildConfigError';
    }
}
exports.BuildConfigError = BuildConfigError;
function isStringArray(value) {
    return Array.isArray(value) && value.every((entry) => typeof entry === 'string');
}
function validateBuildConfig(raw, configPath) {
    const problems = [];
    const config = {
        ...exports.defaultBuildConfig,
        context: { ...exports.defaultBuildConfig.context },
        types: { ...exports.defaultBuildConfig.types },
    };
    if (raw.models !== undefined) {
        if (isStringArray(raw.models) && raw.models.length > 0) {
            config.models = raw.models;
        }
        else {
            problems.push("'models' must be a non-empty array of glob strings.");
        }
    }
    if (raw.outDir !== undefined) {
        if (typeof raw.outDir === 'string' && raw.outDir.trim() !== '') {
            config.outDir = raw.outDir;
        }
        else {
            problems.push("'outDir' must be a non-empty string.");
        }
    }
    if (raw.context !== undefined) {
        const context = raw.context;
        if (!context || typeof context !== 'object') {
            problems.push("'context' must be an object.");
        }
        else {
            if (context.name !== undefined) {
                if (typeof context.name === 'string' && /^[A-Za-z_][A-Za-z0-9_]*$/.test(context.name)) {
                    config.context.name = context.name;
                }
                else {
                    problems.push("'context.name' must be a valid identifier.");
                }
            }
            if (context.fileName !== undefined) {
                if (typeof context.fileName === 'string' && context.fileName.endsWith('.ts')) {
                    config.context.fileName = context.fileName;
                }
                else {
                    problems.push("'context.fileName' must end with '.ts'.");
                }
            }
        }
    }
    if (raw.types !== undefined) {
        const types = raw.types;
        if (!types || typeof types !== 'object') {
            problems.push("'types' must be an object.");
        }
        else {
            if (types.fileName !== undefined) {
                if (typeof types.fileName === 'string' && types.fileName.endsWith('.ts')) {
                    config.types.fileName = types.fileName;
                }
                else {
                    problems.push("'types.fileName' must end with '.ts'.");
                }
            }
            if (types.outDir !== undefined) {
                if (typeof types.outDir === 'string' && types.outDir.trim() !== '') {
                    config.types.outDir = types.outDir;
                }
                else {
                    problems.push("'types.outDir' must be a non-empty string.");
                }
            }
        }
    }
    if (raw.tsconfig !== undefined) {
        if (typeof raw.tsconfig === 'string') {
            config.tsconfig = raw.tsconfig;
        }
        else {
            problems.push("'tsconfig' must be a string path.");
        }
    }
    if (raw.libraryModule !== undefined) {
        if (typeof raw.libraryModule === 'string' && raw.libraryModule.trim() !== '') {
            config.libraryModule = raw.libraryModule;
        }
        else {
            problems.push("'libraryModule' must be a non-empty string.");
        }
    }
    if (raw.repositories !== undefined) {
        if (raw.repositories === 'classes' || raw.repositories === 'none') {
            config.repositories = raw.repositories;
        }
        else {
            problems.push("'repositories' must be 'classes' or 'none'.");
        }
    }
    if (problems.length > 0) {
        throw new BuildConfigError(configPath, problems);
    }
    return config;
}
/**
 * Loads the build config from disk, falling back to defaults when no config file exists.
 * Relative paths inside the config resolve against the config file's directory, so `--config examples/netsuite-repository.config.json` works from anywhere.
 */
function loadBuildConfig(fileSystem, cwd, configPath) {
    const resolvedPath = nodePath.resolve(cwd, configPath ?? exports.DEFAULT_BUILD_CONFIG_FILE_NAME);
    if (!fileSystem.fileExists(resolvedPath)) {
        if (configPath !== undefined) {
            throw new BuildConfigError(resolvedPath, ['file does not exist.']);
        }
        return { ...exports.defaultBuildConfig, context: { ...exports.defaultBuildConfig.context }, types: { ...exports.defaultBuildConfig.types }, rootDirectory: cwd };
    }
    let raw;
    try {
        raw = JSON.parse(fileSystem.readTextFile(resolvedPath));
    }
    catch (error) {
        throw new BuildConfigError(resolvedPath, [`could not parse JSON: ${error instanceof Error ? error.message : String(error)}`]);
    }
    if (!raw || typeof raw !== 'object' || Array.isArray(raw)) {
        throw new BuildConfigError(resolvedPath, ['top-level value must be an object.']);
    }
    return { ...validateBuildConfig(raw, resolvedPath), rootDirectory: nodePath.dirname(resolvedPath) };
}
