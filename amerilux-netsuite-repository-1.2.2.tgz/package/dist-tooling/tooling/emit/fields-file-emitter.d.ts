/** A field path per property, nested by relation: `{ id: 'id', lines: { item: { type: 'lines.item.type' } } }`. */
export interface FieldPathTree {
    [name: string]: string | FieldPathTree;
}
export interface FieldsFileEmitOptions {
    modelName: string;
    tree: FieldPathTree;
    version?: string;
}
/**
 * Emits `<Model>.fields.gen.ts`: a constant whose properties mirror the model and hold its field paths, so a
 * specification can say `where(SalesOrderFields.lines.item.type, 'IN', ...)` instead of spelling the path.
 */
export declare function emitFieldsFile(options: FieldsFileEmitOptions): string;
