export * from './types';
export * from './query';
export * from './field-path';
export * from './record-updater';
export * from './context';
export * from './model';
export * from './coercion';
export * from './tracking';
import type { DeleteResult, RecordGraphPatch, RecordId, RecordUpdaterOptions, UpdateResult } from './types';
import type { RecordUpdater } from './record-updater';
import type { QueryConfigSource } from './model/resolve';
import { createNetSuiteContext } from './context';
/** Repository-style access to one model without a context, from its generated config. */
export declare function repository<TResult, TUpdate extends Record<string, unknown> = Partial<TResult> & Record<string, unknown>>(source: QueryConfigSource<TResult>): {
    query: () => import("./query").QueryBuilder<TResult, never>;
    update: {
        (id: RecordId): RecordUpdater<TResult, TUpdate>;
        (id: RecordId, patch: RecordGraphPatch<TUpdate>, options?: RecordUpdaterOptions): UpdateResult;
    };
    create: {
        (): RecordUpdater<TResult, TUpdate>;
        (patch: RecordGraphPatch<TUpdate>, options?: RecordUpdaterOptions): UpdateResult;
    };
    delete: (id: RecordId) => DeleteResult;
};
export declare const createContext: typeof createNetSuiteContext;
