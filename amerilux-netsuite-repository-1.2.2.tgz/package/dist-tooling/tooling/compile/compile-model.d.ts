import type { QueryConfig } from '../../src/types';
import type { ResolvedClass } from '../collect/model-resolver';
export declare class ModelValidationError extends Error {
    readonly className: string;
    readonly problems: string[];
    constructor(className: string, problems: string[]);
}
/** Turns a resolved record type into the QueryConfig the runtime consumes. */
export declare function compileModel(model: ResolvedClass): QueryConfig<unknown>;
