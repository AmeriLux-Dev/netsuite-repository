import type { CoercedQueryValue, FieldType, QueryResultValue } from './types';
/**
 * Coerces a raw SuiteQL value to the JavaScript type implied by the declared field type.
 * Values that cannot be coerced are returned unchanged so a bad row never throws during mapping.
 */
export declare function coerceQueryResultValueByFieldType(value: QueryResultValue, type: FieldType | undefined): CoercedQueryValue;
