"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createClassOverrides = createClassOverrides;
exports.getOrCreatePropertyOverrides = getOrCreatePropertyOverrides;
exports.mergeClassOverrides = mergeClassOverrides;
function createClassOverrides() {
    return { properties: new Map(), notMapped: new Set() };
}
function getOrCreatePropertyOverrides(overrides, name) {
    let property = overrides.properties.get(name);
    if (!property) {
        property = { name };
        overrides.properties.set(name, property);
    }
    return property;
}
/** Layers `source` over `target`: scalar members win when set, property overrides merge per property. */
function mergeClassOverrides(target, source) {
    const { properties, notMapped, ...scalars } = source;
    for (const [key, value] of Object.entries(scalars)) {
        if (value !== undefined) {
            target[key] = value;
        }
    }
    for (const [name, property] of properties) {
        target.properties.set(name, { ...(target.properties.get(name) ?? { name }), ...property });
    }
    notMapped.forEach((name) => target.notMapped.add(name));
    return target;
}
