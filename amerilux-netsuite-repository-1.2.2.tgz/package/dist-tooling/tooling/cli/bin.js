#!/usr/bin/env node
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/* istanbul ignore file */
const main_1 = require("./main");
(0, main_1.runCli)(process.argv.slice(2), {
    cwd: process.cwd(),
    stdout: (message) => console.log(message),
    stderr: (message) => console.error(message),
}).then((exitCode) => {
    if (process.argv[2] !== 'watch') {
        process.exit(exitCode);
    }
});
