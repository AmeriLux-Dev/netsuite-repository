import type { CompositeModelMapping, FieldType, FieldUpdateMapping, QueryConfig, QueryField, RecordUpdaterOptions, RelationshipFieldMap, RestRecordMetadata } from '../types';
import type { EntityClass, JoinSpec } from './decorators';
import type { EntityModelMetadata, NavigationMetadata, PropertyMetadata } from './metadata';
export type PropertyName<T> = keyof T & string;
export type ElementOf<T> = T extends ReadonlyArray<infer TElement> ? TElement : never;
interface PropertyScope<T> {
    property<K extends PropertyName<T>>(name: K): PropertyBuilder<T, K, this>;
}
/** Configures one scalar property. `end()` returns to the owning builder; `property()` jumps to a sibling. */
export declare class PropertyBuilder<T, K extends PropertyName<T>, TParent extends PropertyScope<T>> {
    private readonly propertyMetadata;
    private readonly parent;
    constructor(propertyMetadata: PropertyMetadata, parent: TParent);
    hasColumn(column: string, tableAlias?: string): this;
    fromAlias(tableAlias: string): this;
    hasAlias(resultAlias: string): this;
    hasType(type: FieldType): this;
    /** Opts the property into writes. Without an argument the record field id equals the column. */
    hasRecordField(fieldId?: string): this;
    isReadOnly(): this;
    setFirst(): this;
    useText(): this;
    excludeFromDefaultSelect(): this;
    coerce(enabled: boolean): this;
    transform(transform: NonNullable<QueryField['transform']>): this;
    hasUpdateMapping(mapping: FieldUpdateMapping): this;
    property<K2 extends PropertyName<T>>(name: K2): PropertyBuilder<T, K2, TParent>;
    end(): TParent;
}
/** Shared surface for owned, collection, and related navigations. */
export declare class NavigationBuilder<TNested> implements PropertyScope<TNested> {
    protected readonly navigation: NavigationMetadata;
    constructor(navigation: NavigationMetadata);
    viaJoin(alias: string, spec: JoinSpec): this;
    /** Nested columns live on an existing alias instead of their own join. */
    fromAlias(alias: string): this;
    withRelationshipFields(fields: RelationshipFieldMap): this;
    property<K extends PropertyName<TNested>>(name: K): PropertyBuilder<TNested, K, this>;
}
export declare class OwnedNavigationBuilder<TNested> extends NavigationBuilder<TNested> {
    /** NetSuite subrecord field id, never inferred. */
    toSubrecord(subrecordFieldId: string): this;
    clearListField(listFieldId: string): this;
}
export declare class CollectionNavigationBuilder<TLine> extends NavigationBuilder<TLine> {
    /** NetSuite sublist id, never inferred. */
    toSublist(sublistId: string): this;
    matchBy<K extends PropertyName<TLine>>(property: K): this;
    lineNumberProperty<K extends PropertyName<TLine>>(property: K): this;
}
export declare class RelatedNavigationBuilder<TNested> extends NavigationBuilder<TNested> {
}
/** Fluent configuration for one entity. Writes the same metadata the decorators produce. */
export declare class EntityTypeBuilder<T> implements PropertyScope<T> {
    readonly metadata: EntityModelMetadata;
    constructor(metadata: EntityModelMetadata);
    toRecord(recordType: string): this;
    toTable(name: string, alias?: string): this;
    hasSetName(setName: string): this;
    hasKey<K extends PropertyName<T>>(property: K): this;
    property<K extends PropertyName<T>>(name: K): PropertyBuilder<T, K, this>;
    ignore<K extends PropertyName<T>>(name: K): this;
    hasJoin(alias: string, spec: JoinSpec): this;
    ownsOne<K extends PropertyName<T>>(name: K, configure: (builder: OwnedNavigationBuilder<NonNullable<T[K]>>) => void): this;
    ownsMany<K extends PropertyName<T>>(name: K, configure: (builder: CollectionNavigationBuilder<ElementOf<NonNullable<T[K]>>>) => void): this;
    hasRelated<K extends PropertyName<T>>(name: K, configure: (builder: RelatedNavigationBuilder<NonNullable<T[K]>>) => void): this;
    updaterOptions(options: RecordUpdaterOptions): this;
    coerce(enabled: boolean): this;
    hasRestMetadata(metadata: RestRecordMetadata): this;
    hasComposite(mapping: CompositeModelMapping): this;
    postProcess(callback: (result: T) => T): this;
}
export type EntityModelConfigure<T> = (builder: EntityTypeBuilder<T>) => void;
/** A reusable, composable model description produced by defineModel() or extendModel(). */
export interface EntityModelDefinition<T> {
    readonly kind: 'entityModel';
    /** Builds fresh metadata by replaying every configure step. */
    buildMetadata(): EntityModelMetadata;
    /** Compiles to the runtime QueryConfig. Cached after the first call. */
    compile(): QueryConfig<T>;
    /** Phantom member so the result type can be inferred from a definition value. */
    readonly __result?: T;
}
/** Describes a model with the fluent API against a hand-written interface. */
export declare function defineModel<T>(configure: EntityModelConfigure<T>): EntityModelDefinition<T>;
/** Layers additional fluent configuration over a decorated class. Fluent calls override the decorators. */
export declare function modelFromEntity<T>(entityClass: EntityClass<T>, configure?: EntityModelConfigure<T>): EntityModelDefinition<T>;
/** Creates a new definition that replays the base steps and then the override. The base is untouched. */
export declare function extendModel<T>(base: EntityModelDefinition<T>, configure: EntityModelConfigure<T>): EntityModelDefinition<T>;
export declare function isEntityModelDefinition(value: unknown): value is EntityModelDefinition<unknown>;
export {};
