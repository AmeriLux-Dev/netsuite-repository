"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.parseCommandLineArguments = parseCommandLineArguments;
exports.readStringOption = readStringOption;
exports.readFlagOption = readFlagOption;
/** Parses `command --key value --key=value --flag positional` without any dependency. */
function parseCommandLineArguments(argv) {
    const parsed = { options: {}, positional: [] };
    for (let index = 0; index < argv.length; index++) {
        const argument = argv[index];
        if (argument.startsWith('--')) {
            const body = argument.slice(2);
            const equalsIndex = body.indexOf('=');
            if (equalsIndex >= 0) {
                parsed.options[body.slice(0, equalsIndex)] = body.slice(equalsIndex + 1);
            }
            else if (index + 1 < argv.length && !argv[index + 1].startsWith('--')) {
                parsed.options[body] = argv[++index];
            }
            else {
                parsed.options[body] = true;
            }
        }
        else if (parsed.command === undefined) {
            parsed.command = argument;
        }
        else {
            parsed.positional.push(argument);
        }
    }
    return parsed;
}
function readStringOption(options, name) {
    const value = options[name];
    return typeof value === 'string' ? value : undefined;
}
function readFlagOption(options, name) {
    return options[name] === true || options[name] === 'true';
}
