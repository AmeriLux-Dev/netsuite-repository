import type { FileSystemAdapter } from '../file-system';
import type { CheckResult, GenerateOptions, GenerateResult, GenerationPlan } from '../generate';
import type { ModelWatcher } from '../watch';
export interface CliEnvironment {
    cwd: string;
    fileSystem?: FileSystemAdapter;
    stdout: (message: string) => void;
    stderr: (message: string) => void;
    /** Replaceable for tests. */
    generate?: (options: GenerateOptions) => GenerateResult;
    check?: (options: GenerateOptions) => CheckResult;
    plan?: (options: GenerateOptions) => GenerationPlan;
    /** Called with the running watcher so a caller can stop it; the CLI itself keeps the process alive. */
    onWatcherStarted?: (watcher: ModelWatcher) => void;
}
export declare const CLI_USAGE: string;
export declare const EXIT_SUCCESS = 0;
export declare const EXIT_PROBLEMS = 1;
export declare const EXIT_USAGE = 2;
/** Runs the CLI and resolves to the process exit code. Never throws for user errors. */
export declare function runCli(argv: string[], environment: CliEnvironment): Promise<number>;
