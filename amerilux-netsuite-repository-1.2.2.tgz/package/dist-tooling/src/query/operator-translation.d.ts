import type { ConditionParamValue, FieldType, NQueryOperatorName, QueryOperator } from '../types';
export interface TranslatedCondition {
    operator: NQueryOperatorName;
    values?: ConditionParamValue[];
    /**
     * Set when N/query has no list operator for the field type: the operator applies to each value on its own and
     * the conditions are combined with `or` (IN) or `and` (NOT IN).
     */
    combine?: 'or' | 'and';
}
export declare function isNQueryOperatorName(operator: string): operator is NQueryOperatorName;
/** Select, multiselect, and key fields compare through ANY_OF in N/query; EQUAL is not valid on them. */
export declare function isSelectLikeField(fieldType: FieldType | undefined): boolean;
/** A checkbox compares as a boolean; NetSuite's own 'T'/'F' spellings are accepted for it. Everything else binds as given. */
export declare function normalizeConditionValue(value: ConditionParamValue, fieldType: FieldType | undefined): ConditionParamValue;
/**
 * Turns a `LIKE` pattern into the N/query operator that expresses it: a trailing `%` is START_WITH, a leading `%`
 * is ENDWITH, both is CONTAIN, none is IS (text equality). Patterns N/query cannot express (`_`, a `%` in the
 * middle) are rejected; a formula condition is the way to write those.
 */
export declare function translateLikePatternToQueryOperator(pattern: string, negated: boolean): TranslatedCondition;
/**
 * Translates a SQL-style operator and its value into the N/query operator for the field's type: `=` is IS on text
 * and checkboxes, ON on a date, ANY_OF on a select or key field, and EQUAL on numbers; the order comparisons become
 * BEFORE/AFTER on dates and LESS/GREATER otherwise; `IN` is ANY_OF on a select or key field and one equality per
 * value combined with `or` elsewhere; `IS NULL` is EMPTY; `LIKE` follows its wildcards. An N/query operator name
 * passes through with its values normalized.
 */
export declare function translateConditionOperator(operator: QueryOperator, fieldType: FieldType | undefined, value: ConditionParamValue | ConditionParamValue[] | undefined): TranslatedCondition;
