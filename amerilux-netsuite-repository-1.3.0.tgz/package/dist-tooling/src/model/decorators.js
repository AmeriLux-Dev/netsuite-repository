"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RecordType = RecordType;
exports.InternalId = InternalId;
exports.ParentId = ParentId;
exports.Field = Field;
exports.ReadOnly = ReadOnly;
exports.Reference = Reference;
exports.Subrecord = Subrecord;
exports.Sublist = Sublist;
exports.SetFirst = SetFirst;
exports.ExcludeFromDefaultSelect = ExcludeFromDefaultSelect;
exports.Transform = Transform;
exports.NotMapped = NotMapped;
exports.getOwnClassOverrides = getOwnClassOverrides;
exports.getClassOverrides = getClassOverrides;
exports.isModelClass = isModelClass;
exports.isRecordTypeClass = isRecordTypeClass;
const metadata_1 = require("./metadata");
const registry = new WeakMap();
function getOrCreateRegistration(target) {
    let overrides = registry.get(target);
    if (!overrides) {
        overrides = (0, metadata_1.createClassOverrides)();
        registry.set(target, overrides);
    }
    return overrides;
}
function toPropertyName(target, propertyKey) {
    if (typeof propertyKey !== 'string') {
        throw new Error(`Symbol properties cannot be mapped on '${target.constructor.name}'.`);
    }
    return propertyKey;
}
function propertyDecorator(apply) {
    return (target, propertyKey) => {
        const overrides = getOrCreateRegistration(target.constructor);
        apply((0, metadata_1.getOrCreatePropertyOverrides)(overrides, toPropertyName(target, propertyKey)), overrides);
    };
}
/** Splits the `(id?, options?)` and `(options)` call shapes the relation decorators share. */
function splitIdAndOptions(first, second) {
    return typeof first === 'string'
        ? { id: first, options: second ?? {} }
        : { id: undefined, options: first ?? {} };
}
function applyRelationOptions(property, options) {
    if (options.load !== undefined)
        property.load = options.load;
    if (options.selectByDefault !== undefined)
        property.selectByDefault = options.selectByDefault;
}
// ── class decorator ───────────────────────────────────────────────────────────
/** A queryable record type. The class becomes a record set on the context, queried through N/query as the same type. */
function RecordType(recordType, options = {}) {
    return (target) => {
        const overrides = getOrCreateRegistration(target);
        overrides.recordType = recordType;
        overrides.queryType = options.queryType;
        overrides.rootFilter = options.filter;
        overrides.setName = options.setName;
        overrides.coerce = options.coerce;
        overrides.updaterOptions = options.updater;
    };
}
// ── property decorators ───────────────────────────────────────────────────────
/** Marks the internal id when it is not the property named `id`. */
function InternalId() {
    return propertyDecorator((property, overrides) => {
        overrides.keyProperty = property.name;
    });
}
/** On a line class: marks the property holding the parent record's internal id. Its field is what the sublist join goes through. */
function ParentId() {
    return propertyDecorator((property, overrides) => {
        overrides.parentKeyProperty = property.name;
    });
}
function Field(first, second) {
    const { id: fieldId, options } = splitIdAndOptions(first, second);
    return propertyDecorator((property) => {
        if (fieldId !== undefined)
            property.fieldId = fieldId;
        if (options.queryFieldId !== undefined)
            property.queryFieldId = options.queryFieldId;
        if (options.type !== undefined)
            property.type = options.type;
        if (options.text !== undefined)
            property.text = options.text;
        if (options.coerce !== undefined)
            property.coerce = options.coerce;
        if (options.relationship !== undefined)
            property.relationshipFieldId = options.relationship;
        if (options.filter !== undefined)
            property.filter = options.filter;
        if (options.readOnly !== undefined)
            property.readOnly = options.readOnly;
        if (options.setFirst !== undefined)
            property.setFirst = options.setFirst;
        if (options.selectByDefault !== undefined)
            property.selectByDefault = options.selectByDefault;
        if (options.transform !== undefined)
            property.transform = options.transform;
    });
}
/** @deprecated Use `@Field({ readOnly: true })`. */
function ReadOnly() {
    return propertyDecorator((property) => {
        property.readOnly = true;
    });
}
function Reference(first, second) {
    const { id: selectFieldProperty, options } = splitIdAndOptions(first, second);
    return propertyDecorator((property) => {
        property.relationKind = 'reference';
        if (selectFieldProperty !== undefined)
            property.selectFieldProperty = selectFieldProperty;
        if (options.targetKey !== undefined)
            property.targetKeyProperty = options.targetKey;
        if (options.join !== undefined)
            property.joinKind = options.join;
        applyRelationOptions(property, options);
    });
}
function Subrecord(first, second) {
    const { id: fieldId, options } = splitIdAndOptions(first, second);
    return propertyDecorator((property) => {
        property.relationKind = 'subrecord';
        if (fieldId !== undefined)
            property.subrecordFieldId = fieldId;
        if (options.clearListField !== undefined)
            property.clearListField = options.clearListField;
        applyRelationOptions(property, options);
    });
}
function Sublist(first, second) {
    const { id: sublistId, options } = splitIdAndOptions(first, second);
    return propertyDecorator((property) => {
        property.relationKind = 'sublist';
        if (sublistId !== undefined)
            property.sublistId = sublistId;
        if (options.filter !== undefined)
            property.filter = options.filter;
        if (options.relationship !== undefined)
            property.relationshipFieldId = options.relationship;
        if (options.queryType !== undefined)
            property.separateQueryType = options.queryType;
        if (options.through !== undefined)
            property.through = options.through.map(toRelationHop);
        applyRelationOptions(property, options);
    });
}
/** A hop given as a bare field id is autoJoin on that relationship field. */
function toRelationHop(hop) {
    return typeof hop === 'string' ? { fieldId: hop } : { ...hop };
}
/** @deprecated Use `@Field({ setFirst: true })`. */
function SetFirst() {
    return propertyDecorator((property) => {
        property.setFirst = true;
    });
}
/** @deprecated Use `@Field({ selectByDefault: false })`, or `{ selectByDefault: false }` on `@Reference`, `@Subrecord`, or `@Sublist`. */
function ExcludeFromDefaultSelect() {
    return propertyDecorator((property) => {
        property.selectByDefault = false;
    });
}
/** @deprecated Use `@Field({ transform })`. */
function Transform(transform) {
    return propertyDecorator((property) => {
        property.transform = transform;
    });
}
/** Excludes a property from the model entirely. */
function NotMapped() {
    return propertyDecorator((property, overrides) => {
        overrides.notMapped.add(property.name);
    });
}
// ── registry access (used by the build step) ─────────────────────────────────
function collectPrototypeChain(modelClass) {
    const chain = [];
    let current = modelClass;
    while (typeof current === 'function' && current !== Function.prototype) {
        chain.unshift(current);
        current = Object.getPrototypeOf(current);
    }
    return chain;
}
/** The overrides registered on exactly this class, ignoring base classes. */
function getOwnClassOverrides(modelClass) {
    return registry.get(modelClass);
}
/** The overrides of a class merged over those of its base classes, base first. */
function getClassOverrides(modelClass) {
    const merged = (0, metadata_1.createClassOverrides)();
    for (const constructor of collectPrototypeChain(modelClass)) {
        const own = registry.get(constructor);
        if (own) {
            (0, metadata_1.mergeClassOverrides)(merged, own);
        }
    }
    return merged;
}
/** True when the class or one of its bases carries a model decorator. */
function isModelClass(value) {
    return typeof value === 'function' && collectPrototypeChain(value).some((constructor) => registry.has(constructor));
}
/** True only for classes carrying @RecordType somewhere in their prototype chain. */
function isRecordTypeClass(value) {
    return typeof value === 'function' && getClassOverrides(value).recordType !== undefined;
}
